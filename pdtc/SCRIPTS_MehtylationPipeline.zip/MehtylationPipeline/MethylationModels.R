load("/Methylation/PromMethylationPDX.RData")
SS <- read.table("/Methylation/MethylationSampleSheet.txt", header=TRUE, sep="\t", stringsAsFactors=F)

X <- res[,-1]
rownames(X) <- res[,1]
X <- X[,grep("Mean", colnames(X))]
colnames(X) <- sub("Mean_", "", colnames(X), fixed=TRUE)
colnames(X)

SS <- SS[which(SS$Include=="YES"),]
X <- X[,which(colnames(X) %in% SS$Gname)]
SS <- SS[match(colnames(X), SS$Gname),]
colnames(X) <- SS$ID

  load("/Methylation/PDTX.RRBS.design.RData")
  badids <- as.character(design$ID[which(design$CpG.5 < 1500000)])
  X <- X[,which(!colnames(X) %in% badids)]
  SS <- SS[which(!SS$ID %in% badids),]

Meth <- X
X <- SS

models <- unique(SS$Tumour)
PDTX.Meth <- matrix(NA, nrow(Meth), length(models))
Tumour.Meth <- matrix(NA, nrow(Meth), length(models))
Normal.Meth <- matrix(NA, nrow(Meth), length(models))
colnames(PDTX.Meth) <- models
colnames(Tumour.Meth) <- models
colnames(Normal.Meth) <- models
rownames(PDTX.Meth) <- rownames(Meth)
rownames(Tumour.Meth) <- rownames(Meth)
rownames(Normal.Meth) <- rownames(Meth)
for (i in models) {
    ids <- which(SS$Tumour==i & SS$TYPE %in% c("PDTX", "PDTC"))
    if (length(ids) > 0) {
        PDTX.Meth[,i] <- apply(Meth[,ids,drop=FALSE], 1, mean, na.rm=TRUE)
    }
    ids <- which(SS$Tumour==i & SS$TYPE =="TUMOUR")
    if (length(ids) > 0) {
        Tumour.Meth[,i] <- apply(Meth[,ids,drop=FALSE], 1, mean, na.rm=TRUE)
    }
    ids <- which(SS$Tumour==i & SS$TYPE =="NORMAL")
    if (length(ids) > 0) {
        Normal.Meth[,i] <- apply(Meth[,ids,drop=FALSE], 1, mean, na.rm=TRUE)
    }
}


pdf("/Methylation/BRCA1PromoterMethylation.pdf", width=12, height=6, useDingbats=F)
library(lattice)
tmp <- sort(PDTX.Meth['BRCA1',])
tmp.names <- names(tmp)
tmp <- data.frame(Model=as.character(tmp.names), Meth=tmp)
dotplot(Meth ~ factor(Model, levels=tmp$Model), data=tmp, pch=19, xlab=list(label="BRCA1 Promoter Methylation Percentage", cex=2),
        ylab=list(label="Percentage", cex=2), ylim=c(0,100), horizontal=FALSE, col=1,
        scales=list(x=list(rot=45, cex=1.5), y=list(cex=1.5)))
dev.off()


bads <- apply(PDTX.Meth, 2, function(x) mean(is.na(x)))
PDTX.Meth <- PDTX.Meth[,which(bads < 1)]
PDTX.Meth <- PDTX.Meth[,order(colnames(PDTX.Meth))]
PDTX.Meth <- data.frame(Gene=rownames(PDTX.Meth), PDTX.Meth)


Meth <- Meth[,order(colnames(Meth))]
Meth <- data.frame(Gene=rownames(Meth), Meth)
colnames(Meth) <- gsub(".", "-", colnames(Meth), fixed=TRUE)

write.table(Meth, file=“/PromoterMethylationSamples.txt", row.names=F, sep="\t", quote=F)
write.table(PDTX.Meth, file="PromoterMethylationModels.txt", row.names=F, sep="\t", quote=F)

