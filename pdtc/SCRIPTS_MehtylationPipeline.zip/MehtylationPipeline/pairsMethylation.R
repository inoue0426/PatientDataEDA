files <- c("/Methylation/PromMethylationPDX.RData",
           "/Methylation/PromMethylationPDX.10.RData",
           "/Methylation/PromMethylationPDX.20.RData")
reads <- c(5, 10, 20)
names(reads) <- files
for (ff in files) {

load(ff)
SS <- read.table("/Methylation/MethylationSampleSheet.txt", header=TRUE, sep="\t", stringsAsFactors=F)

X <- res[,-1]
rownames(X) <- res[,1]
X <- X[,grep("Mean", colnames(X))]
colnames(X) <- sub("Mean_", "", colnames(X), fixed=TRUE)
colnames(X)
SS <- SS[which(SS$Include=="YES"),]
X <- X[,which(colnames(X) %in% SS$Gname)]
SS <- SS[match(colnames(X),SS$Gname),]
colnames(X) <- SS$ID

  load("/Methylation/PDTX.RRBS.design.RData")
  badids <- as.character(design$ID[which(design$CpG.5 < 1000000)])
  X <- X[,which(!SS$ID %in% badids)]
  SS <- SS[which(!SS$ID %in% badids),]


for (i in sort(unique(SS$Tumour))) {
    sub.SS <- SS[which(SS$Tumour==i),]
    sub.X <- X[,which(colnames(X) %in% sub.SS$ID)]
    sub.SS <- sub.SS[match(colnames(sub.X), sub.SS$ID),]
    ids <- order(sub.SS$PASSAGE, sub.SS$ID)
    if (length(ids) > 1) {
    png(paste("/Methylation/pairsMethylation_", i, "_", reads[ff], ".png", sep=""), width=1200, height=1200)
    pairs(sub.X[,ids], upper.panel=function(x,y,...) smoothScatter(x,y,add=TRUE), lower.panel=NULL, cex.labels=1.4)
    dev.off()
    }
	cat(i, " done\n")
}

sub.SS <- SS[which(SS$TYPE=="TUMOUR"),]
sub.X <- X[,which(colnames(X) %in% sub.SS$ID)]
sub.SS <- sub.SS[match(colnames(sub.X), sub.SS$ID),]
ids <- order(sub.SS$PASSAGE, sub.SS$ID)
if (length(ids) > 1) {
    png(paste("/Methylation/pairsMethylation_Tumours_", reads[ff], ".png", sep=""), width=1200, height=1200)
    pairs(sub.X[,ids], upper.panel=function(x,y,...) smoothScatter(x,y,add=TRUE), lower.panel=NULL, cex.labels=1.4)
dev.off()
}
cat(i, " done\n")

}
