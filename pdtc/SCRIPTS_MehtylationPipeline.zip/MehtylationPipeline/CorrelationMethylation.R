files <- c(“/Methylation/PromMethylationPDX.RData",
           “/Methylation/PromMethylationPDX.10.RData",
           "/Methylation/PromMethylationPDX.20.RData")
reads <- c(5, 10, 20)
names(reads) <- files
for (ff in files) {
  load(ff)
SS <- read.table("/Methylation/MethylationSampleSheet.txt", header=TRUE, sep="\t", stringsAsFactors=F)

X <- res[,-1]
rownames(X) <- res[,1]
X <- X[,grep("Mean", colnames(X))]
colnames(X) <- sub("Mean_", "", colnames(X), fixed=TRUE)
colnames(X)

SS <- SS[which(SS$Include=="YES"),]
X <- X[,which(colnames(X) %in% SS$Name)]
SS <- SS[match(colnames(X), SS$Name),]
colnames(X) <- SS$ID

  load("/Methylation/PDTX.RRBS.design.RData")
  badids <- as.character(design$ID[which(design$CpG.5 < 1000000)])
  X <- X[,which(!colnames(X) %in% badids)]
  SS <- SS[which(!SS$ID %in% badids),]

badProms <- apply(X, 1, IQR, na.rm=T)
X <- X[which(badProms > 25),]

Meth <- X
X <- SS
pdf(paste("/Methylation/Correlation_Methylation_", reads[ff], ".pdf", sep=""), width=12, height=9)
for (cor.method in c("pearson", "spearman")) {

all.cor.rep.pdx <- list()
all.cor.pass.pdx <- list()
all.cor.tum.pdx <- list()
all.cor.tum.tum <- list()
all.cor.tumour.tech <- c()
all.cor.pdtc.pdx <- c()

for (i in unique(X$Tumour)) {
    ## Replicate PDXs
    all.cor.rep.pdx[[i]] <- c()
    sub.X <- X[which(X$Tumour==i),]
    sub.Meth <- Meth[,which(X$Tumour==i)]
    PDX <- which(sub.X$TYPE=="PDTX")
    for (j in PDX) {
        ids <- which(sub.X$TYPE=="PDTX" & sub.X$PASSAGE==sub.X$PASSAGE[j])
        if (length(ids) > 1) {
            tmp <- cor(sub.Meth[,ids], use="pairwise.complete.obs", method=cor.method)
            tmp <- tmp[row(tmp)>col(tmp)]
            all.cor.rep.pdx[[i]] <- c(all.cor.rep.pdx[[i]], tmp)
        }
    }
    all.cor.rep.pdx[[i]] <- unique(all.cor.rep.pdx[[i]])
    ## Different PDXs passages
    all.cor.pass.pdx[[i]] <- c()
    sub.X <- X[which(X$Tumour==i),]
    sub.Meth <- Meth[,which(X$Tumour==i)]
    PDX <- which(sub.X$TYPE=="PDTX")
    for (j in PDX) {
        ids <- which(sub.X$PASSAGE!=sub.X$PASSAGE[j])
        if (length(ids) > 1) {
            tmp <- cor(sub.Meth[,ids], use="pairwise.complete.obs", method=cor.method)
            tmp <- tmp[row(tmp)>col(tmp)]
            all.cor.pass.pdx[[i]] <- c(all.cor.pass.pdx[[i]], tmp)
        }
    }
    all.cor.pass.pdx[[i]] <- unique(all.cor.pass.pdx[[i]])
    ## Tumours vs PDXs
    all.cor.tum.pdx[[i]] <- c()
    sub.X <- X[which(X$Tumour==i),]
    sub.Meth <- Meth[,which(X$Tumour==i)]
    Tum <- which(sub.X$TYPE=="TUMOUR")
    PDX <- which(sub.X$TYPE=="PDTX")
    if (length(Tum)>0 & length(PDX)>0) {
        for (j in Tum) {
            tmp <- cor(sub.Meth[,j], sub.Meth[,PDX], use="pairwise.complete.obs", method=cor.method)
            all.cor.tum.pdx[[i]] <- c(all.cor.tum.pdx[[i]], tmp)
        }
    }
    ## Tumours vs Tumours
    all.cor.tum.tum[[i]] <- c()
    Tum <- which(X$TYPE=="TUMOUR" & X$Tumour==i)
    Other <- which(X$TYPE=="TUMOUR" & X$Tumour!=i)
    if (length(Tum)>0) {
        for (j in Tum) {
            tmp <- cor(Meth[,j], Meth[,Other], use="pairwise.complete.obs", method=cor.method)
            all.cor.tum.tum[[i]] <- c(all.cor.tum.tum[[i]], tmp)
        }
    }

}

all.cor.rep.pdx <- do.call("c", all.cor.rep.pdx)
all.cor.pass.pdx <- do.call("c", all.cor.pass.pdx)
all.cor.tum.pdx <- do.call("c", all.cor.tum.pdx)
all.cor.tum.tum <- do.call("c", all.cor.tum.tum)

## PDTCs
all.cor.pdtc.pdx <- c()
ids <- which(X$TYPE=="PDTC")
for (i in ids) {
    found <- which(X$Tumour==X$Tumour[i] & X$TYPE=="PDTX" & X$PASSAGE==X$PASSAGE[i])
    if (length(found)>0) {
        tmp <- cor(Meth[,i], Meth[,found], use="pairwise.complete.obs", method=cor.method)
    all.cor.pdtc.pdx <- c(all.cor.pdtc.pdx, tmp)
    }
}

## Normal (Technical replicate)
all.cor.tumour.tech <- c()
ids <- X[grep("TR", X$ID),'Tumour']
for (i in ids) {
    found <- which(X$Tumour==i & X$TYPE=="TUMOUR")
    if (length(found) > 1) {
        tmp <- cor(Meth[,found], use="pairwise.complete.obs", method=cor.method)
        tmp <- tmp[row(tmp)>col(tmp)]
        all.cor.tumour.tech <- c(all.cor.tumour.tech, tmp)
    }
}
ids <- X[grep("C7R", X$ID),'Tumour']
for (i in ids) {
    found <- which(X$Tumour==i & X$TYPE=="PDTC")
    if (length(found) > 1) {
        tmp <- cor(Meth[,found], use="pairwise.complete.obs", method=cor.method)
        tmp <- tmp[row(tmp)>col(tmp)]
        all.cor.tumour.tech <- c(all.cor.tumour.tech, tmp)
    }
}




cor.method.name <- c("Pearson", "Spearman")
names(cor.method.name) <- c("pearson", "spearman")
boxplot(all.cor.tumour.tech, all.cor.pdtc.pdx,
all.cor.rep.pdx, all.cor.pass.pdx, all.cor.tum.pdx, all.cor.tum.tum,
        names=c("Tech. Replicates", "PDTCs vs PDXs", "Mice Replicates",
            "PDTXs Passages", "PDTX vs Tumour", "Different Tumours"),
        ylab=paste(cor.method.name[cor.method], "Correlation"),
                col=c("grey", "red", "yellow", "olivedrab", "orange", "darkblue"), cex.lab=1.2, cex.axis=1.2)

}
dev.off()

}
