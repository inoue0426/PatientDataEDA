## QDNASEQ may shift the logratios: let's check
load(file="GENE.CN.RData")
Tumour <- sapply(strsplit(colnames(GENE.CN), "-", fixed=TRUE),
                 function(x) x[1])
all.lev <- c("HOMD", "HETD", "NEUT", "GAIN", "AMP")
all.scores <- list()
for (i in unique(Tumour)) {
    x <- GENE.CN[,which(Tumour==i),drop=FALSE]
    if (ncol(x) > 2) {
        all.scores[[i]] <- matrix(1, ncol(x), ncol(x))
        for (j in 1:ncol(x)) {
            for (k in (1:ncol(x))[-j]) {
                tmp <- table(factor(x[,j], levels=all.lev),
                             factor(x[,k], levels=all.lev))
                tmp <- sum(diag(tmp)) / sum(tmp)
                all.scores[[i]][j,k] <- tmp
                all.scores[[i]][k,j] <- tmp
            }
        }
        rownames(all.scores[[i]]) <- colnames(x)
        colnames(all.scores[[i]]) <- colnames(x)
    }
}

x <- GENE.CN[,which(Tumour %in% c("STG139", "STG139M")),drop=FALSE]
i <- "ALLSTG139"
if (ncol(x) > 2) {
    all.scores[[i]] <- matrix(1, ncol(x), ncol(x))
    for (j in 1:ncol(x)) {
        for (k in (1:ncol(x))[-j]) {
            tmp <- table(factor(x[,j], levels=all.lev),
                         factor(x[,k], levels=all.lev))
            tmp <- sum(diag(tmp)) / sum(tmp)
            all.scores[[i]][j,k] <- tmp
            all.scores[[i]][k,j] <- tmp
        }
    }
    rownames(all.scores[[i]]) <- colnames(x)
    colnames(all.scores[[i]]) <- colnames(x)
    }


## Outliers:
## STG282-X1 is very different
## VHIO089 is difficult to know, but looks fine to me
## STG139 needs some shifting

pdf("AgreementCN.pdf", width=8, height=8)
par(oma=c(6,6,2,2))
library(RColorBrewer)
all.col <- c(brewer.pal(8, "Reds"))
breaks <- seq(from=-0.01, to=1.01, length=9)
for (i in 1:length(all.scores)) {
    image(all.scores[[i]],
          breaks=breaks, col=all.col, axes=F,
          main=names(all.scores)[[i]])
    x.ticks <- seq(from=0, to=1, length=ncol(all.scores[[i]]))
    y.ticks <- seq(from=0, to=1, length=ncol(all.scores[[i]]))
    axis(1, at=x.ticks, labels=colnames(all.scores[[i]]),
         cex.axis=1.2, las=2)
    axis(2, at=y.ticks, labels=colnames(all.scores[[i]]),
         cex.axis=1.2, las=2)
    box()
}
dev.off()


## Shift:
##     - STG139-T
##     - STG139-X12
##     - STG139-X14
##     - STG139-X13
##     - STG139-X0
##     - VHIO098-X10
##       - VHIO244
## STG201
