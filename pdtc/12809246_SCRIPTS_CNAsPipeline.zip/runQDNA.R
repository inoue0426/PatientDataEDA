setwd("/lDupMarked")
sample.files <- dir(pattern=".bam$")
binSize <- 100
library(QDNAseq)
bins <- getBinAnnotations(binSize=binSize)
i <- as.numeric(Sys.getenv("LSB_JOBINDEX"))
sample.files <- sample.files[i]
for (i in sample.files)  {
    sample.name <- i
    x <- binReadCounts(bins, bamfiles=i)
    x.f <- applyFilters(x, residual=TRUE, blacklist=TRUE, chromosomes="Y")
    x.f <- estimateCorrection(x.f)
    cn <- correctBins(x.f)
    cn <- normalizeBins(cn)
    cn <- smoothOutlierBins(cn)
    cn <- segmentBins(cn, transformFun="sqrt")
    cn <- normalizeSegmentedBins(cn)
    pdf(paste("/QDNA/", 
								   sample.name, "_QDNAseq.pdf", sep=""), width=12, height=6)
    plot(cn)
    dev.off()
    exportBins(cn, format="tsv", type="copynumber", file=paste("tmp", sample.name, ".txt", sep=""))
    x <- read.table(paste("tmp", sample.name, ".txt", sep=""), header=T, sep="\t")
    colnames(x)[5] <- paste(sample.name, "ratio", sep=".")
    exportBins(cn, format="tsv", type="segments", file=paste("tmp", sample.name, ".txt", sep=""))
    tmp <- read.table(paste("tmp", sample.name, ".txt", sep=""), header=T, sep="\t")
    x <- cbind(x, tmp[,5])
    colnames(x)[6] <- colnames(x)[5]
    colnames(x)[6] <- sub("ratio", "segments", colnames(x)[6])
    write.table(x, file=paste("/QDNA/", 
    		   							    sample.name, "_QDNAseq.txt", sep=""), row.names=F, sep="\t", quote=F)
    cat(i, " done\n")
}
