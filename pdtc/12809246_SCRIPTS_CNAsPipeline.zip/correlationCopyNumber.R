######################################################################
######################################################################
## Now with Copy Number
######################################################################
######################################################################

setwd("CopyNumber/")
allF <- dir(pattern=".txt")
nams <- sub("_ordered.bam.picard.bam_QDNAseq.txt", "", allF, fixed=TRUE)
nams <- sub("Shallow_", "", nams, fixed=TRUE)

res <- NULL
for (i in 1:length(nams)) {
    tmp <- read.table(allF[i], header=TRUE, sep="\t")
    res <- cbind(res, tmp[,6])
}
colnames(res) <- nams

## Let's remove ugly regions
feo <- apply(res, 1, function(x) mean(x < -10, na.rm=T))
res[which(feo>0.9),] <- NA
res[which(res < -10)] <- -10

## Let's remove ugly samples: less than 2,000,000 reads
bads <- c("AB551-X0R", "AB569-X1" ,"AB569-XC7",
          "HC1", "HC2", "HC3", "HCI011-XC", "NORMAL",
          "STG139-X0", "STG235-X1", "STG235-X2",
          "STG335-X4C7", "VHIO136-X14", "VHIO136-X15")
res <- res[,-which(colnames(res) %in% bads)]

SS <- read.table("/SampleSheetShallow.txt", header=TRUE, sep="\t", stringsAsFactors=F)
res <- res[, which(colnames(res) %in% SS$ID[which(SS$Include=="YES")])]
X <- SS[which(SS$ID %in% colnames(res)),]
X$TYPE <- X$Type
X <- X[match(colnames(res), X$ID),]

## Correct for contamination

load("/Exomes/NormalContamination.RData")

for (i in names(all.est)) {
    ids <- which(colnames(res)==i)
    if (length(ids) > 0) {
    x <- 2^res[,ids]
    y <- (x - (1-all.est[i])) / all.est[i]
    y[which(y<=0)] <- 1e-4
    y <- log2(y)
    res[,ids] <- y
    }
}


all.cor.rep.pdx <- list()
all.cor.pass.pdx <- list()
all.cor.tum.pdx <- list()
all.cor.tum.tum <- list()


for (i in unique(X$Tumour)) {
    ## Replicate PDXs
    all.cor.rep.pdx[[i]] <- c()
    sub.X <- X[which(X$Tumour==i),]
    sub.res <- res[,which(X$Tumour==i)]
    PDX <- which(sub.X$TYPE=="PDTX")
    for (j in PDX) {
        ids <- which(sub.X$PASSAGE==sub.X$PASSAGE[j])
        if (length(ids) > 1) {
            tmp <- cor(sub.res[,ids], use="pairwise.complete.obs", method="pearson")
            tmp <- tmp[row(tmp)>col(tmp)]
            all.cor.rep.pdx[[i]] <- c(all.cor.rep.pdx[[i]], tmp)
        }
    }
    all.cor.rep.pdx[[i]] <- unique(all.cor.rep.pdx[[i]])
    ## Different PDXs passages
    all.cor.pass.pdx[[i]] <- c()
    sub.X <- X[which(X$Tumour==i),]
    sub.res <- res[,which(X$Tumour==i)]
    PDX <- which(sub.X$TYPE=="PDTX")
    for (j in PDX) {
        ids <- which(sub.X$PASSAGE!=sub.X$PASSAGE[j])
        if (length(ids) > 1) {
            tmp <- cor(sub.res[,ids], use="pairwise.complete.obs", method="pearson")
            tmp <- tmp[row(tmp)>col(tmp)]
            all.cor.pass.pdx[[i]] <- c(all.cor.pass.pdx[[i]], tmp)
        }
    }
    all.cor.pass.pdx[[i]] <- unique(all.cor.pass.pdx[[i]])
    ## Tumours vs PDXs
    all.cor.tum.pdx[[i]] <- c()
    sub.X <- X[which(X$Tumour==i),]
    sub.res <- res[,which(X$Tumour==i)]
    Tum <- which(sub.X$TYPE=="Tumour")
    PDX <- which(sub.X$TYPE=="PDTX")
    if (length(Tum)>0 & length(PDX)>0) {
        for (j in Tum) {
            tmp <- cor(sub.res[,j], sub.res[,PDX], use="pairwise.complete.obs", method="pearson")
            all.cor.tum.pdx[[i]] <- c(all.cor.tum.pdx[[i]], tmp)
        }
    }
    ## Tumours vs Tumours
    all.cor.tum.tum[[i]] <- c()
    Tum <- which(X$TYPE=="Tumour" & X$Tumour==i)
    Other <- which(X$TYPE=="Tumour" & X$Tumour!=i)
    if (length(Tum)>0) {
        for (j in Tum) {
            tmp <- cor(res[,j], res[,Other], use="pairwise.complete.obs", method="pearson")
            all.cor.tum.tum[[i]] <- c(all.cor.tum.tum[[i]], tmp)
        }
    }

}
all.cor.rep.pdx <- do.call("c", all.cor.rep.pdx)
all.cor.pass.pdx <- do.call("c", all.cor.pass.pdx)
all.cor.tum.pdx <- do.call("c", all.cor.tum.pdx)
all.cor.tum.tum <- do.call("c", all.cor.tum.tum)

## PDTCs
all.cor.pdtc.pdx <- c()
ids <- which(X$TYPE=="PDTC")
for (i in ids) {
    found <- which(X$Tumour==X$Tumour[i] & X$TYPE=="PDTX" & X$PASSAGE==X$PASSAGE[i])
    if (length(found)>0) {
        tmp <- cor(res[,i], res[,found], use="pairwise.complete.obs", method="pearson")
        all.cor.pdtc.pdx <- c(all.cor.pdtc.pdx, tmp)
    }
}

## Tumour (Technical replicate)
all.cor.tumour.tech <- c()
ids <- X[grep("TR", X$ID),'Tumour']
for (i in ids) {
    found <- which(X$Tumour==i & X$TYPE=="Tumour")
    tmp <- cor(res[,found], use="pairwise.complete.obs", method="pearson")
    tmp <- tmp[row(tmp)>col(tmp)]
    all.cor.tumour.tech <- c(all.cor.tumour.tech, tmp)
}

sum(sapply(split(X, X$Tumour), function(x) sum(x$TYPE=="PDTX")>0))
sum(sapply(split(X, X$Tumour), function(x) sum(x$TYPE=="PDTX")))
sum(sapply(split(X, interaction(X$PASSAGE, X$Tumour)), function(x) {
    tmp <- sum(x$TYPE=="PDTX")
    ifelse(tmp>1, tmp, 0)
}))
sum(sapply(split(X, X$Tumour), function(x) sum(x$TYPE=="Tumour")>1))
length(unique(X$Tumour[which(X$TYPE=="Tumour")]))

round(summary(all.cor.tum.pdx), 2)
round(summary(all.cor.pass.pdx), 2)
round(summary(all.cor.pdtc.pdx), 2)

pdf("/Correlation_CN.pdf", width=12, height=9)
boxplot(all.cor.tumour.tech, all.cor.pdtc.pdx,
all.cor.rep.pdx, all.cor.pass.pdx, all.cor.tum.pdx, all.cor.tum.tum,
        names=c("Tech. Replicates", "PDTCs vs PDXs", "Mice Replicates",
            "PDTXs Passages", "PDTX vs Tumour", "Different Tumours"), ylab="Pearson Correlation",
                col=c("grey", "red", "yellow", "olivedrab", "orange", "darkblue"), cex.lab=1.2, cex.axis=1.2)

## Spearman

all.cor.rep.pdx <- list()
all.cor.pass.pdx <- list()
all.cor.tum.pdx <- list()
all.cor.tum.tum <- list()

for (i in unique(X$Tumour)) {
    ## Replicate PDXs
    all.cor.rep.pdx[[i]] <- c()
    sub.X <- X[which(X$Tumour==i),]
    sub.res <- res[,which(X$Tumour==i)]
    PDX <- which(sub.X$TYPE=="PDTX")
    for (j in PDX) {
        ids <- which(sub.X$TYPE=="PDTX" & sub.X$PASSAGE==sub.X$PASSAGE[j])
        if (length(ids) > 1) {
            tmp <- cor(sub.res[,ids], use="pairwise.complete.obs", method="spearman")
            tmp <- tmp[row(tmp)>col(tmp)]
            all.cor.rep.pdx[[i]] <- c(all.cor.rep.pdx[[i]], tmp)
        }
    }
    all.cor.rep.pdx[[i]] <- unique(all.cor.rep.pdx[[i]])
    ## Different PDXs passages
    all.cor.pass.pdx[[i]] <- c()
    sub.X <- X[which(X$Tumour==i),]
    sub.res <- res[,which(X$Tumour==i)]
    PDX <- which(sub.X$TYPE=="PDTX")
    for (j in PDX) {
        ids <- which(sub.X$PASSAGE!=sub.X$PASSAGE[j])
        if (length(ids) > 1) {
            tmp <- cor(sub.res[,ids], use="pairwise.complete.obs", method="spearman")
            tmp <- tmp[row(tmp)>col(tmp)]
            all.cor.pass.pdx[[i]] <- c(all.cor.pass.pdx[[i]], tmp)
        }
    }
    all.cor.pass.pdx[[i]] <- unique(all.cor.pass.pdx[[i]])
    ## Tumours vs PDXs
    all.cor.tum.pdx[[i]] <- c()
    sub.X <- X[which(X$Tumour==i),]
    sub.res <- res[,which(X$Tumour==i)]
    Tum <- which(sub.X$TYPE=="Tumour")
    PDX <- which(sub.X$TYPE=="PDTX")
    if (length(Tum)>0 & length(PDX)>0) {
        for (j in Tum) {
            tmp <- cor(sub.res[,j], sub.res[,PDX], use="pairwise.complete.obs", method="spearman")
            all.cor.tum.pdx[[i]] <- c(all.cor.tum.pdx[[i]], tmp)
        }
    }
    ## Tumours vs Tumours
    all.cor.tum.tum[[i]] <- c()
    Tum <- which(X$TYPE=="Tumour" & X$Tumour==i)
    Other <- which(X$TYPE=="Tumour" & X$Tumour!=i)
    if (length(Tum)>0) {
        for (j in Tum) {
            tmp <- cor(res[,j], res[,Other], use="pairwise.complete.obs", method="spearman")
            all.cor.tum.tum[[i]] <- c(all.cor.tum.tum[[i]], tmp)
        }
    }

}

all.cor.rep.pdx <- do.call("c", all.cor.rep.pdx)
all.cor.pass.pdx <- do.call("c", all.cor.pass.pdx)
all.cor.tum.pdx <- do.call("c", all.cor.tum.pdx)
all.cor.tum.tum <- do.call("c", all.cor.tum.tum)


## PDTCs
all.cor.pdtc.pdx <- c()
ids <- which(X$TYPE=="PDTC")
for (i in ids) {
    found <- which(X$Tumour==X$Tumour[i] & X$TYPE=="PDTX" & X$PASSAGE==X$PASSAGE[i])
    if (length(found)>0) {
        tmp <- cor(res[,i], res[,found], use="pairwise.complete.obs", method="spearman")
        print(tmp)
        all.cor.pdtc.pdx <- c(all.cor.pdtc.pdx, tmp)
    }
}
## Tumour (Technical replicate)
all.cor.tumour.tech <- NULL
ids <- X[grep("TR", X$ID),'Tumour']
for (i in ids) {
    found <- which(X$Tumour==i & X$TYPE=="Tumour")
    tmp <- cor(res[,found], use="pairwise.complete.obs", method="spearman")
    tmp <- tmp[row(tmp)>col(tmp)]
    all.cor.tumour.tech <- c(all.cor.tumour.tech, tmp)
}


boxplot(all.cor.tumour.tech, all.cor.pdtc.pdx, all.cor.rep.pdx,
        all.cor.pass.pdx, all.cor.tum.pdx, all.cor.tum.tum,
        names=c("Tech Replicates", "PDTCs vs PDXs", "Mice Replicates",
            "PDTXs Passages", "PDTX vs Tumour",
"Different Tumours"), ylab="Spearman Correlation",
                col=c("grey", "red", "yellow", "olivedrab", "orange", "darkblue"), cex.lab=1.2, cex.axis=1.2)
dev.off()



