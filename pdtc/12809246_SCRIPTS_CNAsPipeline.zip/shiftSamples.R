X <- read.table("CopyNumber/Shallow_STG143-X0_ordered.bam.picard.bam_QDNAseq.txt", header=TRUE, sep="\t")
rle(X[which(X$chromosome==7),6])
baseline <- which.max(rle(X[which(X$chromosome==7),6])$length)
baseline <- rle(X[which(X$chromosome==7),6])$values[baseline]
X[,5] <- X[,5] - baseline
X[,6] <- X[,6] - baseline
write.table(X, file="CopyNumberShifted/Shallow_STG143-X0_ordered.bam.picard.bam_QDNAseq.txt", sep="\t", row.names=F, quote=F)
X <- read.table("CopyNumber/Shallow_STG143-X2_ordered.bam.picard.bam_QDNAseq.txt", header=TRUE, sep="\t")
rle(X[which(X$chromosome==7),6])
baseline <- which.max(rle(X[which(X$chromosome==7),6])$length)
baseline <- rle(X[which(X$chromosome==7),6])$values[baseline]
X[,5] <- X[,5] - baseline
X[,6] <- X[,6] - baseline
write.table(X, file="CopyNumberShifted/Shallow_STG143-X2_ordered.bam.picard.bam_QDNAseq.txt", sep="\t", row.names=F, quote=F)
X <- read.table("CopyNumber/Shallow_STG143-X2R_ordered.bam.picard.bam_QDNAseq.txt", header=TRUE, sep="\t")
rle(X[which(X$chromosome==7),6])
baseline <- which.max(rle(X[which(X$chromosome==7),6])$length)
baseline <- rle(X[which(X$chromosome==7),6])$values[baseline]
X[,5] <- X[,5] - baseline
X[,6] <- X[,6] - baseline
write.table(X, file="CopyNumberShifted/Shallow_STG143-X2R_ordered.bam.picard.bam_QDNAseq.txt", sep="\t", row.names=F, quote=F)



X <- read.table("CopyNumber/Shallow_STG139-T_ordered.bam.picard.bam_QDNAseq.txt", header=TRUE, sep="\t")
rle(X[which(X$chromosome==1),6])
baseline <- rle(X[which(X$chromosome==1),6])$values[2]
X[,5] <- X[,5] - baseline
X[,6] <- X[,6] - baseline
write.table(X, file="CopyNumberShifted/Shallow_STG139-T_ordered.bam.picard.bam_QDNAseq.txt", sep="\t", row.names=F, quote=F)
X <- read.table("CopyNumber/Shallow_STG139-X12_ordered.bam.picard.bam_QDNAseq.txt", header=TRUE, sep="\t")
rle(X[which(X$chromosome==1),6])
baseline <- rle(X[which(X$chromosome==1),6])$values[2]
X[,5] <- X[,5] - baseline
X[,6] <- X[,6] - baseline
write.table(X, file="CopyNumberShifted/Shallow_STG139-X12_ordered.bam.picard.bam_QDNAseq.txt", sep="\t", row.names=F, quote=F)
X <- read.table("CopyNumber/Shallow_STG139-X13_ordered.bam.picard.bam_QDNAseq.txt", header=TRUE, sep="\t")
rle(X[which(X$chromosome==1),6])
baseline <- rle(X[which(X$chromosome==1),6])$values[2]
X[,5] <- X[,5] - baseline
X[,6] <- X[,6] - baseline
write.table(X, file="CopyNumberShifted/Shallow_STG139-X13_ordered.bam.picard.bam_QDNAseq.txt", sep="\t", row.names=F, quote=F)
X <- read.table("CopyNumber/Shallow_STG139-X14_ordered.bam.picard.bam_QDNAseq.txt", header=TRUE, sep="\t")
rle(X[which(X$chromosome==1),6])
baseline <- rle(X[which(X$chromosome==1),6])$values[2]
X[,5] <- X[,5] - baseline
X[,6] <- X[,6] - baseline
write.table(X, file="CopyNumberShifted/Shallow_STG139-X14_ordered.bam.picard.bam_QDNAseq.txt", sep="\t", row.names=F, quote=F)

X <- read.table("CopyNumber/Shallow_VHIO098-X10_ordered.bam.picard.bam_QDNAseq.txt", header=TRUE, sep="\t")
rle(X[which(X$chromosome==3),6])
baseline <- rle(X[which(X$chromosome==3),6])$values[which.max(rle(X[which(X$chromosome==3),6])$lengths)]
X[,5] <- X[,5] - baseline
X[,6] <- X[,6] - baseline
write.table(X, file="CopyNumberShifted/Shallow_VHIO098-X10_ordered.bam.picard.bam_QDNAseq.txt", sep="\t", row.names=F, quote=F)


X <- read.table("CopyNumber/Shallow_VHIO098-X11_ordered.bam.picard.bam_QDNAseq.txt", header=TRUE, sep="\t")
rle(X[which(X$chromosome==3),6])
baseline <- rle(X[which(X$chromosome==3),6])$values[which.max(rle(X[which(X$chromosome==3),6])$lengths)]
X[,5] <- X[,5] - baseline
X[,6] <- X[,6] - baseline
write.table(X, file="CopyNumberShifted/Shallow_VHIO098-X11_ordered.bam.picard.bam_QDNAseq.txt", sep="\t", row.names=F, quote=F)

X <- read.table("CopyNumber/Shallow_VHIO102-T_ordered.bam.picard.bam_QDNAseq.txt", header=TRUE, sep="\t")
rle(X[which(X$chromosome==2),6])
baseline <- rle(X[which(X$chromosome==2),6])$values[which.max(rle(X[which(X$chromosome==2),6])$lengths)]
X[,5] <- X[,5] - baseline
X[,6] <- X[,6] - baseline
write.table(X, file="CopyNumberShifted/Shallow_VHIO102-T_ordered.bam.picard.bam_QDNAseq.txt", sep="\t", row.names=F, quote=F)

X <- read.table("CopyNumber/Shallow_VHIO102-X7_ordered.bam.picard.bam_QDNAseq.txt", header=TRUE, sep="\t")
rle(X[which(X$chromosome==2),6])
baseline <- rle(X[which(X$chromosome==2),6])$values[which.max(rle(X[which(X$chromosome==2),6])$lengths)]
X[,5] <- X[,5] - baseline
X[,6] <- X[,6] - baseline
write.table(X, file="CopyNumberShifted/Shallow_VHIO102-X7_ordered.bam.picard.bam_QDNAseq.txt", sep="\t", row.names=F, quote=F)

X <- read.table("CopyNumber/Shallow_VHIO244-X4_ordered.bam.picard.bam_QDNAseq.txt", header=TRUE, sep="\t")
rle(X[which(X$chromosome==14),6])
baseline <- rle(X[which(X$chromosome==14),6])$values[which.max(rle(X[which(X$chromosome==14),6])$lengths)]
X[,5] <- X[,5] - baseline
X[,6] <- X[,6] - baseline
write.table(X, file="CopyNumberShifted/Shallow_VHIO244-X4_ordered.bam.picard.bam_QDNAseq.txt", sep="\t", row.names=F, quote=F)
X <- read.table("CopyNumber/Shallow_VHIO244-X3_ordered.bam.picard.bam_QDNAseq.txt", header=TRUE, sep="\t")
rle(X[which(X$chromosome==14),6])
baseline <- rle(X[which(X$chromosome==14),6])$values[which.max(rle(X[which(X$chromosome==14),6])$lengths)]
X[,5] <- X[,5] - baseline
X[,6] <- X[,6] - baseline
write.table(X, file="CopyNumberShifted/Shallow_VHIO244-X3_ordered.bam.picard.bam_QDNAseq.txt", sep="\t", row.names=F, quote=F)


## This one is only used for PyClone
X <- read.table("CopyNumber/Shallow_STG139-X0_ordered.bam.picard.bam_QDNAseq.txt", header=TRUE, sep="\t")
rle(X[which(X$chromosome==3),6])
baseline <- rle(X[which(X$chromosome==3),6])$values[4]
X[,5] <- X[,5] - baseline
X[,6] <- X[,6] - baseline
write.table(X, file="CopyNumberShifted/Shallow_STG139-X0_ordered.bam.picard.bam_QDNAseq.txt", sep="\t", row.names=F, quote=F)

X <- read.table("CopyNumber/Shallow_STG201-X0_ordered.bam.picard.bam_QDNAseq.txt", header=TRUE, sep="\t")
rle(X[which(X$chromosome==19),6])
baseline <- rle(X[which(X$chromosome==19),6])$values[which.max(rle(X[which(X$chromosome==19),6])$lengths)]
X[,5] <- X[,5] - baseline
X[,6] <- X[,6] - baseline
write.table(X, file="CopyNumberShifted/Shallow_STG201-X0_ordered.bam.picard.bam_QDNAseq.txt", sep="\t", row.names=F, quote=F)

X <- read.table("CopyNumber/Shallow_STG201-X2_ordered.bam.picard.bam_QDNAseq.txt", header=TRUE, sep="\t")
rle(X[which(X$chromosome==19),6])
baseline <- rle(X[which(X$chromosome==19),6])$values[which.max(rle(X[which(X$chromosome==19),6])$lengths)]
X[,5] <- X[,5] - baseline
X[,6] <- X[,6] - baseline
write.table(X, file="CopyNumberShifted/Shallow_STG201-X2_ordered.bam.picard.bam_QDNAseq.txt", sep="\t", row.names=F, quote=F)

X <- read.table("CopyNumber/Shallow_STG201-X3_ordered.bam.picard.bam_QDNAseq.txt", header=TRUE, sep="\t")
rle(X[which(X$chromosome==19),6])
baseline <- rle(X[which(X$chromosome==19),6])$values[which.max(rle(X[which(X$chromosome==19),6])$lengths)]
X[,5] <- X[,5] - baseline
X[,6] <- X[,6] - baseline
write.table(X, file="CopyNumberShifted/Shallow_STG201-X3_ordered.bam.picard.bam_QDNAseq.txt", sep="\t", row.names=F, quote=F)

X <- read.table("CopyNumber/Shallow_STG201-X6_ordered.bam.picard.bam_QDNAseq.txt", header=TRUE, sep="\t")
rle(X[which(X$chromosome==19),6])
baseline <- rle(X[which(X$chromosome==19),6])$values[which.max(rle(X[which(X$chromosome==19),6])$lengths)]
X[,5] <- X[,5] - baseline
X[,6] <- X[,6] - baseline
write.table(X, file="CopyNumberShifted/Shallow_STG201-X6_ordered.bam.picard.bam_QDNAseq.txt", sep="\t", row.names=F, quote=F)

X <- read.table("CopyNumber/Shallow_STG139M-T_ordered.bam.picard.bam_QDNAseq.txt", header=TRUE, sep="\t")
rle(X[which(X$chromosome==3),6])
baseline <- rle(X[which(X$chromosome==3),6])$values[which.max(rle(X[which(X$chromosome==3),6])$lengths)]
X[,5] <- X[,5] - baseline
X[,6] <- X[,6] - baseline
write.table(X, file="CopyNumberShifted/Shallow_STG139M-T_ordered.bam.picard.bam_QDNAseq.txt", sep="\t", row.names=F, quote=F)

X <- read.table("CopyNumber/Shallow_STG139M-X0_ordered.bam.picard.bam_QDNAseq.txt", header=TRUE, sep="\t")
rle(X[which(X$chromosome==3),6])
baseline <- rle(X[which(X$chromosome==3),6])$values[which.max(rle(X[which(X$chromosome==3),6])$lengths)]
X[,5] <- X[,5] - baseline
X[,6] <- X[,6] - baseline
write.table(X, file="CopyNumberShifted/Shallow_STG139M-X0_ordered.bam.picard.bam_QDNAseq.txt", sep="\t", row.names=F, quote=F)

X <- read.table("CopyNumber/Shallow_STG139M-X2_ordered.bam.picard.bam_QDNAseq.txt", header=TRUE, sep="\t")
rle(X[which(X$chromosome==3),6])
baseline <- rle(X[which(X$chromosome==3),6])$values[which.max(rle(X[which(X$chromosome==3),6])$lengths)]
baseline
X[,5] <- X[,5] - baseline
X[,6] <- X[,6] - baseline
write.table(X, file="CopyNumberShifted/Shallow_STG139M-X2_ordered.bam.picard.bam_QDNAseq.txt", sep="\t", row.names=F, quote=F)

X <- read.table("CopyNumber/Shallow_STG139M-X2R_ordered.bam.picard.bam_QDNAseq.txt", header=TRUE, sep="\t")
rle(X[which(X$chromosome==3),6])
baseline <- rle(X[which(X$chromosome==3),6])$values[which.max(rle(X[which(X$chromosome==3),6])$lengths)]
baseline
X[,5] <- X[,5] - baseline
X[,6] <- X[,6] - baseline
write.table(X, file="CopyNumberShifted/Shallow_STG139M-X2R_ordered.bam.picard.bam_QDNAseq.txt", sep="\t", row.names=F, quote=F)


X <- read.table("CopyNumber/Shallow_STG139M-X5_ordered.bam.picard.bam_QDNAseq.txt", header=TRUE, sep="\t")
rle(X[which(X$chromosome==3),6])
baseline <- rle(X[which(X$chromosome==3),6])$values[which.max(rle(X[which(X$chromosome==3),6])$lengths)]
baseline
X[,5] <- X[,5] - baseline
X[,6] <- X[,6] - baseline
write.table(X, file="CopyNumberShifted/Shallow_STG139M-X5_ordered.bam.picard.bam_QDNAseq.txt", sep="\t", row.names=F, quote=F)

X <- read.table("CopyNumber/Shallow_STG139M-X5R1_ordered.bam.picard.bam_QDNAseq.txt", header=TRUE, sep="\t")
rle(X[which(X$chromosome==3),6])
baseline <- rle(X[which(X$chromosome==3),6])$values[which.max(rle(X[which(X$chromosome==3),6])$lengths)]
baseline
X[,5] <- X[,5] - baseline
X[,6] <- X[,6] - baseline
write.table(X, file="CopyNumberShifted/Shallow_STG139M-X5R1_ordered.bam.picard.bam_QDNAseq.txt", sep="\t", row.names=F, quote=F)

X <- read.table("CopyNumber/Shallow_STG139M-X5R1C7_ordered.bam.picard.bam_QDNAseq.txt", header=TRUE, sep="\t")
rle(X[which(X$chromosome==3),6])
baseline <- rle(X[which(X$chromosome==3),6])$values[which.max(rle(X[which(X$chromosome==3),6])$lengths)]
baseline
X[,5] <- X[,5] - baseline
X[,6] <- X[,6] - baseline
write.table(X, file="CopyNumberShifted/Shallow_STG139M-X5R1C7_ordered.bam.picard.bam_QDNAseq.txt", sep="\t", row.names=F, quote=F)

X <- read.table("CopyNumber/Shallow_STG139M-X5R1C10_ordered.bam.picard.bam_QDNAseq.txt", header=TRUE, sep="\t")
rle(X[which(X$chromosome==3),6])
baseline <- rle(X[which(X$chromosome==3),6])$values[which.max(rle(X[which(X$chromosome==3),6])$lengths)]
baseline
X[,5] <- X[,5] - baseline
X[,6] <- X[,6] - baseline
write.table(X, file="CopyNumberShifted/Shallow_STG139M-X5R1C10_ordered.bam.picard.bam_QDNAseq.txt", sep="\t", row.names=F, quote=F)


## All VHIO124
setwd("CopyNumberRevision/")
allF <- dir(pattern=".txt")
allF <- allF[grep("VHIO124", allF)]
for (i in allF) {
    X <- read.table(i, header=TRUE, sep="\t")
    tmp <- X[which(X$chromosome==1 & X$start>203000000),6]
    baseline <- mean(tmp)
    X[,5] <- X[,5] - baseline
    X[,6] <- X[,6] - baseline
    write.table(X, file=paste("ALLCOPYNUMBER/", i, sep=""), sep="\t", row.names=F, quote=F)
}
i <- "Shallow_VHIO124-X15_ordered.bam.picard.bam_QDNAseq.txt"
X <- read.table(paste("CopyNumberShifted/", i, sep=""), header=TRUE, sep="\t")
rle(X[which(X$chromosome==1),6])
    tmp <- X[which(X$chromosome==1 & X$start>203000000),6]
    baseline <- mean(tmp)
X[,5] <- X[,5] - baseline
X[,6] <- X[,6] - baseline
write.table(X, file=paste("ALLCOPYNUMBER/", i, sep=""), sep="\t", row.names=F, quote=F)

setwd("ALLBAM/")
sample.files <- dir(pattern=".bam$")
sample.files <- sample.files[grep("VHIO124", sample.files)][1:2]
binSize <- 100
library(QDNAseq)
library(Biobase)
bins <- getBinAnnotations(binSize=binSize)
for (i in sample.files)  {
    sample.name <- i
    x <- binReadCounts(bins, bamfiles=i)
    x.f <- applyFilters(x, residual=TRUE, blacklist=TRUE, chromosomes="Y")
    x.f <- estimateCorrection(x.f)
    cn <- correctBins(x.f)
    cn <- normalizeBins(cn)
    cn <- smoothOutlierBins(cn)
    cn <- segmentBins(cn, transformFun="sqrt")
    cn <- normalizeSegmentedBins(cn)
    corrected <- read.table(file=paste("ALLCOPYNUMBER/", sample.name, "_QDNAseq.txt", sep=""), sep="\t", header=T)
    mean(names(assayDataElement(cn, "segmented")[which(!is.na(assayDataElement(cn, "segmented"))),]) == corrected[,1])
    assayDataElement(cn, "segmented")[which(!is.na(assayDataElement(cn, "segmented")))] <- I(2 ^ corrected[,6])
    assayDataElement(cn, "copynumber")[which(!is.na(assayDataElement(cn, "copynumber")))] <- I(2 ^ corrected[,5])
    pdf(paste("ALLCOPYNUMBER/",
								   sample.name, "_QDNAseq.pdf", sep=""), width=12, height=6)
    plot(cn)
    dev.off()
}

SS <- read.table("/Volumes/BAM_PDX/ExomeV3/SampleSheetExomes_V3.txt", header=T, sep="\t")
SS[grep("VHIO124", SS$Tumour),'ID']
SS$Name <- gsub(" ", "_", SS$Name, fixed=T)
SS$Name <- gsub("(", "_", SS$Name, fixed=T)
SS$Name <- gsub(")", "_", SS$Name, fixed=T)
SS$Name <- gsub("/", "_", SS$Name, fixed=T)

for (i in SS[grep("VHIO124", SS$Tumour),'ID']) {
    sample.name <- i
    bam <- SS$Name[which(SS$ID==i)]
    bam <- paste("ALLBAM/Shallow_", bam, "_ordered.bam.picard.bam", sep="")
    if (file.exists(bam)) {
    x <- binReadCounts(bins, bamfiles=bam)
    x.f <- applyFilters(x, residual=TRUE, blacklist=TRUE, chromosomes="Y")
    x.f <- estimateCorrection(x.f)
    cn <- correctBins(x.f)
    cn <- normalizeBins(cn)
    cn <- smoothOutlierBins(cn)
    cn <- segmentBins(cn, transformFun="sqrt")
    cn <- normalizeSegmentedBins(cn)
    corrected <- read.table(file=paste("ALLCOPYNUMBER/Shallow_", sample.name, "_ordered.bam.picard.bam_QDNAseq.txt", sep=""), sep="\t", header=T)
    mean(names(assayDataElement(cn, "segmented")[which(!is.na(assayDataElement(cn, "segmented"))),]) == corrected[,1])
    assayDataElement(cn, "segmented")[which(!is.na(assayDataElement(cn, "segmented")))] <- I(2 ^ corrected[,6])
    assayDataElement(cn, "copynumber")[which(!is.na(assayDataElement(cn, "copynumber")))] <- I(2 ^ corrected[,5])
    pdf(paste("ALLCOPYNUMBER/Shallow_",
								   sample.name, "_ordered.bam.picard.bam_QDNAseq.pdf", sep=""), width=12, height=6)
    plot(cn)
    dev.off()
} else{
    cat(i, " not found\n")
}

}
}


################################################################
################################################################
## We need to plot these samples
################################################################
################################################################
setwd("BAMShallow/")
sample.files <- dir(pattern=".bam$")
sample.files <- sample.files[c(52, 53, 54, 55, 56, 60:66, 78:81,107)]
binSize <- 100
library(QDNAseq)
library(Biobase)
bins <- getBinAnnotations(binSize=binSize)
for (i in sample.files)  {
    sample.name <- i
    x <- binReadCounts(bins, bamfiles=i)
    x.f <- applyFilters(x, residual=TRUE, blacklist=TRUE, chromosomes="Y")
    x.f <- estimateCorrection(x.f)
    cn <- correctBins(x.f)
    cn <- normalizeBins(cn)
    cn <- smoothOutlierBins(cn)
    cn <- segmentBins(cn, transformFun="sqrt")
    cn <- normalizeSegmentedBins(cn)
    corrected <- read.table(file=paste("CopyNumberShifted/", sample.name, "_QDNAseq.txt", sep=""), sep="\t", header=T)
    mean(names(assayDataElement(cn, "segmented")[which(!is.na(assayDataElement(cn, "segmented"))),]) == corrected[,1])
    assayDataElement(cn, "segmented")[which(!is.na(assayDataElement(cn, "segmented")))] <- I(2 ^ corrected[,6])
    assayDataElement(cn, "copynumber")[which(!is.na(assayDataElement(cn, "copynumber")))] <- I(2 ^ corrected[,5])
    pdf(paste("CopyNumberShifted/",
								   sample.name, "_QDNAseq.pdf", sep=""), width=12, height=6)
    plot(cn)
    dev.off()
}

######################################################################
######################################################################
## Correlation Now with Copy Number
######################################################################
######################################################################

setwd("CopyNumberShifted/")
allF <- dir(pattern=".txt")
nams <- sub("_ordered.bam.picard.bam_QDNAseq.txt", "", allF, fixed=TRUE)
nams <- sub("Shallow_", "", nams, fixed=TRUE)

res <- NULL
for (i in 1:length(nams)) {
    tmp <- read.table(allF[i], header=TRUE, sep="\t")
    res <- cbind(res, tmp[,6])
}
colnames(res) <- nams

## Let's remove ugly regions
feo <- apply(res, 1, function(x) mean(x < -10, na.rm=T))
res[which(feo>0.9),] <- NA
res[which(res < -10)] <- -10

## Let's remove ugly samples: less than 2,000,000 reads
bads <- c("AB551-X0R", "AB569-X1" ,"AB569-XC7",
          "HC1", "HC2", "HC3", "HCI011-XC", "NORMAL",
          "STG139-X0", "STG235-X1", "STG235-X2",
          "STG335-X4C7", "VHIO136-X14", "VHIO136-X15")
res <- res[,-which(colnames(res) %in% bads)]

SS <- read.table("/Volumes/CLUS_BACKUP/PDX/PDX/Shallow/SampleSheetShallow.txt", header=TRUE, sep="\t", stringsAsFactors=F)
res <- res[, which(colnames(res) %in% SS$ID[which(SS$Include=="YES")])]
X <- SS[which(SS$ID %in% colnames(res)),]
X$TYPE <- X$Type
X <- X[match(colnames(res), X$ID),]

## Correct for contamination

load("/Volumes/PDX/Exomes/NormalContamination.RData")

for (i in names(all.est)) {
    ids <- which(colnames(res)==i)
    if (length(ids) > 0) {
    x <- 2^res[,ids]
    y <- (x - (1-all.est[i])) / all.est[i]
    y[which(y<=0)] <- 1e-4
    y <- log2(y)
    res[,ids] <- y
    }
}


all.cor.rep.pdx <- list()
all.cor.pass.pdx <- list()
all.cor.tum.pdx <- list()
all.cor.tum.tum <- list()

for (i in unique(X$Tumour)) {
    ## Replicate PDXs
    all.cor.rep.pdx[[i]] <- c()
    sub.X <- X[which(X$Tumour==i),]
    sub.res <- res[,which(X$Tumour==i)]
    PDX <- which(sub.X$TYPE=="PDTX")
    for (j in PDX) {
        ids <- which(sub.X$TYPE=="PDTX" & sub.X$PASSAGE==sub.X$PASSAGE[j])
        if (length(ids) > 1) {
            tmp <- cor(sub.res[,ids], use="pairwise.complete.obs", method="pearson")
            tmp <- tmp[row(tmp)>col(tmp)]
            all.cor.rep.pdx[[i]] <- c(all.cor.rep.pdx[[i]], tmp)
        }
    }
    all.cor.rep.pdx[[i]] <- unique(all.cor.rep.pdx[[i]])
    ## Different PDXs passages
    all.cor.pass.pdx[[i]] <- c()
    sub.X <- X[which(X$Tumour==i),]
    sub.res <- res[,which(X$Tumour==i)]
    PDX <- which(sub.X$TYPE=="PDTX")
    for (j in PDX) {
        ids <- which(sub.X$PASSAGE!=sub.X$PASSAGE[j])
        if (length(ids) > 1) {
            tmp <- cor(sub.res[,ids], use="pairwise.complete.obs", method="pearson")
            tmp <- tmp[row(tmp)>col(tmp)]
            all.cor.pass.pdx[[i]] <- c(all.cor.pass.pdx[[i]], tmp)
        }
    }
    all.cor.pass.pdx[[i]] <- unique(all.cor.pass.pdx[[i]])
    ## Tumours vs PDXs
    all.cor.tum.pdx[[i]] <- c()
    sub.X <- X[which(X$Tumour==i),]
    sub.res <- res[,which(X$Tumour==i)]
    Tum <- which(sub.X$TYPE=="Tumour")
    PDX <- which(sub.X$TYPE=="PDTX")
    if (length(Tum)>0 & length(PDX)>0) {
        for (j in Tum) {
            tmp <- cor(sub.res[,j], sub.res[,PDX], use="pairwise.complete.obs", method="pearson")
            all.cor.tum.pdx[[i]] <- c(all.cor.tum.pdx[[i]], tmp)
        }
    }
    ## Tumours vs Tumours
    all.cor.tum.tum[[i]] <- c()
    Tum <- which(X$TYPE=="Tumour" & X$Tumour==i)
    Other <- which(X$TYPE=="Tumour" & X$Tumour!=i)
    if (length(Tum)>0) {
        for (j in Tum) {
            tmp <- cor(res[,j], res[,Other], use="pairwise.complete.obs", method="pearson")
            all.cor.tum.tum[[i]] <- c(all.cor.tum.tum[[i]], tmp)
        }
    }

}

all.cor.rep.pdx <- do.call("c", all.cor.rep.pdx)
all.cor.pass.pdx <- do.call("c", all.cor.pass.pdx)
all.cor.tum.pdx <- do.call("c", all.cor.tum.pdx)
all.cor.tum.tum <- do.call("c", all.cor.tum.tum)

## PDTCs
all.cor.pdtc.pdx <- c()
ids <- which(X$TYPE=="PDTC")
for (i in ids) {
    found <- which(X$Tumour==X$Tumour[i] & X$TYPE=="PDTX" & X$PASSAGE==X$PASSAGE[i])
    if (length(found)>0) {
        tmp <- cor(res[,i], res[,found], use="pairwise.complete.obs", method="pearson")
    all.cor.pdtc.pdx <- c(all.cor.pdtc.pdx, tmp)
    }
}

## Tumour (Technical replicate)
all.cor.tumour.tech <- c()
ids <- X[grep("TR", X$ID),'Tumour']
for (i in ids) {
    found <- which(X$Tumour==i & X$TYPE=="Tumour")
    tmp <- cor(res[,found], use="pairwise.complete.obs", method="pearson")
    tmp <- tmp[row(tmp)>col(tmp)]
    all.cor.tumour.tech <- c(all.cor.tumour.tech, tmp)
}


pdf("Correlation_CN.pdf", width=12, height=9)
boxplot(all.cor.tumour.tech, all.cor.pdtc.pdx,
all.cor.rep.pdx, all.cor.pass.pdx, all.cor.tum.pdx, all.cor.tum.tum,
        names=c("Tech. Replicates", "PDTCs vs PDXs", "Mice Replicates",
            "PDTXs Passages", "PDTX vs Tumour", "Different Tumours"), ylab="Pearson Correlation",
                col=c("grey", "red", "yellow", "olivedrab", "orange", "darkblue"), cex.lab=1.2, cex.axis=1.2)

## Spearman

all.cor.rep.pdx <- list()
all.cor.pass.pdx <- list()
all.cor.tum.pdx <- list()
all.cor.tum.tum <- list()

for (i in unique(X$Tumour)) {
    ## Replicate PDXs
    all.cor.rep.pdx[[i]] <- c()
    sub.X <- X[which(X$Tumour==i),]
    sub.res <- res[,which(X$Tumour==i)]
    PDX <- which(sub.X$TYPE=="PDTX")
    for (j in PDX) {
        ids <- which(sub.X$PASSAGE==sub.X$PASSAGE[j])
        if (length(ids) > 1) {
            tmp <- cor(sub.res[,ids], use="pairwise.complete.obs", method="spearman")
            tmp <- tmp[row(tmp)>col(tmp)]
            all.cor.rep.pdx[[i]] <- c(all.cor.rep.pdx[[i]], tmp)
        }
    }
    all.cor.rep.pdx[[i]] <- unique(all.cor.rep.pdx[[i]])
    ## Different PDXs passages
    all.cor.pass.pdx[[i]] <- c()
    sub.X <- X[which(X$Tumour==i),]
    sub.res <- res[,which(X$Tumour==i)]
    PDX <- which(sub.X$TYPE=="PDTX")
    for (j in PDX) {
        ids <- which(sub.X$PASSAGE!=sub.X$PASSAGE[j])
        if (length(ids) > 1) {
            tmp <- cor(sub.res[,ids], use="pairwise.complete.obs", method="spearman")
            tmp <- tmp[row(tmp)>col(tmp)]
            all.cor.pass.pdx[[i]] <- c(all.cor.pass.pdx[[i]], tmp)
        }
    }
    all.cor.pass.pdx[[i]] <- unique(all.cor.pass.pdx[[i]])
    ## Tumours vs PDXs
    all.cor.tum.pdx[[i]] <- c()
    sub.X <- X[which(X$Tumour==i),]
    sub.res <- res[,which(X$Tumour==i)]
    Tum <- which(sub.X$TYPE=="Tumour")
    PDX <- which(sub.X$TYPE=="PDTX")
    if (length(Tum)>0 & length(PDX)>0) {
        for (j in Tum) {
            tmp <- cor(sub.res[,j], sub.res[,PDX], use="pairwise.complete.obs", method="spearman")
            all.cor.tum.pdx[[i]] <- c(all.cor.tum.pdx[[i]], tmp)
        }
    }
    ## Tumours vs Tumours
    all.cor.tum.tum[[i]] <- c()
    Tum <- which(X$TYPE=="Tumour" & X$Tumour==i)
    Other <- which(X$TYPE=="Tumour" & X$Tumour!=i)
    if (length(Tum)>0) {
        for (j in Tum) {
            tmp <- cor(res[,j], res[,Other], use="pairwise.complete.obs", method="spearman")
            all.cor.tum.tum[[i]] <- c(all.cor.tum.tum[[i]], tmp)
        }
    }

}

all.cor.rep.pdx <- do.call("c", all.cor.rep.pdx)
all.cor.pass.pdx <- do.call("c", all.cor.pass.pdx)
all.cor.tum.pdx <- do.call("c", all.cor.tum.pdx)
all.cor.tum.tum <- do.call("c", all.cor.tum.tum)


## PDTCs
all.cor.pdtc.pdx <- c()
ids <- which(X$TYPE=="PDTC")
for (i in ids) {
    found <- which(X$Tumour==X$Tumour[i] & X$TYPE=="PDTX" & X$PASSAGE==X$PASSAGE[i])
    if (length(found)>0) {
        tmp <- cor(res[,i], res[,found], use="pairwise.complete.obs", method="spearman")
        print(tmp)
        all.cor.pdtc.pdx <- c(all.cor.pdtc.pdx, tmp)
    }
}
## Tumour (Technical replicate)
all.cor.tumour.tech <- NULL
ids <- X[grep("TR", X$ID),'Tumour']
for (i in ids) {
    found <- which(X$Tumour==i & X$TYPE=="Tumour")
    tmp <- cor(res[,found], use="pairwise.complete.obs", method="spearman")
    tmp <- tmp[row(tmp)>col(tmp)]
    all.cor.tumour.tech <- c(all.cor.tumour.tech, tmp)
}


boxplot(all.cor.tumour.tech, all.cor.pdtc.pdx, all.cor.rep.pdx,
        all.cor.pass.pdx, all.cor.tum.pdx, all.cor.tum.tum,
        names=c("Tech Replicates", "PDTCs vs PDXs", "Mice Replicates",
            "PDTXs Passages", "PDTX vs Tumour",
"Different Tumours"), ylab="Spearman Correlation",
                col=c("grey", "red", "yellow", "olivedrab", "orange", "darkblue"), cex.lab=1.2, cex.axis=1.2)
dev.off()

## joinCopyNumber

setwd("CopyNumberShifted/")
allF <- dir(pattern=".txt")
nams <- sub("_ordered.bam.picard.bam_QDNAseq.txt", "", allF, fixed=TRUE)
nams <- sub("Shallow_", "", nams, fixed=TRUE)

res <- NULL
for (i in 1:length(nams)) {
    tmp <- read.table(allF[i], header=TRUE, sep="\t")
    res <- cbind(res, tmp[,6])
}
colnames(res) <- nams

## Let's remove ugly regions
feo <- apply(res, 1, function(x) mean(x < -10, na.rm=T))
res[which(feo>0.9),] <- NA
res[which(res < -10)] <- -10

## Let's remove ugly samples: less than 2,000,000 reads
bads <- c("AB551-X0R", "AB569-X1" ,"AB569-XC7",
          "HC1", "HC2", "HC3", "HCI011-XC", "NORMAL",
          "STG139-X0", "STG235-X1", "STG235-X2",
          "STG335-X4C7", "VHIO136-X14", "VHIO136-X15")

res.merged <- NULL
Pos <- read.table(allF[1], header=TRUE, sep="\t")
Chrom <- Pos$chromosome
Start <- Pos$start
End <- Pos$end

for (i in 1:length(nams)) {
    tmp <- res[,i,drop=F]
    for (chr in unique(Chrom)) {
	rle.merged <- rle(tmp[Chrom==chr,1])
	loc.start <- c(1, cumsum(rle.merged$length) + 1)
	loc.start <- loc.start[-length(loc.start)]
	loc.start <- Start[Chrom==chr][loc.start]
	loc.end <- End[Chrom==chr][cumsum(rle.merged$length)]
	num.mark <- rle.merged$lengths
	seg.mean <- rle.merged$values
	ID <- rep(nams[i], length(seg.mean))
	chrom <- Chrom[Chrom==chr][cumsum(rle.merged$length)]
	x <- data.frame(ID, chrom, loc.start, loc.end, num.mark, seg.mean)
        res.merged <- rbind(res.merged, x)
 	}
    cat(i, " done\n")
}
res.merged$chrom <- factor(res.merged$chrom, levels=c(1:22, "X"))
res.merged <- res.merged[order(res.merged$ID, res.merged$chrom, res.merged$loc.start),]
res.merged <- res.merged[which(!is.na(res.merged$seg.mean)),]
write.table(res.merged, file="CNAllSamples.seg", row.names=F, quote=F, sep="\t")

SS <- read.table("/Volumes/CLUS_BACKUP/PDX/PDX/Shallow/SampleSheetShallow.txt", header=TRUE, sep="\t")
ids <- which(res.merged$ID %in% SS$ID[which(SS$Include=="YES")])
feo <- res.merged[ids,]
feo <- feo[-which(feo$ID %in% bads),]
write.table(feo, file="CNA_GoodSamples.seg", row.names=F, quote=F, sep="\t")


load("/Volumes/PDX/Exomes/NormalContamination.RData")

for (i in names(all.est)) {
    ids <- which(res.merged$ID==i)
    if (length(ids) > 0) {
    x <- 2^res.merged$seg.mean[ids]
    y <- (x - (1-all.est[i])) / all.est[i]
    y[which(y<=0)] <- 1e-4
    y <- log2(y)
    res.merged$seg.mean[ids] <- y
    }
}
write.table(res.merged, file="CNAllSamplesContaminationCorrected.seg", row.names=F, quote=F, sep="\t")

for (i in names(all.est)) {
    ids <- which(feo$ID==i)
    if (length(ids) > 0) {
    x <- 2^feo$seg.mean[ids]
    y <- (x - (1-all.est[i])) / all.est[i]
    y[which(y<=0)] <- 1e-4
    y <- log2(y)
    feo$seg.mean[ids] <- y
    }
}
write.table(feo, file="CNA_GoodSamplesContaminationCorrected.seg", row.names=F, quote=F, sep="\t")

## callCopyNumber

CNA <- read.table(file="CNA_GoodSamplesContaminationCorrected.seg", header=TRUE, sep="\t")
CNA$call <- NA
CNA$call2 <- NA
for (i in unique(CNA$ID)) {
    x.log <- rep(CNA$seg.mean[which(CNA$ID==i)],
                 CNA$num.mark[which(CNA$ID==i)])
    thr <- c(-1, -0.4, 0.25, 0.75)
    CNA$call[CNA$ID == i] <- 1 * (CNA$seg.mean[CNA$ID ==
             i] > thr[3]) -1 *
    (CNA$seg.mean[CNA$ID == i] < thr[2])
    CNA$call2[CNA$ID == i] <- 1 * (CNA$seg.mean[CNA$ID == i] > thr[3]) +
      1 * (CNA$seg.mean[CNA$ID == i] > thr[4]) -1 *
    (CNA$seg.mean[CNA$ID == i] < thr[2]) -1 *
    (CNA$seg.mean[CNA$ID == i] < thr[1])
}


write.table(CNA, file="CNACalls_GoodSamplesContaminationCorrected.txt", row.names=F, quote=F, sep="\t")

## Now we make files per gene

refseq <- read.table("refseqGenes.txt", header=FALSE, sep="\t", stringsAsFactors=F)
refseq <- refseq[which(refseq$V3 %in% paste("chr", c(1:22, "X"), sep="")),]
refseq <- split(refseq, refseq$V13)
refseq <- lapply(refseq, function(x) {
                 data.frame(x$V13[1],x$V3[1],
                            min(x$V5), max(x$V6))
             })

refseq <- do.call("rbind", refseq)
colnames(refseq) <- c("Symbol", "Chrom", "Start", "End")
refseq$Chrom <- factor(refseq$Chrom,
                       levels=paste("chr", c(1:22, "X"),
                       sep=""))
refseq <- refseq[order(refseq$Chrom, refseq$Start),]

SS <- read.table("/Volumes/CLUS_BACKUP/PDX/PDX/Shallow/SampleSheetShallow.txt", header=TRUE, sep="\t")
SS <- SS[which(SS$ID %in% CNA$ID),]
GENE.CN <- matrix(NA, nrow(refseq),
                  length(unique(CNA$ID)))
for (i in 1:nrow(refseq)) {
    x <- subset(CNA, chrom==sub("chr", "",
                     refseq$Chrom[i]) &
                ((loc.start >= refseq$Start[i] &
                  loc.start <= refseq$End[i]) |
                 (loc.start <= refseq$Start[i] &
                  loc.end >= refseq$Start[i])))
    if (nrow(x) > 0) {
        res <- sapply(split(x, x$ID), function(x) {
            if (nrow(x)>0) {
          c(any(x$call==-1), any(x$call==1))
    }else {
          c(NA, NA)
      }
        })
        res <- apply(res, 2, function(x) {
            if (any(is.na(x))) {
                NA
            } else if (!x[1] & !x[2]) {
              "NEUT"
          } else if (x[1] & !x[2]) {
              "LOSS"
          } else if (!x[1] & x[2]) {
              "GAIN"
          } else if (x[1] & x[2]) {
              "LOSS/GAIN"
          }
      })
        if (length(res) != ncol(GENE.CN)) stop()
        GENE.CN[i,] <- res
    }
    cat("i=", i, "\n")
}
rownames(GENE.CN) <- refseq$Symbol
colnames(GENE.CN) <- names(res)

save(GENE.CN, file="GENE.CN.RData")


GENE.CN.MODEL <- NULL
Valid <- names(which(table(SS$Tumour[which(SS$Type %in% c("PDTX", "PDTC"))])>0))
for (i in Valid) {
    ids <- as.character(SS$ID[which(SS$Tumour == i & SS$Type %in%  c("PDTX", "PDTC"))])
    res <- apply(GENE.CN[,ids,drop=F], 1, function(x) {
        if (mean(is.na(x))<1) {
        if(mean(x=="GAIN", na.rm=T) > 0.5) {
              "GAIN"
          } else if(mean(x=="LOSS", na.rm=T) > 0.5) {
              "LOSS"
          } else if(mean(x=="NEUT", na.rm=T) > 0.5) {
              "NEUT"
          } else {
              'UNKNOWN'
          }
          } else {
              NA
          }
      })
    GENE.CN.MODEL <- cbind(GENE.CN.MODEL, res)
}
colnames(GENE.CN.MODEL) <- Valid

GENE.CN.MODEL <- data.frame(GENE.CN.MODEL)
GENE.CN.MODEL$Symbol <- rownames(GENE.CN.MODEL)
GENE.CN.MODEL <- GENE.CN.MODEL[,c(ncol(GENE.CN.MODEL), c(1:(ncol(GENE.CN.MODEL)-1)))]
write.table(GENE.CN.MODEL,
            file="GENECNMODEL.txt", row.names=F, sep="\t", quote=F)

ids <- which(GENE.CN.MODEL[,1] %in% c("ZNF703", "MYC", "CCND1", "MDM2", "ERBB2", "CCNE1"))
ids <- apply(GENE.CN.MODEL[ids,-1], 1, function(x) mean(x=="GAIN"))
names(ids) <- c("ZNF703", "MYC", "CCND1", "MDM2", "ERBB2", "CCNE1")
ids <- which(GENE.CN.MODEL[,1] %in% c("PTEN", "PPP2R2A", "CDKN2A", "CDKN2B"))
ids <- apply(GENE.CN.MODEL[ids,-1], 1, function(x) mean(x=="LOSS"))
names(ids) <- c("PTEN", "PPP2R2A", "CDKN2A", "CDKN2B")



GENE.CN.TUMOUR <- NULL
Valid <- names(which(table(SS$Tumour[which(SS$Type %in% c("Tumour"))])>0))
for (i in Valid) {
    ids <- as.character(SS$ID[which(SS$Tumour == i & SS$Type %in%  c("Tumour"))])
    res <- apply(GENE.CN[,ids,drop=F], 1, function(x) {
        if (mean(is.na(x))<1) {
        if(mean(x=="GAIN", na.rm=T) > 0.5) {
              "GAIN"
          } else if(mean(x=="LOSS", na.rm=T) > 0.5) {
              "LOSS"
          } else if(mean(x=="NEUT", na.rm=T) > 0.5) {
              "NEUT"
          } else {
              NA
          }
          } else {
              NA
          }
      })
    GENE.CN.TUMOUR <- cbind(GENE.CN.TUMOUR, res)
}
colnames(GENE.CN.TUMOUR) <- Valid

GENE.CN.TUMOUR <- data.frame(GENE.CN.TUMOUR)
GENE.CN.TUMOUR$Symbol <- rownames(GENE.CN.TUMOUR)
GENE.CN.TUMOUR <- GENE.CN.TUMOUR[,c(ncol(GENE.CN.TUMOUR), c(1:(ncol(GENE.CN.TUMOUR)-1)))]
write.table(GENE.CN.TUMOUR,
            file="GENECNTUMOUR.txt", row.names=F, sep="\t", quote=F)


## checkQDNAShift
## QDNASEQ may shift the logratios: let's check
load(file="GENE.CN.RData")
Tumour <- sapply(strsplit(colnames(GENE.CN), "-", fixed=TRUE),
                 function(x) x[1])
all.lev <- c("HOMD", "HETD", "NEUT", "GAIN", "AMP")
all.scores <- list()
for (i in unique(Tumour)) {
    x <- GENE.CN[,which(Tumour==i),drop=FALSE]
    if (ncol(x) >= 2) {
        all.scores[[i]] <- matrix(1, ncol(x), ncol(x))
        for (j in 1:ncol(x)) {
            for (k in (1:ncol(x))[-j]) {
                tmp <- table(factor(x[,j], levels=all.lev),
                             factor(x[,k], levels=all.lev))
                tmp <- sum(diag(tmp)) / sum(tmp)
                all.scores[[i]][j,k] <- tmp
                all.scores[[i]][k,j] <- tmp
            }
        }
        rownames(all.scores[[i]]) <- colnames(x)
        colnames(all.scores[[i]]) <- colnames(x)
    }
}

x <- GENE.CN[,which(Tumour %in% c("STG139", "STG139M")),drop=FALSE]
i <- "ALLSTG139"
if (ncol(x) > 2) {
    all.scores[[i]] <- matrix(1, ncol(x), ncol(x))
    for (j in 1:ncol(x)) {
        for (k in (1:ncol(x))[-j]) {
            tmp <- table(factor(x[,j], levels=all.lev),
                         factor(x[,k], levels=all.lev))
            tmp <- sum(diag(tmp)) / sum(tmp)
            all.scores[[i]][j,k] <- tmp
            all.scores[[i]][k,j] <- tmp
        }
    }
    rownames(all.scores[[i]]) <- colnames(x)
    colnames(all.scores[[i]]) <- colnames(x)
    }


## Outliers:
## STG282-X1 is very different
## VHIO089 is difficult to know
## STG139 needs some shifting


pdf("AgreementCN.pdf", width=8, height=8)
par(oma=c(6,6,2,2))
library(RColorBrewer)
all.col <- c(brewer.pal(8, "Reds"))
breaks <- seq(from=-0.01, to=1.01, length=9)
for (i in 1:length(all.scores)) {
    image(all.scores[[i]],
          breaks=breaks, col=all.col, axes=F,
          main=names(all.scores)[[i]])
    x.ticks <- seq(from=0, to=1, length=ncol(all.scores[[i]]))
    y.ticks <- seq(from=0, to=1, length=ncol(all.scores[[i]]))
    axis(1, at=x.ticks, labels=colnames(all.scores[[i]]),
         cex.axis=1.2, las=2)
    axis(2, at=y.ticks, labels=colnames(all.scores[[i]]),
         cex.axis=1.2, las=2)
    box()
}
dev.off()




## Now let's do a heatmap

sample.names <- colnames(all.scores[['ALLSTG139']])
sample.names <- sample.names[-grep("-N", sample.names, fixed=TRUE)]
CNA <- read.table(file="CNACalls_GoodSamplesContaminationCorrected.txt", header=TRUE, sep="\t")
CNA <- CNA[which(CNA$ID %in% sample.names),]
CNA$ID <- factor(CNA$ID)
Calls <- sapply(split(CNA, CNA$ID), function(x) rep(x$call, x$num.mark))

setwd("CopyNumberShifted/")
allF <- dir(pattern=".txt")
nams <- sub("_ordered.bam.picard.bam_QDNAseq.txt", "", allF, fixed=TRUE)
nams <- sub("Shallow_", "", nams, fixed=TRUE)

res <- NULL
for (i in 1:length(nams)) {
    tmp <- read.table(allF[i], header=TRUE, sep="\t")
    res <- cbind(res, tmp[,6])
}
colnames(res) <- nams
rownames(res) <- tmp$feature
## Let's remove ugly regions
feo <- apply(res, 1, function(x) mean(x < -10, na.rm=T))
res[which(feo>0.9),] <- NA
res[which(res < -10)] <- -10
res <- res[which(!is.na(res[,1])),]
geneNames <- rownames(res)

rownames(Calls) <- geneNames
desv <-  apply(Calls, 1, function(x) max(table(x)))
sub.Calls <- Calls[which(desv <=10),]

feo <- hclust(dist(t(sub.Calls)))
cutree(feo, 3)
plot(hclust(dist(t(sub.Calls))))

breaks <- c(-1.1, -0.5, 0.5, 1.1)
cols <- c("blue", "black", "red")
## heatmap(sub.tmp, col=cols, breaks, breaks, scale="none")

library(biclust)
test <- biclust(sub.Calls, method=BCPlaid())

biclustbarchart(sub.Calls, test)

C1 <- bicluster(sub.Calls, test, 1)[[1]]
C1 <- data.frame(C1)
C1 <- apply(C1, 1, function(x) names(which.max(table(x))))
pos <- names(C1)
tmp <- strsplit(pos, ":")
Chrom <- sapply(tmp, function(x) x[1])
tmp <- strsplit(sapply(tmp, function(x) x[2]), "-")
Start <- as.numeric(sapply(tmp, function(x) x[1]))
End <- as.numeric(sapply(tmp, function(x) x[2]))
C1 <- data.frame(Chrom, Start, End, X=C1)

C2 <- bicluster(sub.Calls, test, 2)[[1]]
C2 <- data.frame(C2)
C2 <- apply(C2, 1, function(x) names(which.max(table(x))))
pos <- names(C2)
tmp <- strsplit(pos, ":")
Chrom <- sapply(tmp, function(x) x[1])
tmp <- strsplit(sapply(tmp, function(x) x[2]), "-")
Start <- as.numeric(sapply(tmp, function(x) x[1]))
End <- as.numeric(sapply(tmp, function(x) x[2]))
C2 <- data.frame(Chrom, Start, End, X=C2)

C3 <- bicluster(sub.Calls, test, 3)[[1]]
C3 <- data.frame(C3)
C3 <- apply(C3, 1, function(x) names(which.max(table(x))))
pos <- names(C3)
tmp <- strsplit(pos, ":")
Chrom <- sapply(tmp, function(x) x[1])
tmp <- strsplit(sapply(tmp, function(x) x[2]), "-")
Start <- as.numeric(sapply(tmp, function(x) x[1]))
End <- as.numeric(sapply(tmp, function(x) x[2]))
C3 <- data.frame(Chrom, Start, End, X=C3)

tmp <- strsplit(geneNames, ":")
Chrom <- sapply(tmp, function(x) x[1])
tmp <- strsplit(sapply(tmp, function(x) x[2]), "-")
Start <- as.numeric(sapply(tmp, function(x) x[1]))
End <- as.numeric(sapply(tmp, function(x) x[2]))

X <- data.frame(Chrom, Start, End)
X$Chrom <- as.character(X$Chrom)
X$Chrom[which(X$Chrom=="X")] <- 23
X$Chrom <- as.numeric(X$Chrom)
X$Pos <- X$Start + (X$End-X$Start)/2
X$AbsPos <- as.numeric(X$Pos)
for (i in 2:23) {
	X$AbsPos[which(X$Chrom==i)] <- X$Pos[which(X$Chrom==i)] + max(X$AbsPos[which(X$Chrom==i-1)])
}

maxVals <- rep(NA, 22)
for (i in 2:23) {
    maxVals[i-1] <- max(X$AbsPos[which(X$Chrom==i-1)])
}


C1$Chrom <- as.character(C1$Chrom)
C1$Chrom[which(C1$Chrom=="C1")] <- 23
C1$Chrom <- as.numeric(C1$Chrom)
C1$Pos <- C1$Start + (C1$End-C1$Start)/2
C1$AbsPos <- as.numeric(C1$Pos)
for (i in 2:23) {
	C1$AbsPos[which(C1$Chrom==i)] <- C1$Pos[which(C1$Chrom==i)] + maxVals[i-1]
}

C2$Chrom <- as.character(C2$Chrom)
C2$Chrom[which(C2$Chrom=="C2")] <- 23
C2$Chrom <- as.numeric(C2$Chrom)
C2$Pos <- C2$Start + (C2$End-C2$Start)/2
C2$AbsPos <- as.numeric(C2$Pos)
for (i in 2:23) {
	C2$AbsPos[which(C2$Chrom==i)] <- C2$Pos[which(C2$Chrom==i)] + maxVals[i-1]
}

C3$Chrom <- as.character(C3$Chrom)
C3$Chrom[which(C3$Chrom=="C3")] <- 23
C3$Chrom <- as.numeric(C3$Chrom)
C3$Pos <- C3$Start + (C3$End-C3$Start)/2
C3$AbsPos <- as.numeric(C3$Pos)
for (i in 2:23) {
	C3$AbsPos[which(C3$Chrom==i)] <- C3$Pos[which(C3$Chrom==i)] + maxVals[i-1]
}

par(mfrow=c(4,1))
plot(res[,'STG139M-X0'] ~ X$AbsPos, cex=0.25, pch=19, axes=F, ylab="Copy Number", xlab="Chromosome",
     ylim=c(-2, 2), main="Cluster 1: Metastasis")
abline(h=0, col="grey")
pos.breaks <- tapply(X$AbsPos, X$Chr, max)
abline(v=pos.breaks, lty=2, col="grey")
axis(1, c(0, pos.breaks[-length(pos.breaks)]) + diff(c(0, pos.breaks)) / 2, c(1:22, "X"))
axis(2)
box()
plot(res[,'STG139-X2'] ~ X$AbsPos, cex=0.25, pch=19, axes=F, ylab="Copy Number", xlab="Chromosome",
     ylim=c(-2, 2), main="Cluster 2:Primary Early Passages")
abline(h=0, col="grey")
pos.breaks <- tapply(X$AbsPos, X$Chr, max)
abline(v=pos.breaks, lty=2, col="grey")
axis(1, c(0, pos.breaks[-length(pos.breaks)]) + diff(c(0, pos.breaks)) / 2, c(1:22, "X"))
axis(2)
box()
plot(res[,'STG139-X12'] ~ X$AbsPos, cex=0.25, pch=19, axes=F, ylab="Copy Number", xlab="Chromosome",
     ylim=c(-2, 2), main="Cluster 3:Primary Late Passages")
abline(h=0, col="grey")
pos.breaks <- tapply(X$AbsPos, X$Chr, max)
abline(v=pos.breaks, lty=2, col="grey")
axis(1, c(0, pos.breaks[-length(pos.breaks)]) + diff(c(0, pos.breaks)) / 2, c(1:22, "X"))
axis(2)
box()

plot(Pos ~ AbsPos, data=X, type="n", cex=0.25, pch=19, axes=F, ylab="Copy Number", xlab="Chromosome",
     ylim=c(-1.2, 1.2))
abline(h=0, col="grey")
pos.breaks <- tapply(X$AbsPos, X$Chr, max)
abline(v=pos.breaks, lty=2, col="grey")
axis(1, c(0, pos.breaks[-length(pos.breaks)]) + diff(c(0, pos.breaks)) / 2, c(1:22, "X"))
axis(2, c(-1, 0, 1), c("Loss", "Neutral", "Gain"))
box()
points(as.numeric(as.character(X)) ~ AbsPos, data=C1, col="olivedrab", pch=19)
points(as.numeric(as.character(X)) ~ AbsPos, data=C2, col="red", pch=19)
points(as.numeric(as.character(X)) ~ AbsPos, data=C3, col="blue", pch=19)
legend("topright", lwd=rep(2, 3), col=c("olivedrab", "red", "blue"), legend=c("Cluster 1", "Cluster 2",
                                                                     "Cluster 3"))
