setwd("/CopyNumber/")
allF <- dir(pattern=".txt")
nams <- sub("_ordered.bam.picard.bam_QDNAseq.txt", "", allF, fixed=TRUE)
nams <- sub("_ordered_picard.bam_QDNAseq.txt", "", nams, fixed=TRUE)
nams <- sub("Shallow_", "", nams, fixed=TRUE)

res <- NULL
for (i in 1:length(nams)) {
    tmp <- read.table(allF[i], header=TRUE, sep="\t")
    res <- cbind(res, tmp[,6])
}
colnames(res) <- nams

## Let's remove ugly regions
feo <- apply(res, 1, function(x) mean(x < -10, na.rm=T))
res[which(feo>0.9),] <- NA
res[which(res < -10)] <- -10

## Let's remove ugly samples: less than 2,000,000 reads
bads <- c("AB551-X0R", "AB569-X1" ,"AB569-XC7",
          "HC1", "HC2", "HC3", "HCI011-XC", "NORMAL",
          "STG139-X0", "STG235-X1", "STG235-X2",
          "STG335-X4C7", "VHIO136-X14", "VHIO136-X15")

res.merged <- NULL
Pos <- read.table(allF[1], header=TRUE, sep="\t")
Chrom <- Pos$chromosome
Start <- Pos$start
End <- Pos$end

for (i in 1:length(nams)) {
    tmp <- res[,i,drop=F]
    for (chr in unique(Chrom)) {
	rle.merged <- rle(tmp[Chrom==chr,1])
	loc.start <- c(1, cumsum(rle.merged$length) + 1)
	loc.start <- loc.start[-length(loc.start)]
	loc.start <- Start[Chrom==chr][loc.start]
	loc.end <- End[Chrom==chr][cumsum(rle.merged$length)]
	num.mark <- rle.merged$lengths
	seg.mean <- rle.merged$values
	ID <- rep(nams[i], length(seg.mean))
	chrom <- Chrom[Chrom==chr][cumsum(rle.merged$length)]
	x <- data.frame(ID, chrom, loc.start, loc.end, num.mark, seg.mean)
        res.merged <- rbind(res.merged, x)
 	}
    cat(i, " done\n")
}
res.merged$chrom <- factor(res.merged$chrom, levels=c(1:22, "X"))
res.merged <- res.merged[order(res.merged$ID, res.merged$chrom, res.merged$loc.start),]
res.merged <- res.merged[which(!is.na(res.merged$seg.mean)),]
write.table(res.merged, file="/Volumes/BAM_PDX/Shallow/CNAllSamples.seg", row.names=F, quote=F, sep="\t")

SS <- read.table("/SampleSheetShallow.txt", header=TRUE, sep="\t")
ids <- which(res.merged$ID %in% SS$ID[which(SS$Include=="YES")])
feo <- res.merged[ids,]
feo <- feo[-which(feo$ID %in% bads),]
write.table(feo, file="/CNA_GoodSamples.seg", row.names=F, quote=F, sep="\t")


load("/Exomes/NormalContamination.RData")

for (i in names(all.est)) {
    ids <- which(res.merged$ID==i)
    if (length(ids) > 0) {
    x <- 2^res.merged$seg.mean[ids]
    y <- (x - (1-all.est[i])) / all.est[i]
    y[which(y<=0)] <- 1e-4
    y <- log2(y)
    res.merged$seg.mean[ids] <- y
    }
}
write.table(res.merged, file="/CNAllSamplesContaminationCorrected.seg", row.names=F, quote=F, sep="\t")

for (i in names(all.est)) {
    ids <- which(feo$ID==i)
    if (length(ids) > 0) {
    x <- 2^feo$seg.mean[ids]
    y <- (x - (1-all.est[i])) / all.est[i]
    y[which(y<=0)] <- 1e-4
    y <- log2(y)
    feo$seg.mean[ids] <- y
    }
}
write.table(feo, file="/CNA_GoodSamplesContaminationCorrected.seg", row.names=F, quote=F, sep="\t")
