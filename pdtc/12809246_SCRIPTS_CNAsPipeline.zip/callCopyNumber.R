
CNA <- read.table(file="/CNA_GoodSamplesContaminationCorrected.seg", header=TRUE, sep="\t")
CNA$call <- NA
CNA$call2 <- NA
for (i in unique(CNA$ID)) {
    x.log <- rep(CNA$seg.mean[which(CNA$ID==i)],
                 CNA$num.mark[which(CNA$ID==i)])
    thr <- c(-1.4, -0.3, 0.25, 0.75)
    CNA$call[CNA$ID == i] <- 1 * (CNA$seg.mean[CNA$ID ==
             i] > thr[3]) -1 *
    (CNA$seg.mean[CNA$ID == i] < thr[2])
    CNA$call2[CNA$ID == i] <- 1 * (CNA$seg.mean[CNA$ID == i] > thr[3]) +
      1 * (CNA$seg.mean[CNA$ID == i] > thr[4]) -1 *
    (CNA$seg.mean[CNA$ID == i] < thr[2]) -1 *
    (CNA$seg.mean[CNA$ID == i] < thr[1])
}

SS <- read.table("/SampleSheetShallow.txt", header=T, sep="\t")
CNA <- CNA[which(CNA$ID %in% SS$ID),]

write.table(CNA, file="/CNACalls.txt", row.names=F, quote=F, sep="\t")

## Now we make files per gene

refseq <- read.table("/refseqGenes.txt", header=FALSE, sep="\t", stringsAsFactors=F)
refseq <- refseq[which(refseq$V3 %in% paste("chr", c(1:22, "X"), sep="")),]
refseq <- split(refseq, refseq$V13)
refseq <- lapply(refseq, function(x) {
                 data.frame(x$V13[1],x$V3[1],
                            min(x$V5), max(x$V6))
             })

refseq <- do.call("rbind", refseq)
colnames(refseq) <- c("Symbol", "Chrom", "Start", "End")
refseq$Chrom <- factor(refseq$Chrom,
                       levels=paste("chr", c(1:22, "X"),
                       sep=""))
refseq <- refseq[order(refseq$Chrom, refseq$Start),]

SS <- SS[which(SS$ID %in% CNA$ID),]
SS <- SS[,c('Tumour', 'ID', 'Type')]
SS <- unique(SS)

cat("Number of different samples:", nrow(SS), "\n")
cat("Number of different models:", length(unique(SS$Tumour)), "\n")
sort(unique(SS$Tumour))

GENE.CN <- matrix(NA, nrow(refseq),
                  length(unique(CNA$ID)))
for (i in 1:nrow(refseq)) {
    x <- subset(CNA, chrom==sub("chr", "",
                     refseq$Chrom[i]) &
                ((loc.start >= refseq$Start[i] &
                  loc.start <= refseq$End[i]) |
                 (loc.start <= refseq$Start[i] &
                  loc.end >= refseq$Start[i])))
    if (nrow(x) > 0) {
        res <- sapply(split(x, x$ID), function(x) {
            if (nrow(x)>0) {
          c(any(x$call==-1), any(x$call==1))
    }else {
          c(NA, NA)
      }
        })
        res <- apply(res, 2, function(x) {
            if (any(is.na(x))) {
                NA
            } else if (!x[1] & !x[2]) {
              "NEUT"
          } else if (x[1] & !x[2]) {
              "LOSS"
          } else if (!x[1] & x[2]) {
              "GAIN"
          } else if (x[1] & x[2]) {
              "LOSS/GAIN"
          }
      })
        if (length(res) != ncol(GENE.CN)) stop()
        GENE.CN[i,] <- res
    }
    cat("i=", i, "\n")
}
rownames(GENE.CN) <- refseq$Symbol
colnames(GENE.CN) <- names(res)

save(GENE.CN, file="/GENE.CN.RData")


GENE.CN.MODEL <- NULL
Valid <- names(which(table(SS$Tumour[which(SS$Type %in% c("PDTX", "PDTC"))])>0))
for (i in Valid) {
    ids <- as.character(SS$ID[which(SS$Tumour == i & SS$Type %in%  c("PDTX", "PDTC"))])
    res <- apply(GENE.CN[,ids,drop=F], 1, function(x) {
        if (mean(is.na(x))<1) {
        if(mean(x=="GAIN", na.rm=T) > 0.5) {
              "GAIN"
          } else if(mean(x=="LOSS", na.rm=T) > 0.5) {
              "LOSS"
          } else if(mean(x=="NEUT", na.rm=T) > 0.5) {
              "NEUT"
          } else {
              'UNKNOWN'
          }
          } else {
              NA
          }
      })
    GENE.CN.MODEL <- cbind(GENE.CN.MODEL, res)
}
colnames(GENE.CN.MODEL) <- Valid

GENE.CN.MODEL <- data.frame(GENE.CN.MODEL)
GENE.CN.MODEL$Symbol <- rownames(GENE.CN.MODEL)
GENE.CN.MODEL <- GENE.CN.MODEL[,c(ncol(GENE.CN.MODEL), c(1:(ncol(GENE.CN.MODEL)-1)))]
write.table(GENE.CN.MODEL,
            file="/GENECNMODEL.txt", row.names=F, sep="\t", quote=F)


GENE.CN.TUMOUR <- NULL
Valid <- names(which(table(SS$Tumour[which(SS$Type %in% c("Tumour"))])>0))
for (i in Valid) {
    ids <- as.character(SS$ID[which(SS$Tumour == i & SS$Type %in%  c("Tumour"))])
    res <- apply(GENE.CN[,ids,drop=F], 1, function(x) {
        if (mean(is.na(x))<1) {
        if(mean(x=="GAIN", na.rm=T) > 0.5) {
              "GAIN"
          } else if(mean(x=="LOSS", na.rm=T) > 0.5) {
              "LOSS"
          } else if(mean(x=="NEUT", na.rm=T) > 0.5) {
              "NEUT"
          } else {
              NA
          }
          } else {
              NA
          }
      })
    GENE.CN.TUMOUR <- cbind(GENE.CN.TUMOUR, res)
}
colnames(GENE.CN.TUMOUR) <- Valid

GENE.CN.TUMOUR <- data.frame(GENE.CN.TUMOUR)
GENE.CN.TUMOUR$Symbol <- rownames(GENE.CN.TUMOUR)
GENE.CN.TUMOUR <- GENE.CN.TUMOUR[,c(ncol(GENE.CN.TUMOUR), c(1:(ncol(GENE.CN.TUMOUR)-1)))]
write.table(GENE.CN.TUMOUR,
            file="/GENECNTUMOUR.txt", row.names=F, sep="\t", quote=F)
