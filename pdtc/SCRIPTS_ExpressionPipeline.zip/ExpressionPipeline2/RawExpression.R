SS <- read.csv(“/Expression/ExpressionFullSampleSheet.csv", skip=7)

pdf("/SignaltoNoise.pdf",
    width=12, height=8)
setwd("/Volumes/CLUS_BACKUP/PDX/PDX/Expression/Images")
alldirs <- dir()
alldirs <- alldirs[which(alldirs!="QC")]
for (i in alldirs) {
  ht12metrics <- read.table(paste(i, "/Metrics.txt", sep=""), as.is=TRUE, header=TRUE, sep="\t")
  ht12snr <- ht12metrics $ P95Grn / ht12metrics $ P05Grn
  labs <- paste ( ht12metrics [, 2], ht12metrics [, 3], sep = "_")
  par(mai = c(1.5 , 0.8 , 0.3 , 0.1))
  plot (1:12 , ht12snr , pch = 19, ylab = "P95 / P05", xlab = "",
       main = paste("Signal-to- noise ratio for HT12 data ", i, sep=""), axes = FALSE,
       frame.plot = TRUE )
  axis (2)
 axis (1, 1:12 , labs , las = 2)
}
dev.off()

SS$Sentrix_Position <- toupper(SS$Sentrix_Position)

library(beadarray)
chipPath <- getwd()
chip <- readIllumina(dir=chipPath, sampleSheet="/Expression/ExpressionFullSampleSheet.csv",
                         useImages=FALSE, illuminaAnnotation="Humanv4")

pdf("/Volumes/PDX/Expression/ControlProbes.pdf",
    width=12, height=6)
for (i in 1:nrow(SS)) {
    print(combinedControlPlot(chip, array=i))
}
dev.off()

save(chip, file=“/Expression/FullbeadBeforeBASH.RData")

for (i in 1:nrow(SS)) {
    BASHoutput <- BASH(chip, array=i)
    chip <- setWeights(chip, wts=BASHoutput$wts, array=i)
}
save(chip, file="/Expression/FullbeadAfterBASH.RData")

load(file="/Expression/FullbeadAfterBASH.RData")
## expressionQCPipeline(chip, horizontal=T)
datasumm <- summarize(BLData=chip)

rm(chip)
gc()

## boxplot(exprs(datasumm))
## boxplot(nObservations(datasumm))
detec <- calculateDetection(datasumm)
Detection(datasumm) <- detec
PropDet <- apply(detec, 2, function(x) sum(x<0.05, na.rm=T))/nrow(detec)
pdf("/Expression/DetectedProbes.pdf", width=10, height=25)
dotchart(PropDet, labels=pData(datasumm)$Sample_Name, xlab="Proportion of detected probes", pch=19)
dev.off()

## boxplot(datasumm)
library(limma)
prop <- propexpr(exprs(datasumm), status=fData(datasumm)$Status)
pdf("/VExpression/ExpressedProbes.pdf", width=10, height=25)
dotchart(prop, labels=pData(datasumm)$Sample_Name, xlab="Proportion of probes expressed above the level of negative controls", pch=19)
dev.off()
slide <- colnames(datasumm)
slide <- sapply(strsplit(slide, "_"), function(x) x[1])
pdf("/Expression/MDS.pdf", width=10, height=10)
plotMDS(exprs(datasumm), col=as.numeric(factor(slide)), labels=pData(datasumm)$Sample_Name)
dev.off()

reallybad <- which(prop < 0.3)
normData <- normaliseIllumina(datasumm[,-reallybad])
ids <- as.character(featureNames(normData))
qual <- unlist(mget(ids, illuminaHumanv4PROBEQUALITY, ifnotfound=NA))
qual <- gsub("*", "", qual, fixed=TRUE)
symbol <- unlist(mget(ids, illuminaHumanv4SYMBOL, ifnotfound=NA))
Pos <- unlist(mget(ids, illuminaHumanv4GENOMICLOCATION, ifnotfound=NA))
SNP <- unlist(mget(ids, illuminaHumanv4OVERLAPPINGSNP, ifnotfound=NA))
symbol2 <- unlist(mget(ids, illuminaHumanv4SYMBOLREANNOTATED, ifnotfound=NA))
zone <- unlist(mget(ids, illuminaHumanv4CODINGZONE, ifnotfound=NA))
fData(normData) <- cbind(fData(normData), qual, symbol, symbol2, Pos, SNP, zone)
## boxplot(normData, probeFactor="qual")
rem <- qual == "No match" | qual =="Bad"

## we need TP53 back!
rem[which(symbol2=="TP53")] <- FALSE

normData.filt <- normData[which(!rem),]
dim(normData)
dim(normData.filt)

pData(normData.filt)$Tumour[which(pData(normData.filt)$Sample_Name=="AB559x1_1490")] <- "AB559"
pData(normData.filt)$Tumour <- factor(pData(normData.filt)$Tumour)
save(normData.filt, file="/Expression/NormalizedAllSamples.RData")

