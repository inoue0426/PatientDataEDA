load("/Expression/NormalizedAllSamples.RData")
library(beadarray)
SS <- read.csv("/Expression/ExpressionFullSampleSheet.csv", skip=7)
PDX <- exprs(normData.filt)
Genes <- fData(normData.filt)

load("/SelectedProbes.RData")
selected.probes <- as.character(selected.probes)

genesfound <- unique(Genes$symbol2)
genesfound <- genesfound[which(!is.na(genesfound))]
genesfound <- as.character(genesfound)

FinalProbes <- c()

for (i in genesfound) {
    ID <- which(Genes$symbol2==i)
    if (length(ID)==1) {
        FinalProbes <- c(FinalProbes, as.character(Genes$IlluminaID[ID]))
    } else {
        found <- which(ID %in% selected.probes)
        if (length(found)!=1) {
            if(length(found)>0) ID <- found
            IQR <- apply(PDX[which(rownames(PDX) %in%
                                   Genes$IlluminaID[ID]),],
                         1, IQR, na.rm=TRUE)
        FinalProbes  <- c(FinalProbes, names(which.max(IQR)))
        } else {
            FinalProbes <- c(FinalProbes,
                             as.character(Genes$IlluminaID[found]))
        }
    }
    cat(i, " done\n")
}

PDX <- PDX[which(rownames(PDX) %in% FinalProbes),]
Genes <- Genes[which(Genes$IlluminaID %in% FinalProbes),]
FinalProbes <- FinalProbes[match(rownames(PDX), FinalProbes)]
Genes <- Genes[match(FinalProbes, Genes$IlluminaID),]
rownames(PDX) <- Genes$symbol2
SS$Sentrix <- paste(SS[,4], SS[,5], sep="_")
SS <- SS[which(SS$Sentrix %in% colnames(PDX)),]
SS <- SS[match(colnames(PDX), SS$Sentrix),]
colnames(PDX) <- SS$ID
write.table(PDX, file="/Expression/PDX_Genes_Expression.txt", sep="\t", quote=F)
save(PDX, Genes, SS, file="/Expression/PDX_Genes_Expression.RData")

cat("Number of samples:", ncol(PDX), "\n")
cat("Number of different models:", length(unique(SS$Tumour)), "\n")
sort(unique(SS$Tumour))

