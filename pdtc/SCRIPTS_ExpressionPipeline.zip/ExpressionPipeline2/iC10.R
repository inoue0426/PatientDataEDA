load("/Expression/NormalizedAllSamples.RData")
library(beadarray)
SS <- read.csv("/Expression/ExpressionFullSampleSheet.csv", skip=7)
PDX <- exprs(normData.filt)
Annot <- fData(normData.filt)

SS <- SS[which(SS$ID %in% pData(normData.filt)$ID),]
SS <- SS[match(pData(normData.filt)$ID, SS$ID),]

colnames(PDX) <- SS$ID

PDX <- PDX[,which(SS$TYPE!="Normal")]
SS <- SS[which(SS$TYPE!="Normal"),]

Exp.SS <- SS

compare.iC10 <-
function (obj, iC10 = 1:10, newdata, name.test = "Test", ylim.train, ylim.test, layout=NULL,...)
{
    par(no.readonly = TRUE)
    oldpar <- par(no.readonly = TRUE)
    coliCluster <- c("#FF5500", "#00EE76", "#CD3278", "#00C5CD",
        "#8B0000", "#FFFF40", "#0000CD", "#FFAA00", "#EE82EE",
        "#7D26CD")
    cn.features <- NULL
    exp.features <- NULL
    if (attr(obj, "classifier.type") != "Exp") {
        cn.features <- newdata$map.cn
        if ("Synonyms_0" %in% colnames(cn.features)) {
            cn.features <- cn.features[, -which(colnames(cn.features) %in%
                c("Synonyms_0", "Gene.Chosen"))]
        }
        cn.features$Type <- "CN"
        features <- cn.features
    }
    if (attr(obj, "classifier.type") != "CN") {
        exp.features <- newdata$map.exp
        exp.features$Type <- "Exp"
        features <- exp.features
    }
    max.grey.square <- nrow(cn.features)
    if (!is.null(cn.features) & !is.null(exp.features)) {
        common.cols <- intersect(colnames(cn.features), colnames(exp.features))
        features <- rbind(cn.features[, common.cols], exp.features[,
            common.cols])
    }
    if (attr(obj, "ref") == "hg18") {
        features$CHROM <- features$chromosome_name_hg18
    }
    if (attr(obj, "ref") == "hg19") {
        features$CHROM <- features$chromosome_name_hg19
    }
    Pos <- c(1, which(diff(features$CHROM) != 0), nrow(features))
    text.pos <- Pos + c(diff(Pos)/2, 0)
    text.pos <- text.pos[-length(text.pos)]
    all.data <- rbind(newdata$CN, newdata$Exp)
    par(mfrow = layout, mar = c(2.5, 4, 5, 2), oma = c(2,
        2, 2, 2), no.readonly = TRUE)
    for (i in iC10) {
        plot(obj$centroids[, i], type = "h", col = coliCluster[i],
            xlab = "", ylab = "Copy Number", axes = F, main = paste("IntClust ",
                i, " METABRIC", sep = ""), ylim=ylim.train,
		col.main=coliCluster[i], cex.main=2, cex.lab=1.5, cex.axis=1.5,...)
        axis(2, cex.axis=1.5, cex.lab=1.5)
        bottom.axis.pos <- seq(from = 1, by = 2, length = length(text.pos))
        top.axis.pos <- seq(from = 2, by = 2, length = length(text.pos))
        axis(1, at = text.pos[bottom.axis.pos], features$CHROM[Pos[-1]][bottom.axis.pos], cex.axis=1.5, cex.lab=1.5)
        axis(3, at = text.pos[top.axis.pos], features$CHROM[Pos[-1]][top.axis.pos], line=-1, cex.axis=1.5, cex.lab=1.5)
        box()
        if (attr(obj, "classifier.type") != "Exp") {
            polygon(x = rep(c(0, max.grey.square), c(2, 2)),
                ## y = c(range(obj$centroids[, i]), rev(range(obj$centroids[,i]))),
                    y = c(ylim.train, rev(ylim.train)),
                    density = NA, border = "lightgrey",
                col = "lightgrey", ylab = paste("iC", i))
        }
        points(obj$centroids[, i], type = "h", col = coliCluster[i],
            xlab = "")
        abline(v = Pos, lty = 2)
        if (length(which(obj$class == i)) > 0) {
            test <- unclass(apply(all.data[, which(obj$class ==
                i), drop = F], 1, mean))
            plot(test, type = "h", col = coliCluster[i], xlab = "",
                ylab = "Copy Number", axes = F, cex.lab=1.5, cex.axis=1.5, main = paste("IntClust", i, " ", name.test,
                  sep = ""), ylim=ylim.test, col.main=coliCluster[i], cex.main=2,...)
            axis(2, cex.axis=1.5, cex.lab=1.5)
            bottom.axis.pos <- seq(from = 1, by = 2, length = length(text.pos))
            top.axis.pos <- seq(from = 2, by = 2, length = length(text.pos))
            axis(1, at = text.pos[bottom.axis.pos], features$CHROM[Pos[-1]][bottom.axis.pos], cex.axis=1.5, cex.lab=1.5)
            axis(3, at = text.pos[top.axis.pos], features$CHROM[Pos[-1]][top.axis.pos], line=-1, cex.axis=1.5, cex.lab=1.5)
            box()
            if (attr(obj, "classifier.type") != "Exp") {
                polygon(x = rep(c(0, max.grey.square), c(2, 2)),
                    y = c(ylim.test, rev(ylim.test)),
                        ## y = c(range(obj$centroids[, i]), rev(range(obj$centroids[, i]))),
                        density = NA, border = "lightgrey",
                  col = "lightgrey", ylab = paste("iC", i))
            }
            points(test, type = "h", col = coliCluster[i], xlab = "")
            abline(v = Pos, lty = 2)
        }
        else {
            plot(0, 0, type = "n", xlab = "", ylab = "", axes = F)
        }
    }
    par(oldpar, no.readonly = TRUE)
}

compare2.iC10 <-
function (obj, iC10 = 1:10, newdata, name.test = "Test", ylim.train, ylim.test, layout=NULL,...)
{
    par(no.readonly = TRUE)
    oldpar <- par(no.readonly = TRUE)
    coliCluster <- c("#FF5500", "#00EE76", "#CD3278", "#00C5CD",
        "#8B0000", "#FFFF40", "#0000CD", "#FFAA00", "#EE82EE",
        "#7D26CD")
    cn.features <- NULL
    exp.features <- NULL
    if (attr(obj, "classifier.type") != "Exp") {
        cn.features <- newdata$map.cn
        if ("Synonyms_0" %in% colnames(cn.features)) {
            cn.features <- cn.features[, -which(colnames(cn.features) %in%
                c("Synonyms_0", "Gene.Chosen"))]
        }
        cn.features$Type <- "CN"
        features <- cn.features
    }
    if (attr(obj, "classifier.type") != "CN") {
        exp.features <- newdata$map.exp
        exp.features$Type <- "Exp"
        features <- exp.features
    }
    max.grey.square <- nrow(cn.features)
    if (!is.null(cn.features) & !is.null(exp.features)) {
        common.cols <- intersect(colnames(cn.features), colnames(exp.features))
        features <- rbind(cn.features[, common.cols], exp.features[,
            common.cols])
    }
    if (attr(obj, "ref") == "hg18") {
        features$CHROM <- features$chromosome_name_hg18
    }
    if (attr(obj, "ref") == "hg19") {
        features$CHROM <- features$chromosome_name_hg19
    }
    Pos <- c(1, which(diff(features$CHROM) != 0), nrow(features))
    text.pos <- Pos + c(diff(Pos)/2, 0)
    text.pos <- text.pos[-length(text.pos)]
    all.data <- rbind(newdata$CN, newdata$Exp)
    par(mfrow = layout, mar = c(2.5, 4, 5, 2), oma = c(2,
        2, 2, 2), no.readonly = TRUE)
    for (i in iC10) {
        plot(obj$centroids[, i], type = "h", col = coliCluster[i],
            xlab = "", ylab = "Copy Number", axes = F, main = "", ylim=ylim.train,
		col.main=coliCluster[i], cex.main=2, cex.lab=1.5, cex.axis=1.5,...)
        axis(2, cex.axis=1.5, cex.lab=1.5)
        bottom.axis.pos <- seq(from = 1, by = 2, length = length(text.pos))
        top.axis.pos <- seq(from = 2, by = 2, length = length(text.pos))
        axis(1, at = text.pos[bottom.axis.pos], features$CHROM[Pos[-1]][bottom.axis.pos], cex.axis=1.5, cex.lab=1.5)
        axis(3, at = text.pos[top.axis.pos], features$CHROM[Pos[-1]][top.axis.pos], line=1, cex.axis=1.5, cex.lab=1.5)
        box()
        abline(v = Pos, lty = 2)
        if (length(which(obj$class == i)) > 0) {
            test <- unclass(apply(all.data[, which(obj$class ==
                i), drop = F], 1, mean))
            lines(test, type = "l", col = coliCluster[i], xlab = "", pch=2, lwd=2,
                ylab = "Copy Number", cex.lab=1.5, cex.axis=1.5, main = paste("IntClust", i, " ", name.test,
                  sep = ""), ylim=ylim.test, col.main=coliCluster[i], cex.main=2,...)
        }
        else {
            plot(0, 0, type = "n", xlab = "", ylab = "", axes = F)
        }
    }
    par(oldpar, no.readonly = TRUE)
}


set.seed(43534)
load(file="/Expression/NormalizedAllSamples.RData")
library(beadarray)
SS <- read.csv("/Expression/ExpressionFullSampleSheet.csv", skip=7)
PDX <- exprs(normData.filt)
Genes <- fData(normData.filt)
SS$Sentrix <- paste(SS[,4], SS[,5], sep="_")
SS <- SS[which(SS$Sentrix %in% colnames(PDX)),]
SS <- SS[match(colnames(PDX), SS$Sentrix),]
colnames(PDX) <- SS$ID


PDX <- PDX[,which(SS$TYPE!="Normal")]
SS <- SS[which(SS$TYPE!="Normal"),]

load(“/MetabricExpressionDiscoverySet997.RData")
load("/Metabric2/MetabricExpressionValidationSet983.RData")
Metabric <- cbind(DS, VS)
rm(DS, VS)

common.probes <- intersect(rownames(Metabric), rownames(PDX))
Metabric <- Metabric[which(rownames(Metabric) %in% common.probes),]
PDX <- PDX[which(rownames(PDX) %in% common.probes),]
Genes <- Genes[which(Genes$IlluminaID %in% common.probes),]

PDX <- PDX[match(rownames(Metabric), rownames(PDX)),]
Genes <- Genes[match(rownames(PDX), Genes$IlluminaID),]

Exp <- cbind(Metabric, PDX)
library(preprocessCore)
AllExp <- normalize.quantiles(Exp)
dimnames(AllExp) <- dimnames(Exp)
AllExp <- apply(AllExp, 1, scale)
AllExp <- t(AllExp)
dimnames(AllExp) <- dimnames(Exp)


source("classifier_functions.R")
pam <- pam50(AllExp, level="probe", probs=TRUE)
post.probs <- c()
for (i in 1:length(pam$call)) {
    if (pam$call[i]=="NC") post.probs <- c(post.probs, NA)
    else post.probs <- c(post.probs, pam$probs[i,pam$call[i]])
}
post.probs <- post.probs/100
pam <- data.frame(ID=names(pam$call), Pam50=pam$call,
                  Pam50.score=post.probs)

library(iC10)

features <- matchFeatures(Exp=AllExp, Exp.by.feat="probe")
features.norm <- normalizeFeatures(features, "scale")
res.Exp <- iC10(features.norm)
summ <- goodnessOfFit(res.Exp)
summ$total

iC10.PDX <- data.frame(ID=names(res.Exp$class[1981:length(res.Exp$class)]), iC10.Exp=res.Exp$class[1981:length(res.Exp$class)],
                       score.Exp=summ$indiv[1981:length(res.Exp$class)])

codes <- SS[,c('ID', 'Tumour', 'TYPE', 'Include')]
iC10.PDX <- merge(iC10.PDX, codes)

features.pdx <- features
features.pdx$Exp <- features.pdx$Exp[,1981:length(res.Exp$class)]
res.Exp.pdx <- res.Exp
res.Exp.pdx$class <- res.Exp.pdx$class[1981:length(res.Exp$class)]


## Now shallow copy number

## Now Metabric Validation
load("CNA1980.RData")
load("MetabricExpressionDiscoverySet997.RData")
discovery <- colnames(DS)
CNA <- CNA[-which(CNA$ID %in% discovery),]
CNA <- CNA[,c(1:4, 6)]
colnames(CNA) <- c("ID", "chromosome_name", "loc.start", "loc.end", "seg.mean")
features <- matchFeatures(CN=CNA, CN.by.feat="probe", ref="hg18")
res.CN <- iC10(features)
summ <- goodnessOfFit(res.CN)
scores.Met <- data.frame(iC10=res.CN$class, Score=summ$indiv)

CNA <- read.table(file="/CNA.seg", header=TRUE, sep="\t", stringsAsFactors=FALSE)
colnames(CNA)[2] <- "chromosome_name"
CNA$chromosome_name[which(CNA$chromosome_name=="X")] <- 23
CNA$chromosome_name <-
    as.numeric(as.character(CNA$chromosome_name))
CNA$loc.start <- as.numeric(as.character(CNA$loc.start))
CNA$loc.end <- as.numeric(as.character(CNA$loc.end))
CNA <- CNA[-grep("-N", CNA$ID, fixed=TRUE),]
features <- matchFeatures(CN=CNA, CN.by.feat="probe", ref="hg19")
res.CN <- iC10(features)
summ <- goodnessOfFit(res.CN)
scores.PDX <- data.frame(iC10=res.CN$class, Score=summ$indiv)


scores.Met$Cohort <- "MB"
scores.PDX$Cohort <- "PDTX"

Scores <- rbind(scores.PDX, scores.Met)
Scores$iC10 <- paste("iC", Scores$iC10, sep="")
Scores$iC10 <- factor(Scores$iC10, levels=paste("iC", 1:10, sep=""))
coliCluster <- c("#FF5500", "#00EE76", "#CD3278", "#00C5CD",
                 "#8B0000", "#FFFF40", "#0000CD", "#FFAA00", "#EE82EE",
                 "#7D26CD")


pdf("/Expression/GoodnessofFitCN2.pdf", width=12, height=7)
par(oma=c(4, 1, 1, 1))
sub.Scores <- subset(Scores, iC10 %in% paste("iC", c(1, 3:6, 8:10), sep=""))
sub.Scores$iC10 <- factor(sub.Scores$iC10)
n.vals <-tapply(sub.Scores$iC10, interaction(sub.Scores$Cohort, sub.Scores$iC10), length)
levels(sub.Scores$iC10) <- sub("iC", "IntClust", levels(sub.Scores$iC10))
boxplot(Score ~ Cohort*iC10, data=sub.Scores,
        ylim=c(0,1), col=rep(coliCluster[-c(2,7)], rep(2, 8)), las=2,
        ylab="Goodness of Fit Score")
axis(3, at=1:length(n.vals), labels=paste("(n=", n.vals, ")", sep=""), las=2)
dev.off()



pdf("/iC10_CN2.pdf", width=20, height=12)
compare2.iC10(res.CN, iC10=c(1,3, 4,5,6, 8:10), newdata=features, name.test="PDTX",
layout=c(4, 2), ylim.train=c(-2, 2), ylim.test=c(-4, 4))
dev.off()

tmp <- data.frame(ID=names(res.CN$class), iC10.CN=res.CN$class,
                  score.CN=summ$indiv)
SS <- read.table("/SampleSheetShallow.txt", header=TRUE, sep="\t")
codes <- SS[,c('ID', 'Tumour', 'Type', 'Include')]
colnames(codes)[3] <- "TYPE"
tmp <- merge(tmp, codes)
iC10.PDX <- merge(iC10.PDX, tmp, all=TRUE)

## Now Both

common.IDS <- intersect(unique(CNA$ID), colnames(AllExp))
features <- matchFeatures(CN=CNA[which(CNA$ID %in% common.IDS),],
                          Exp=AllExp[,which(colnames(AllExp) %in% common.IDS)], CN.by.feat="probe",
                          Exp.by.feat="probe", ref="hg19")
res.CN.Exp <- iC10(features)
summ <- goodnessOfFit(res.CN.Exp)
summ$total
tmp <- data.frame(ID=names(res.CN.Exp$class), iC10.CN.Exp=res.CN.Exp$class, score.CN.Exp=summ$indiv)
iC10.PDX <- merge(iC10.PDX, tmp, all=TRUE)

iC10.PDX$Final <- iC10.PDX$iC10.CN.Exp
iC10.PDX$Score <- iC10.PDX$score.CN.Exp
iC10.PDX$Final[which(is.na(iC10.PDX$Final))] <- iC10.PDX$iC10.Exp[which(is.na(iC10.PDX$Final))]
iC10.PDX$Score[which(is.na(iC10.PDX$Score))] <- iC10.PDX$score.Exp[which(is.na(iC10.PDX$Score))]
iC10.PDX$Final[which(is.na(iC10.PDX$Final))] <- iC10.PDX$iC10.CN[which(is.na(iC10.PDX$Final))]
iC10.PDX$Score[which(is.na(iC10.PDX$Score))] <- iC10.PDX$score.CN[which(is.na(iC10.PDX$Score))]

iC10.PDX <- iC10.PDX[order(iC10.PDX$Tumour, iC10.PDX$ID),]

SS <- as.character(SS$ID[which(SS$Include=="NO")])
Exp.SS <- as.character(Exp.SS$ID[which(Exp.SS$Include=="NO")])
SS <- unique(c(SS, Exp.SS))


iC10.PDX$Tumour <- as.character(iC10.PDX$Tumour)
res <- sapply(split(iC10.PDX, iC10.PDX$Tumour), function(x) {
    x <- x[which(!x$ID %in% SS),]
    if (nrow(x)>0) {
        res <- tapply(x$Score, x$Final, sum)
        if (sum(!is.na(res))==1) {
            c(which.max(res), x$Tumour[1])
        } else {
            if (abs(diff(sort(res, decreasing=T))[1]) > 0.1) {
                c(which.max(res), x$Tumour[1])
            } else {
                c(NA, x$Tumour[1])
            }
        }
    }
})
res <- do.call("cbind", res)
res <- data.frame(Tumour=res[2,], iC10=res[1,])

iC10.PDX <- merge(iC10.PDX, res, all.x=T)

iC10.PDX$ID <- as.character(iC10.PDX$ID)
iC10.PDX <- iC10.PDX[order(iC10.PDX$ID),]
iC10.PDX <- unique(iC10.PDX)
write.table(iC10.PDX, file="/Volumes/PDX/Expression/PDXiC10.txt", row.names=F, quote=F, sep="\t")



## Plot Comparing frequencies


load("Clinical1980.RData")
Clinical$Group <- as.character(Clinical$IntClustMemb)
Clinical$Group[which(Clinical$Group=="4" & Clinical$er_status=="neg")] <- "4ER-"
Clinical$Group[which(Clinical$Group=="4" & Clinical$er_status=="pos")] <- "4ER+"
Clinical$Group <- factor(Clinical$Group, levels=c(1:3, "4ER+", "4ER-", 5:10))
PDX.Clinical <- read.table("/PDXClinical.txt", header=TRUE, sep="\t", stringsAsFactors=FALSE)
PDX.Clinical$Tumour[which(PDX.Clinical$Tumour=="IC07")] <- "IC007"
PDX.Clinical$IC <- NULL
iC10.PDX <- merge(iC10.PDX, PDX.Clinical, all.x=TRUE)
iC10.PDX$iC10 <- as.character(iC10.PDX$iC10)

iC10.PDX$iC10[which(iC10.PDX$iC10=="4" & iC10.PDX$ER.status=="Neg")] <- "4ER-"
iC10.PDX$iC10[which(iC10.PDX$iC10=="4" & iC10.PDX$ER.status=="Pos")] <- "4ER+"
iC10.PDX$iC10 <- factor(iC10.PDX$iC10, levels=c(1:3, "4ER+", "4ER-", 5:10))

PDX <- tapply(iC10.PDX$iC10, iC10.PDX$Tumour, function(x) as.character(x[1]))


## Now PAM50 and ThreeGene

load(file="/Expression/PDX_Genes_Expression.RData")

PDX <- PDX[,which(SS$TYPE!="Normal")]
SS <- SS[which(SS$TYPE!="Normal"),]

load(“/MetabricExpressionDiscoverySet997.RData")
load("/MetabricExpressionValidationSet983.RData")
Metabric <- cbind(DS, VS)
rm(DS, VS)

Genes$IlluminaID <- as.character(Genes$IlluminaID)
common.probes <- intersect(rownames(Metabric), Genes$IlluminaID)
Genes <- Genes[which(Genes$IlluminaID %in% common.probes),]
Metabric <- Metabric[which(rownames(Metabric) %in% Genes$IlluminaID),]
PDX <- PDX[which(rownames(PDX) %in% Genes$symbol2),]
Genes <- Genes[match(rownames(PDX), Genes$symbol2),]
Metabric <- Metabric[match(Genes$IlluminaID, rownames(Metabric)),]
mean(rownames(Metabric) == Genes$IlluminaID)
mean(rownames(PDX) == Genes$symbol2)
rownames(Metabric) <- Genes$symbol2
mean(rownames(Metabric) == rownames(PDX))

Exp <- cbind(Metabric, PDX)
library(preprocessCore)
AllExp <- normalize.quantiles(Exp)
dimnames(AllExp) <- dimnames(Exp)
AllExp <- apply(AllExp, 1, scale)
AllExp <- t(AllExp)
dimnames(AllExp) <- dimnames(Exp)

source("classifier_functions.R")
tg <- ThreeGene(AllExp)

y <- data.frame(ID=names(tg), ThreeGene=tg)
y$ID <- sub(".", "-", y$ID, fixed=TRUE)
y <- merge(y, pam)


iC10.PDX <- merge(iC10.PDX, y, all.x=TRUE)
iC10.PDX <- iC10.PDX[order(iC10.PDX$Tumour, iC10.PDX$ID),]

iC10.PDX$threeGene <- do.call("c", sapply(split(iC10.PDX, iC10.PDX$Tumour),
       function(x) {
           scores <- table(x$ThreeGene)
           if (sum(!is.na(scores))>0) {
               ids <- names(which(scores == max(scores, na.rm=T)))
               if (length(ids)>1) ids <- "NC"
           } else ids <- NA
           rep(ids, nrow(x))
       }))

iC10.PDX$pam50 <- do.call("c", sapply(split(iC10.PDX, iC10.PDX$Tumour),
       function(x) {
           scores <- tapply(x$Pam50.score, x$Pam50, sum)
           if (sum(!is.na(scores))>0) {
               ids <- names(which(scores == max(scores, na.rm=T)))
               if (length(ids)>1) ids <- "NC"
           } else ids <- NA
           rep(ids, nrow(x))
       }))

## ER/HER2/PR

library(mclust)
ER <- unclass(AllExp['ESR1',])
plot(density(ER))
names(ER) <- colnames(ER)
clust <- Mclust(ER, G=2)
ER <- clust$classification
ER <- factor(ER, levels=c(1,2), labels=c("-", "+"))
names(ER) <- colnames(AllExp)

HER2 <- unclass(AllExp['ERBB2',])
plot(density(HER2))
clust <- Mclust(HER2, G=2)
HER2 <- clust$classification
HER2 <- factor(HER2, levels=c(1,2), labels=c("-", "+"))
names(HER2) <- colnames(AllExp)

PR <- unclass(AllExp['PGR',])
plot(density(PR))
clust <- Mclust(PR, G=2)
PR <- clust$classification
PR <- factor(PR, levels=c(1,2), labels=c("-", "+"))
names(PR) <- colnames(AllExp)
ER <- data.frame(ID=names(ER), er=ER, her2=HER2, pr=PR)
iC10.PDX <- merge(iC10.PDX, ER, all.x=T)

iC10.PDX <- iC10.PDX[order(iC10.PDX$Tumour, iC10.PDX$ID),]
iC10.PDX$ER <- do.call("c", sapply(split(iC10.PDX, iC10.PDX$Tumour),
       function(x) {
           scores <- table(x$er)
           if (sum(!is.na(scores))>0) {
               ids <- names(which(scores == max(scores, na.rm=T)))
               if (length(ids)>1) ids <- "NC"
           } else ids <- NA
           rep(ids, nrow(x))
       }))
iC10.PDX$HER2 <- do.call("c", sapply(split(iC10.PDX, iC10.PDX$Tumour),
       function(x) {
           scores <- table(x$her2)
           if (sum(!is.na(scores))>0) {
               ids <- names(which(scores == max(scores, na.rm=T)))
               if (length(ids)>1) ids <- "NC"
           } else ids <- NA
           rep(ids, nrow(x))
       }))
iC10.PDX$PR <- do.call("c", sapply(split(iC10.PDX, iC10.PDX$Tumour),
       function(x) {
           scores <- table(x$pr)
           if (sum(!is.na(scores))>0) {
               ids <- names(which(scores == max(scores, na.rm=T)))
               if (length(ids)>1) ids <- "NC"
           } else ids <- NA
           rep(ids, nrow(x))
       }))



write.table(iC10.PDX, file="/Expression/PDXiC10.txt", row.names=F, quote=F, sep="\t")

X <- iC10.PDX[,c('Tumour', 'ER.status', 'Her.2.status',
                 'BRCA.status', 'iC10', 'threeGene', 'pam50', 'ER', 'HER2', 'PR')]
X <- unique(X)

write.table(X, file="/Expression/ModelsClassifiers.txt", row.names=F, quote=F, sep="\t")


coliCluster.plus <- c('#FF5500', '#00EE76', '#CD3278', '#00C5CD',
                      '#00C5CD','#8B0000',
                '#FFFF40', '#0000CD', '#FFAA00', '#EE82EE', '#7D26CD')

SS <- SS[,c('Tumour', 'Include')]
SS <- unique(SS)
SS <- unique(SS$Tumour[which(SS$Include=="YES")])
X <- X[which(!is.na(X$iC10)),]
X <- X[which(X$Tumour %in% SS | X$Tumour == "AB569"),]
X <- rbind(100*prop.table(table(Clinical$Group)), 100*prop.table(table(X$iC10)))
rownames(X) <- c("Clinical frequencies", "PDTX frequencies")
ids <- c(6, 2, 11, 7, 10, 1, 5, 4, 9, 8, 3)
X <- X[,ids]

pdf("/Expression/iC10Comparison_V2.pdf", width=9, height=7)
par(mfrow=c(1,1))
barplot(X, beside=T, horiz=T, las=2, col=rep(coliCluster.plus[ids], each=2), density=c(1000, 15), xlab="Percentage",
        legend.text=rownames(X), args.legend=list(x=40, y=30))
dev.off()
