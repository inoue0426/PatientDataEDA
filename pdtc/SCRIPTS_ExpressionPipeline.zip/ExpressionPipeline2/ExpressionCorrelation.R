## Correlation with all genes

load("/Expression/NormalizedAllSamples.RData")
library(beadarray)
X <- read.csv("/Expression/ExpressionFullSampleSheet.csv", skip=7, stringsAsFactors=FALSE)
X$Tumour[which(X$Tumour=="VHIO6")] <- "VHIO006"
Exp <- exprs(normData.filt)
Annot <- fData(normData.filt)
X$TYPE[which(X$Type %in% c("Tumour", "primary tumour"))] <- "Tumour"

X <- X[which(X$ID %in% pData(normData.filt)$ID),]
X <- X[match(pData(normData.filt)$ID, X$ID),]

colnames(Exp) <- X$ID

Exp <- Exp[,which(X$TYPE!="Normal")]
X <- X[which(X$TYPE!="Normal"),]

Exp <- Exp[,which(X$Include=="YES")]
X <- X[which(X$Include=="YES"),]



sum(sapply(split(X, X$Tumour), function(x) sum(x$TYPE=="PDTX") * (1 * any(x$TYPE=="Tumour"))))
sum(sapply(split(X, X$Tumour), function(x) {
    tmp <- sum(x$TYPE=="PDTX")
    ifelse(tmp>1, choose(tmp, 2), 0)
}))

sum(sapply(split(X, X$Tumour), function(x) sum(x$TYPE=="PDTX")))
sum(sapply(split(X, interaction(X$PASSAGE, X$Tumour)), function(x) {
    tmp <- sum(x$TYPE=="PDTX")
    ifelse(tmp>1, tmp, 0)
}))
sum(sapply(split(X, X$Tumour), function(x) sum(x$TYPE=="Tumour")>1)) +
    sum(sapply(split(X, interaction(X$PASSAGE, X$Tumour)), function(x) {
        tmp <- sum(x$TYPE=="PDTX" & x$TECHNICAL=="TECHNICAL")
    ifelse(tmp>1, tmp, 0)
}))

length(unique(X$Tumour[which(X$TYPE=="Tumour")]))


all.cor.rep.pdx <- list()
all.cor.pass.pdx <- list()
all.cor.tum.pdx <- list()
all.cor.tum.tum <- list()

for (i in unique(X$Tumour)) {
    ## Replicate PDXs
    all.cor.rep.pdx[[i]] <- c()
    sub.X <- X[which(X$Tumour==i),]
    sub.Exp <- Exp[,which(X$Tumour==i)]
    PDX <- which(sub.X$TYPE=="PDTX")
    for (j in PDX) {
        ids <- which(sub.X$PASSAGE==sub.X$PASSAGE[j] & sub.X$TECHNICAL=="BIOLOGICAL")
        if (length(ids) > 1) {
            tmp <- cor(sub.Exp[,ids], use="pairwise.complete.obs", method="pearson")
            tmp <- tmp[row(tmp)>col(tmp)]
            all.cor.rep.pdx[[i]] <- c(all.cor.rep.pdx[[i]], tmp)
        }
    }
    all.cor.rep.pdx[[i]] <- unique(all.cor.rep.pdx[[i]])
    ## Different PDXs passages
    all.cor.pass.pdx[[i]] <- c()
    sub.X <- X[which(X$Tumour==i),]
    sub.Exp <- Exp[,which(X$Tumour==i)]
    PDX <- which(sub.X$TYPE=="PDTX")
    for (j in PDX) {
        ids <- which(sub.X$TYPE=="PDTX" & sub.X$PASSAGE!=sub.X$PASSAGE[j])
        if (length(ids) > 1) {
            tmp <- cor(sub.Exp[,ids], use="pairwise.complete.obs", method="pearson")
            tmp <- tmp[row(tmp)>col(tmp)]
            all.cor.pass.pdx[[i]] <- c(all.cor.pass.pdx[[i]], tmp)
        }
    }
    all.cor.pass.pdx[[i]] <- unique(all.cor.pass.pdx[[i]])
    ## Tumours vs PDXs
    all.cor.tum.pdx[[i]] <- c()
    sub.X <- X[which(X$Tumour==i),]
    sub.Exp <- Exp[,which(X$Tumour==i)]
    Tum <- which(sub.X$TYPE=="Tumour")
    PDX <- which(sub.X$TYPE=="PDTX")
    if (length(Tum)>0 & length(PDX)>0) {
        for (j in Tum) {
            tmp <- cor(sub.Exp[,j], sub.Exp[,PDX], use="pairwise.complete.obs", method="pearson")
            all.cor.tum.pdx[[i]] <- c(all.cor.tum.pdx[[i]], tmp)
        }
    }
    ## Tumours vs Tumours
    all.cor.tum.tum[[i]] <- c()
    Tum <- which(X$TYPE=="Tumour" & X$Tumour==i)
    Other <- which(X$TYPE=="Tumour" & X$Tumour!=i)
    if (length(Tum)>0) {
        for (j in Tum) {
            tmp <- cor(Exp[,j], Exp[,Other], use="pairwise.complete.obs", method="pearson")
            all.cor.tum.tum[[i]] <- c(all.cor.tum.tum[[i]], tmp)
        }
    }

}

all.cor.rep.pdx <- do.call("c", all.cor.rep.pdx)
all.cor.pass.pdx <- do.call("c", all.cor.pass.pdx)
all.cor.tum.pdx <- do.call("c", all.cor.tum.pdx)
all.cor.tum.tum <- do.call("c", all.cor.tum.tum)

## PDTCs
all.cor.pdtc.pdx <- c()
ids <- which(X$TYPE=="PDTC")
for (i in ids) {
    found <- which(X$Tumour==X$Tumour[i] & X$TYPE=="PDTX" & X$PASSAGE==X$PASSAGE[i])
    if (length(found)>0) {
        tmp <- cor(Exp[,i], Exp[,found], use="pairwise.complete.obs", method="pearson")
        all.cor.pdtc.pdx <- c(all.cor.pdtc.pdx, tmp)
    }
}

## Tumour (Technical replicate)
all.cor.tumour.tech <- c()
ids <- X[grep("TR", X$ID),'Tumour']
for (i in ids) {
    found <- which(X$Tumour==i & X$TYPE=="Tumour")
    tmp <- cor(Exp[,found], use="pairwise.complete.obs", method="pearson")
    tmp <- tmp[row(tmp)>col(tmp)]
    all.cor.tumour.tech <- c(all.cor.tumour.tech, tmp)
}
for (i in unique(X$Tumour)) {
    ## Replicate PDXs
    sub.X <- X[which(X$Tumour==i),]
    sub.Exp <- Exp[,which(X$Tumour==i)]
    PDX <- which(sub.X$TYPE=="PDTX")
    for (j in PDX) {
        ids <- which(sub.X$PASSAGE==sub.X$PASSAGE[j] & sub.X$TECHNICAL=="TECHNICAL")
        if (length(ids) > 1) {
            tmp <- cor(sub.Exp[,ids], use="pairwise.complete.obs", method="pearson")
            tmp <- tmp[row(tmp)>col(tmp)]
            all.cor.tumour.tech <- c(all.cor.tumour.tech, tmp)
        }
    }
}

round(summary(all.cor.tum.pdx), 2)
round(summary(all.cor.pass.pdx), 2)
round(summary(all.cor.pdtc.pdx), 2)

pdf("/Expression/Correlation_Expression.pdf", width=12, height=9)
boxplot(all.cor.tumour.tech, all.cor.pdtc.pdx,
all.cor.rep.pdx, all.cor.pass.pdx, all.cor.tum.pdx, all.cor.tum.tum,
        names=c("Tech. Replicates", "PDTCs vs PDXs", "Mice Replicates",
            "PDTXs Passages", "PDTX vs Tumour", "Different Tumours"), ylab="Pearson Correlation",
                col=c("grey", "red", "yellow", "olivedrab", "orange", "darkblue"), cex.lab=1.2, cex.axis=1.2)

## Spearman Correlation



all.cor.rep.pdx <- list()
all.cor.pass.pdx <- list()
all.cor.tum.pdx <- list()
all.cor.tum.tum <- list()

for (i in unique(X$Tumour)) {
    ## Replicate PDXs
    all.cor.rep.pdx[[i]] <- c()
    sub.X <- X[which(X$Tumour==i),]
    sub.Exp <- Exp[,which(X$Tumour==i)]
    PDX <- which(sub.X$TYPE=="PDTX")
    for (j in PDX) {
        ids <- which(sub.X$PASSAGE==sub.X$PASSAGE[j] & sub.X$TECHNICAL=="BIOLOGICAL")
        if (length(ids) > 1) {
            tmp <- cor(sub.Exp[,ids], use="pairwise.complete.obs", method="spearman")
            tmp <- tmp[row(tmp)>col(tmp)]
            all.cor.rep.pdx[[i]] <- c(all.cor.rep.pdx[[i]], tmp)
        }
    }
    all.cor.rep.pdx[[i]] <- unique(all.cor.rep.pdx[[i]])
    ## Different PDXs passages
    all.cor.pass.pdx[[i]] <- c()
    sub.X <- X[which(X$Tumour==i),]
    sub.Exp <- Exp[,which(X$Tumour==i)]
    PDX <- which(sub.X$TYPE=="PDTX")
    for (j in PDX) {
        ids <- which(sub.X$PASSAGE!=sub.X$PASSAGE[j])
        if (length(ids) > 1) {
            tmp <- cor(sub.Exp[,ids], use="pairwise.complete.obs", method="spearman")
            tmp <- tmp[row(tmp)>col(tmp)]
            all.cor.pass.pdx[[i]] <- c(all.cor.pass.pdx[[i]], tmp)
        }
    }
    all.cor.pass.pdx[[i]] <- unique(all.cor.pass.pdx[[i]])
    ## Tumours vs PDXs
    all.cor.tum.pdx[[i]] <- c()
    sub.X <- X[which(X$Tumour==i),]
    sub.Exp <- Exp[,which(X$Tumour==i)]
    Tum <- which(sub.X$TYPE=="Tumour")
    PDX <- which(sub.X$TYPE=="PDTX")
    if (length(Tum)>0 & length(PDX)>0) {
        for (j in Tum) {
            tmp <- cor(sub.Exp[,j], sub.Exp[,PDX], use="pairwise.complete.obs", method="spearman")
            all.cor.tum.pdx[[i]] <- c(all.cor.tum.pdx[[i]], tmp)
        }
    }
    ## Tumours vs Tumours
    all.cor.tum.tum[[i]] <- c()
    Tum <- which(X$TYPE=="Tumour" & X$Tumour==i)
    Other <- which(X$TYPE=="Tumour" & X$Tumour!=i)
    if (length(Tum)>0) {
        for (j in Tum) {
            tmp <- cor(Exp[,j], Exp[,Other], use="pairwise.complete.obs", method="spearman")
            all.cor.tum.tum[[i]] <- c(all.cor.tum.tum[[i]], tmp)
        }
    }

}

all.cor.rep.pdx <- do.call("c", all.cor.rep.pdx)
all.cor.pass.pdx <- do.call("c", all.cor.pass.pdx)
all.cor.tum.pdx <- do.call("c", all.cor.tum.pdx)
all.cor.tum.tum <- do.call("c", all.cor.tum.tum)

## PDTCs
all.cor.pdtc.pdx <- c()
ids <- which(X$TYPE=="PDTC")
for (i in ids) {
    found <- which(X$Tumour==X$Tumour[i] & X$TYPE=="PDTX" & X$PASSAGE==X$PASSAGE[i])
    if (length(found)>0) {
        tmp <- cor(Exp[,i], Exp[,found], use="pairwise.complete.obs", method="spearman")
        all.cor.pdtc.pdx <- c(all.cor.pdtc.pdx, tmp)
    }
}

## Tumour (Technical replicate)
all.cor.tumour.tech <- c()
ids <- X[grep("TR", X$ID),'Tumour']
for (i in ids) {
    found <- which(X$Tumour==i & X$TYPE=="Tumour")
    tmp <- cor(Exp[,found], use="pairwise.complete.obs", method="spearman")
    tmp <- tmp[row(tmp)>col(tmp)]
    all.cor.tumour.tech <- c(all.cor.tumour.tech, tmp)
}
for (i in unique(X$Tumour)) {
    ## Replicate PDXs
    sub.X <- X[which(X$Tumour==i),]
    sub.Exp <- Exp[,which(X$Tumour==i)]
    PDX <- which(sub.X$TYPE=="PDTX")
    for (j in PDX) {
        ids <- which(sub.X$PASSAGE==sub.X$PASSAGE[j] & sub.X$TECHNICAL=="TECHNICAL")
        if (length(ids) > 1) {
            tmp <- cor(sub.Exp[,ids], use="pairwise.complete.obs", method="spearman")
            tmp <- tmp[row(tmp)>col(tmp)]
            all.cor.tumour.tech <- c(all.cor.tumour.tech, tmp)
        }
    }
}


boxplot(all.cor.tumour.tech, all.cor.pdtc.pdx, all.cor.rep.pdx,
        all.cor.pass.pdx, all.cor.tum.pdx, all.cor.tum.tum,
        names=c("Tech Replicates", "PDTCs vs PDXs", "Mice Replicates",
            "PDTXs Passages", "PDTX vs Tumour",
"Different Tumours"), ylab="Spearman Correlation",
                col=c("grey", "red", "yellow", "olivedrab", "orange", "darkblue"), cex.lab=1.2, cex.axis=1.2)
dev.off()

##################################################
##################################################
## Pathways
##################################################
##################################################

load(file="/Expression/pathwaysReduced.RData")
all.res <- all.res[,which(colnames(all.res) %in% X$ID)]
mean(X$ID == colnames(all.res))
Exp <- all.res

all.cor.rep.pdx <- list()
all.cor.pass.pdx <- list()
all.cor.tum.pdx <- list()
all.cor.tum.tum <- list()

for (i in unique(X$Tumour)) {
    ## Replicate PDXs
    all.cor.rep.pdx[[i]] <- c()
    sub.X <- X[which(X$Tumour==i),]
    sub.Exp <- Exp[,which(X$Tumour==i)]
    PDX <- which(sub.X$TYPE=="PDTX")
    for (j in PDX) {
        ids <- which(sub.X$PASSAGE==sub.X$PASSAGE[j] & sub.X$TECHNICAL=="BIOLOGICAL")
        if (length(ids) > 1) {
            tmp <- cor(sub.Exp[,ids], use="pairwise.complete.obs", method="pearson")
            tmp <- tmp[row(tmp)>col(tmp)]
            all.cor.rep.pdx[[i]] <- c(all.cor.rep.pdx[[i]], tmp)
        }
    }
    all.cor.rep.pdx[[i]] <- unique(all.cor.rep.pdx[[i]])
    ## Different PDXs passages
    all.cor.pass.pdx[[i]] <- c()
    sub.X <- X[which(X$Tumour==i),]
    sub.Exp <- Exp[,which(X$Tumour==i)]
    PDX <- which(sub.X$TYPE=="PDTX")
    for (j in PDX) {
        ids <- which(sub.X$PASSAGE!=sub.X$PASSAGE[j])
        if (length(ids) > 1) {
            tmp <- cor(sub.Exp[,ids], use="pairwise.complete.obs", method="pearson")
            tmp <- tmp[row(tmp)>col(tmp)]
            all.cor.pass.pdx[[i]] <- c(all.cor.pass.pdx[[i]], tmp)
        }
    }
    all.cor.pass.pdx[[i]] <- unique(all.cor.pass.pdx[[i]])
    ## Tumours vs PDXs
    all.cor.tum.pdx[[i]] <- c()
    sub.X <- X[which(X$Tumour==i),]
    sub.Exp <- Exp[,which(X$Tumour==i)]
    Tum <- which(sub.X$TYPE=="Tumour")
    PDX <- which(sub.X$TYPE=="PDTX")
    if (length(Tum)>0 & length(PDX)>0) {
        for (j in Tum) {
            tmp <- cor(sub.Exp[,j], sub.Exp[,PDX], use="pairwise.complete.obs", method="pearson")
            all.cor.tum.pdx[[i]] <- c(all.cor.tum.pdx[[i]], tmp)
        }
    }
    ## Tumours vs Tumours
    all.cor.tum.tum[[i]] <- c()
    Tum <- which(X$TYPE=="Tumour" & X$Tumour==i)
    Other <- which(X$TYPE=="Tumour" & X$Tumour!=i)
    if (length(Tum)>0) {
        for (j in Tum) {
            tmp <- cor(Exp[,j], Exp[,Other], use="pairwise.complete.obs", method="pearson")
            all.cor.tum.tum[[i]] <- c(all.cor.tum.tum[[i]], tmp)
        }
    }

}

all.cor.rep.pdx <- do.call("c", all.cor.rep.pdx)
all.cor.pass.pdx <- do.call("c", all.cor.pass.pdx)
all.cor.tum.pdx <- do.call("c", all.cor.tum.pdx)
all.cor.tum.tum <- do.call("c", all.cor.tum.tum)

## PDTCs
all.cor.pdtc.pdx <- c()
ids <- which(X$TYPE=="PDTC")
for (i in ids) {
    found <- which(X$Tumour==X$Tumour[i] & X$TYPE=="PDTX" & X$PASSAGE==X$PASSAGE[i])
    if (length(found)>0) {
        tmp <- cor(Exp[,i], Exp[,found], use="pairwise.complete.obs", method="pearson")
        all.cor.pdtc.pdx <- c(all.cor.pdtc.pdx, tmp)
    }
}

## Tumour (Technical replicate)
all.cor.tumour.tech <- c()
ids <- X[grep("TR", X$ID),'Tumour']
for (i in ids) {
    found <- which(X$Tumour==i & X$TYPE=="Tumour")
    tmp <- cor(Exp[,found], use="pairwise.complete.obs", method="pearson")
    tmp <- tmp[row(tmp)>col(tmp)]
    all.cor.tumour.tech <- c(all.cor.tumour.tech, tmp)
}
for (i in unique(X$Tumour)) {
    ## Replicate PDXs
    sub.X <- X[which(X$Tumour==i),]
    sub.Exp <- Exp[,which(X$Tumour==i)]
    PDX <- which(sub.X$TYPE=="PDTX")
    for (j in PDX) {
        ids <- which(sub.X$PASSAGE==sub.X$PASSAGE[j] & sub.X$TECHNICAL=="TECHNICAL")
        if (length(ids) > 1) {
            tmp <- cor(sub.Exp[,ids], use="pairwise.complete.obs", method="pearson")
            tmp <- tmp[row(tmp)>col(tmp)]
            all.cor.tumour.tech <- c(all.cor.tumour.tech, tmp)
        }
    }
}

round(summary(all.cor.tum.pdx), 2)
round(summary(all.cor.pass.pdx), 2)
round(summary(all.cor.pdtc.pdx), 2)


pdf("/Expression/Correlation_Expression_Pathways.pdf", width=12, height=9)
boxplot(all.cor.tumour.tech, all.cor.pdtc.pdx,
all.cor.rep.pdx, all.cor.pass.pdx, all.cor.tum.pdx, all.cor.tum.tum,
        names=c("Tech. Replicates", "PDTCs vs PDXs", "Mice Replicates",
            "PDTXs Passages", "PDTX vs Tumour", "Different Tumours"), ylab="Pearson Correlation",
                col=c("grey", "red", "yellow", "olivedrab", "orange", "darkblue"), cex.lab=1.2, cex.axis=1.2)

## Spearman Correlation



all.cor.rep.pdx <- list()
all.cor.pass.pdx <- list()
all.cor.tum.pdx <- list()
all.cor.tum.tum <- list()

for (i in unique(X$Tumour)) {
    ## Replicate PDXs
    all.cor.rep.pdx[[i]] <- c()
    sub.X <- X[which(X$Tumour==i),]
    sub.Exp <- Exp[,which(X$Tumour==i)]
    PDX <- which(sub.X$TYPE=="PDTX")
    for (j in PDX) {
        ids <- which(sub.X$TYPE=="PDTX" & sub.X$PASSAGE==sub.X$PASSAGE[j] & sub.X$TECHNICAL=="BIOLOGICAL")
        if (length(ids) > 1) {
            tmp <- cor(sub.Exp[,ids], use="pairwise.complete.obs", method="spearman")
            tmp <- tmp[row(tmp)>col(tmp)]
            all.cor.rep.pdx[[i]] <- c(all.cor.rep.pdx[[i]], tmp)
        }
    }
    all.cor.rep.pdx[[i]] <- unique(all.cor.rep.pdx[[i]])
    ## Different PDXs passages
    all.cor.pass.pdx[[i]] <- c()
    sub.X <- X[which(X$Tumour==i),]
    sub.Exp <- Exp[,which(X$Tumour==i)]
    PDX <- which(sub.X$TYPE=="PDTX")
    for (j in PDX) {
        ids <- which(sub.X$PASSAGE!=sub.X$PASSAGE[j])
        if (length(ids) > 1) {
            tmp <- cor(sub.Exp[,ids], use="pairwise.complete.obs", method="spearman")
            tmp <- tmp[row(tmp)>col(tmp)]
            all.cor.pass.pdx[[i]] <- c(all.cor.pass.pdx[[i]], tmp)
        }
    }
    all.cor.pass.pdx[[i]] <- unique(all.cor.pass.pdx[[i]])
    ## Tumours vs PDXs
    all.cor.tum.pdx[[i]] <- c()
    sub.X <- X[which(X$Tumour==i),]
    sub.Exp <- Exp[,which(X$Tumour==i)]
    Tum <- which(sub.X$TYPE=="Tumour")
    PDX <- which(sub.X$TYPE=="PDTX")
    if (length(Tum)>0 & length(PDX)>0) {
        for (j in Tum) {
            tmp <- cor(sub.Exp[,j], sub.Exp[,PDX], use="pairwise.complete.obs", method="spearman")
            all.cor.tum.pdx[[i]] <- c(all.cor.tum.pdx[[i]], tmp)
        }
    }
    ## Tumours vs Tumours
    all.cor.tum.tum[[i]] <- c()
    Tum <- which(X$TYPE=="Tumour" & X$Tumour==i)
    Other <- which(X$TYPE=="Tumour" & X$Tumour!=i)
    if (length(Tum)>0) {
        for (j in Tum) {
            tmp <- cor(Exp[,j], Exp[,Other], use="pairwise.complete.obs", method="spearman")
            all.cor.tum.tum[[i]] <- c(all.cor.tum.tum[[i]], tmp)
        }
    }

}

all.cor.rep.pdx <- do.call("c", all.cor.rep.pdx)
all.cor.pass.pdx <- do.call("c", all.cor.pass.pdx)
all.cor.tum.pdx <- do.call("c", all.cor.tum.pdx)
all.cor.tum.tum <- do.call("c", all.cor.tum.tum)

## PDTCs
all.cor.pdtc.pdx <- c()
ids <- which(X$TYPE=="PDTC")
for (i in ids) {
    found <- which(X$Tumour==X$Tumour[i] & X$TYPE=="PDTX" & X$PASSAGE==X$PASSAGE[i])
    if (length(found)>0) {
        tmp <- cor(Exp[,i], Exp[,found], use="pairwise.complete.obs", method="spearman")
        all.cor.pdtc.pdx <- c(all.cor.pdtc.pdx, tmp)
    }
}

## Tumour (Technical replicate)
all.cor.tumour.tech <- c()
ids <- X[grep("TR", X$ID),'Tumour']
for (i in ids) {
    found <- which(X$Tumour==i & X$TYPE=="Tumour")
    tmp <- cor(Exp[,found], use="pairwise.complete.obs", method="spearman")
    tmp <- tmp[row(tmp)>col(tmp)]
    all.cor.tumour.tech <- c(all.cor.tumour.tech, tmp)
}
for (i in unique(X$Tumour)) {
    ## Replicate PDXs
    sub.X <- X[which(X$Tumour==i),]
    sub.Exp <- Exp[,which(X$Tumour==i)]
    PDX <- which(sub.X$TYPE=="PDTX")
    for (j in PDX) {
        ids <- which(sub.X$PASSAGE==sub.X$PASSAGE[j] & sub.X$TECHNICAL=="TECHNICAL")
        if (length(ids) > 1) {
            tmp <- cor(sub.Exp[,ids], use="pairwise.complete.obs", method="spearman")
            tmp <- tmp[row(tmp)>col(tmp)]
            all.cor.tumour.tech <- c(all.cor.tumour.tech, tmp)
        }
    }
}


boxplot(all.cor.tumour.tech, all.cor.pdtc.pdx, all.cor.rep.pdx,
        all.cor.pass.pdx, all.cor.tum.pdx, all.cor.tum.tum,
        names=c("Tech Replicates", "PDTCs vs PDXs", "Mice Replicates",
            "PDTXs Passages", "PDTX vs Tumour",
"Different Tumours"), ylab="Spearman Correlation",
                col=c("grey", "red", "yellow", "olivedrab", "orange", "darkblue"), cex.lab=1.2, cex.axis=1.2)
dev.off()



## Lets see the outliers
all.cor.tum.pdx <- list()
all.names.tum.pdx <- list()
 for (i in unique(X$Tumour)) {
    ## Tumours vs PDXs
    all.cor.tum.pdx[[i]] <- c()
    sub.X <- X[which(X$Tumour==i),]
    sub.Exp <- Exp[,which(X$Tumour==i)]
    Tum <- which(sub.X$TYPE=="Tumour")
    PDX <- which(sub.X$TYPE=="PDTX")
    if (length(Tum)>0 & length(PDX)>0) {
        for (j in Tum) {
            tmp <- cor(sub.Exp[,j], sub.Exp[,PDX], use="pairwise.complete.obs", method="spearman")
	    tmp2 <- as.character(sub.X$ID[PDX])
            all.cor.tum.pdx[[i]] <- c(all.cor.tum.pdx[[i]], tmp)
            all.names.tum.pdx[[i]] <- c(all.names.tum.pdx[[i]], tmp2)
        }
    }
}

all.names <- c()
for (i in 1:length(all.names.tum.pdx)) {
    all.names <- c(all.names, paste(names(all.names.tum.pdx)[i], all.names.tum.pdx[[i]], sep=".vs."))
}
all.cor.tum.pdx <- do.call("c", all.cor.tum.pdx)
names(all.cor.tum.pdx) <- all.names
pdf("/Volumes/PDX/Expression/CorTumvsPDX_PATHWAYS.pdf", width=12, height=16)
dotchart(sort(all.cor.tum.pdx), pch=19)
dev.off()

library(limma)

counts <- table(X$Tumour, X$TYPE)
ids <- names(which(apply(counts, 1, function(x) any(x[2]>0 & x[3]>0))))
sub.X <- X[which(X$Tumour %in% ids & X$TYPE %in% c("Tumour", "PDTX")),]
colnames(Exp) <- X$ID
sub.Exp <- Exp[,which(colnames(Exp) %in% sub.X$ID)]
sub.X$Tumour  <- factor(sub.X$Tumour)
sub.X$TYPE  <- factor(sub.X$TYPE)
design <- model.matrix(~sub.X$Tumour + sub.X$TYPE -1)
m1 <- lmFit(sub.Exp, design)
m1 <- eBayes(m1)
res <- topTable(m1, coef=13, n=nrow(m1))
write.table(res, file="/Volumes/PDX/Expression/TumvsPDTX_limma.txt", row.names=T, quote=F, sep="\t")
pdf("/Volumes/PDX/Expression/PATHWAYS_That_Change_From_T_to_PDTX.pdf", width=8, height=8)
for (p in 1:nrow(res)) {
    toplot <- NULL
    tmp <- sub.Exp[which(rownames(sub.Exp)==rownames(res)[p]),]
    for (i in unique(sub.X$Tumour)) {
    	for (j in sub.X$ID[which(sub.X$Tumour==i & sub.X$TYPE=="Tumour")]) {
	       x <- tmp[j]
	       for (k in sub.X$ID[which(sub.X$Tumour==i & sub.X$TYPE=="PDTX")]) {
	       y <- tmp[k]
	       feo <- data.frame("T"=x, "PDTX"=y)
	       toplot <- rbind(toplot, feo)
	       }
	  }
    }
    plot(toplot, xlab="Tumour", ylab="PDTX", ylim=range(toplot), pch=19, main=rownames(res)[p])
}
dev.off()

ids <- names(which(apply(counts, 1, function(x) any(x[3]>0 & x[2]>0))))
sub.X <- X[which(X$Tumour %in% ids & X$TYPE %in% c("PDTC", "PDTX")),]
sub.Exp <- Exp[,which(colnames(Exp) %in% sub.X$ID)]
sub.X$Tumour  <- factor(sub.X$Tumour)
sub.X$TYPE  <- factor(sub.X$TYPE)
design <- model.matrix(~sub.X$Tumour + sub.X$TYPE -1)
m1 <- lmFit(sub.Exp, design)
m1 <- eBayes(m1)
res <- topTable(m1, coef=4, n=nrow(m1))
write.table(res, file="/Volumes/PDX/Expression/PDTXvsPDTC_limma.txt", row.names=T, quote=F, sep="\t")


counts <- table(X$Tumour, X$TYPE)
ids <- names(which(apply(counts, 1, function(x) any(x[2]>0 & x[3]>0))))
sub.X <- X[which(X$Tumour %in% ids & X$TYPE %in% c("Tumour", "PDTX")),]
colnames(Exp) <- X$ID
sub.Exp <- Exp[,which(colnames(Exp) %in% sub.X$ID)]
sub.X$Tumour  <- factor(sub.X$Tumour)
sub.X$TYPE  <- factor(sub.X$TYPE)
cor.paths <- numeric(nrow(res))
deviance.paths <- numeric(nrow(res))
library(mgcv)
for (p in 1:nrow(res)) {
    toplot <- NULL
    tmp <- sub.Exp[which(rownames(sub.Exp)==rownames(res)[p]),]
    for (i in unique(sub.X$Tumour)) {
    	for (j in sub.X$ID[which(sub.X$Tumour==i & sub.X$TYPE=="Tumour")]) {
	       x <- tmp[j]
	       for (k in sub.X$ID[which(sub.X$Tumour==i & sub.X$TYPE=="PDTX")]) {
	       y <- tmp[k]
	       feo <- data.frame("T"=x, "PDTX"=y)
	       toplot <- rbind(toplot, feo)
	       }
	  }
    }
    tmp <- gam(T ~ s(PDTX), data=toplot)
    deviance.paths[p] <- 100 * summary(tmp)$dev.expl
    cor.paths[p] <- cor(toplot$T, toplot$PDTX, method="spearman")
}



pdf("/Expression/TvsPDTXPlots.pdf", width=8, height=8)
plot(density(deviance.paths), main="% Deviance between Tumour and PDTX")
plot(density(cor.paths), main="Rank Correlation between Tumour and PDTX")

plot(deviance.paths, cor.paths, xlab="Prediction (% Deviance)", ylab="Reproducibility (Spearman Correlation)",
     pch=19)
abline(h=c(0, .20), v=c(0, 20), col=2)
bads <- which(cor.paths<0 | deviance.paths<0.2)
for (p in bads) {
    toplot <- NULL
    tmp <- sub.Exp[which(rownames(sub.Exp)==rownames(res)[p]),]
    for (i in unique(sub.X$Tumour)) {
    	for (j in sub.X$ID[which(sub.X$Tumour==i & sub.X$TYPE=="Tumour")]) {
	       x <- tmp[j]
	       for (k in sub.X$ID[which(sub.X$Tumour==i & sub.X$TYPE=="PDTX")]) {
	       y <- tmp[k]
	       feo <- data.frame("T"=x, "PDTX"=y)
	       toplot <- rbind(toplot, feo)
	       }
	  }
    }
    plot(toplot, xlab="Tumour", ylab="PDTX", ylim=range(toplot), pch=19, main=rownames(res)[p])
}
dev.off()


names(deviance.paths) <- rownames(res)
names(cor.paths) <- rownames(res)

pdf("/Expression/FigureS1C.pdf", width=8, height=8)
plot(deviance.paths, cor.paths, xlab="Prediction (% Deviance)", ylab="Reproducibility (Spearman Correlation)",
     pch=19, cex.lab=1.5, cex.axis=1.5)
abline(h=c(0, .20), v=c(0, 20), col=2)
size.text <- 1.25
text(deviance.paths['PTEN_DN.V1'], cor.paths['PTEN_DN.V1'], "PTEN", pos=1, cex=size.text)
text(deviance.paths['PTEN_DN.V1'], cor.paths['PTEN_DN.V1'], "PTEN", pos=1, cex=size.text)
text(deviance.paths['P53_DN.V1'], cor.paths['P53_DN.V1'], "TP53", pos=1, cex=size.text)
text(deviance.paths['BRCA1_DN.V1'], cor.paths['BRCA1_DN.V1'], "BRCA1", pos=1, cex=size.text)
text(deviance.paths['ERB2_UP.V1'], cor.paths['ERB2_UP.V1'], "ERBB2", pos=1, cex=size.text)
text(deviance.paths['CYCLIN_D1_UP.V1'], cor.paths['CYCLIN_D1_UP.V1'], "CyclinD1", pos=1, cex=size.text)
dev.off()
