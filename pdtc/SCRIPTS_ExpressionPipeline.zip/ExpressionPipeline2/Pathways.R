load(file="/VExpression/PDX_Genes_Expression.RData")

PDX <- PDX[,which(SS$TYPE!="Normal")]
SS <- SS[which(SS$TYPE!="Normal"),]

load(“/MetabricExpressionDiscoverySet997.RData")
load("/Metabric2/MetabricExpressionValidationSet983.RData")
Metabric <- cbind(DS, VS)
rm(DS, VS)

Genes$IlluminaID <- as.character(Genes$IlluminaID)
common.probes <- intersect(rownames(Metabric), Genes$IlluminaID)
Genes <- Genes[which(Genes$IlluminaID %in% common.probes),]
Metabric <- Metabric[which(rownames(Metabric) %in% Genes$IlluminaID),]
PDX <- PDX[which(rownames(PDX) %in% Genes$symbol2),]
Genes <- Genes[match(rownames(PDX), Genes$symbol2),]
Metabric <- Metabric[match(Genes$IlluminaID, rownames(Metabric)),]
mean(rownames(Metabric) == Genes$IlluminaID)
mean(rownames(PDX) == Genes$symbol2)
rownames(Metabric) <- Genes$symbol2
mean(rownames(Metabric) == rownames(PDX))

Exp <- cbind(Metabric, PDX)
library(preprocessCore)
AllExp <- normalize.quantiles(Exp)
dimnames(AllExp) <- dimnames(Exp)
AllExp <- apply(AllExp, 1, scale)
AllExp <- t(AllExp)
dimnames(AllExp) <- dimnames(Exp)

library(GSA)
library(GSVA)
geneset.obj<- GSA.read.gmt("/c6.all.v4.0.symbols.gmt.txt")
DDR <- read.table("/DDR_pathway.txt")
geneset.obj$geneset.names <- c(geneset.obj$geneset.names, "DDR")
N <- length(geneset.obj$genesets)
geneset.obj$genesets[[N+1]] <- DDR$V1
PI3K <- read.table("/PI3K_AKT_mTOR.txt")
PI3K <- unique(PI3K$V1)
geneset.obj$geneset.names <- c(geneset.obj$geneset.names, "PI3K/AKT/mTOR")
N <- length(geneset.obj$genesets)
geneset.obj$genesets[[N+1]] <- PI3K

m2 <- gsva(expr=AllExp, gset.idx.list=geneset.obj$genesets, method="gsva", verbose=TRUE, parallel.sz=2)
res <- m2$es.obs
rownames(res) <- geneset.obj$geneset.names
save(res, file="/Expression/pathways.RData")

candidates <- grep("DN$", rownames(res))
all.res <- NULL
all.names <- NULL
toremove <- NULL
for (i in candidates) {
    up <- sub("_DN$", "_UP", rownames(res)[i])
    ids.up <- which(rownames(res) == up)
    if (length(ids.up) > 0) {
        tmp <- res[ids.up,] - res[i,]
        all.res <- rbind(all.res, tmp)
        all.names <- c(all.names, sub("_UP$", "", up))
        toremove <- c(toremove, i, ids.up)
    }
}
rownames(all.res) <- all.names

all.res <- rbind(all.res, res[-c(toremove),])

save(all.res, file="/Expression/pathwaysReduced.RData")
all.res <- all.res[,1981:2155]
write.table(all.res, file="/Expression/pathwaysReduced.txt", sep="\t", quote=F)

all.res <- read.table(file="/Expression/pathwaysReduced.txt", sep="\t", header=TRUE)
colnames(all.res) <- gsub(".", "-", colnames(all.res), fixed=TRUE)
SS <- read.csv("/Expression/ExpressionFullSampleSheet.csv", skip=7)
SS <- SS[order(SS$ID,SS$PASSAGE),]
SS <- SS[which(SS$ID %in% colnames(all.res)),]

SS <- SS[which(SS$Include=="YES"),]
all.res <- all.res[,which(colnames(all.res) %in% SS$ID)]
SS <- SS[match(colnames(all.res), SS$ID),]

pdf("/Expression/Concordance_Pathways.pdf", width=10, height=10)
par(oma=c(4, 2, 2, 4))

for (i in sort(as.character(unique(SS$Tumour)))) {
    sub.SS <- SS[which(SS$Tumour==i),]
    if (nrow(sub.SS) > 1) {
        sub.SS <- sub.SS[order(sub.SS$PASSAGE, sub.SS$ID),]
        res <- all.res[,which(colnames(all.res) %in% sub.SS$ID)]
        res <- res[,match(sub.SS$ID, colnames(res))]
        pairs(res, pch=19)
    }
}
    dev.off()


paths <- read.table(file="/Expression/pathwaysReduced.txt", sep="\t", header=T)
paths <- as.matrix(paths)
colnames(paths) <- gsub(".", "-", colnames(paths), fixed=TRUE)

SS <- read.csv("/Expression/ExpressionFullSampleSheet.csv", skip=7)
paths <- paths[,which(colnames(paths) %in% SS$ID)]

SS <- SS[which(SS$ID %in% colnames(paths)),]
SS <- SS[match(colnames(paths), SS$ID),]
models <- t(table(SS$TYPE, SS$Tumour))
models <- models[which(models[,'Tumour']>0 & models[,'PDTX']>0),]
res <- NULL
all.names <- NULL
count <- 1
for (i in rownames(models)) {
    ids.T <- as.character(SS$ID[which(SS$Tumour==i & SS$TYPE=="Tumour")])
    ids.P <- as.character(SS$ID[which(SS$Tumour==i & SS$TYPE=="PDTX")])
    ref <- paths[,which(colnames(paths) %in% ids.T)]
    if (!is.null(dim(ref))) {
       ref <- apply(ref, 1, mean)
       }
     res <- cbind(res, apply(paths[,which(colnames(paths) %in% ids.P),drop=F], 2, function(x) x-ref))
     all.names <- c(all.names, ids.P)
}
rownames(res) <- rownames(paths)
colnames(res) <- all.names
library(RColorBrewer)
cols <- rev(brewer.pal(9, "RdBu"))
breaks <- c(-100, seq(from=-0.75, to=0.75, length=8), 100)
pdf("/Expression/pathways_cancer_PDTX_minus_Tumour.pdf", width=12, height=16)
library(gplots)
heatmap(res, scale="none", col=cols, breaks=breaks, hclustfun=function(x,...) hclust(x, method="ward"),
margins=c(3, 20), cexRow=0.8)



models <- t(table(SS$TYPE, SS$Tumour))
models <- models[which(models[,'Tumour']>0 & models[,'PDTX']>0),]
res <- NULL
all.names <- NULL
count <- 1
for (i in rownames(models)) {
    ids.P0 <- SS$ID[which(SS$Tumour==i & SS$TYPE=="PDTX" & SS$PASSAGE==0)]
    if (length(ids.P0) > 0) {
    ids.P <- as.character(SS$ID[which(SS$Tumour==i & SS$TYPE=="PDTX" & SS$PASSAGE>0)])
    ref <- paths[,which(colnames(paths) %in% ids.P0)]
    if (!is.null(dim(ref))) {
       ref <- apply(ref, 1, mean)
       }
     res <- cbind(res, apply(paths[,which(colnames(paths) %in% ids.P)], 2, function(x) x-ref))
     all.names <- c(all.names, ids.P)
}
}
rownames(res) <- rownames(paths)
colnames(res) <- all.names
library(RColorBrewer)
cols <- rev(brewer.pal(9, "RdBu"))
breaks <- c(-100, seq(from=-0.75, to=0.75, length=8), 100)
library(gplots)
heatmap(res, scale="none", col=cols, breaks=breaks, hclustfun=function(x,...) hclust(x, method="ward"),
margins=c(3, 20), cexRow=0.8)
dev.off()
