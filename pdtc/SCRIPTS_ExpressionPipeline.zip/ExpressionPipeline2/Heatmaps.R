library(heatmap.plus)

oscar.heatmap.plus <-
function (x, Rowv = NULL, Colv = if (symm) "Rowv" else NULL,
    distfun = dist, hclustfun = hclust, reorderfun = function(d,
        w) reorder(d, w), add.expr, symm = FALSE, revC = identical(Colv,
        "Rowv"), scale = c("row", "column", "none"), na.rm = TRUE,
    margins = c(5, 5), ColSideColors, RowSideColors, cexRow = 0.2 +
        1/log10(nr), cexCol = 0.2 + 1/log10(nc), labRow = NULL,
    labCol = NULL, main = NULL, xlab = NULL, ylab = NULL, keep.dendro = FALSE,
    verbose = getOption("verbose"), ...)
{
    scale <- if (symm && missing(scale))
        "none"
    else match.arg(scale)
    if (length(di <- dim(x)) != 2 || !is.numeric(x))
        stop("'x' must be a numeric matrix")
    nr <- di[1]
    nc <- di[2]
    if (nr <= 1 || nc <= 1)
        stop("'x' must have at least 2 rows and 2 columns")
    if (!is.numeric(margins) || length(margins) != 2)
        stop("'margins' must be a numeric vector of length 2")
    doRdend <- !identical(Rowv, NA)
    doCdend <- !identical(Colv, NA)
    if (is.null(Rowv))
        Rowv <- rowMeans(x, na.rm = na.rm)
    if (is.null(Colv))
        Colv <- colMeans(x, na.rm = na.rm)
    if (doRdend) {
        if (inherits(Rowv, "dendrogram"))
            ddr <- Rowv
        else {
            hcr <- hclustfun(distfun(x))
            ddr <- as.dendrogram(hcr)
            if (!is.logical(Rowv) || Rowv)
                ddr <- reorderfun(ddr, Rowv)
        }
        if (nr != length(rowInd <- order.dendrogram(ddr)))
            stop("row dendrogram ordering gave index of wrong length")
    }
    else rowInd <- 1:nr
    if (doCdend) {
        if (inherits(Colv, "dendrogram"))
            ddc <- Colv
        else if (identical(Colv, "Rowv")) {
            if (nr != nc)
                stop("Colv = \"Rowv\" but nrow(x) != ncol(x)")
            ddc <- ddr
        }
        else {
            hcc <- hclustfun(distfun(if (symm)
                x
            else t(x)))
            ddc <- as.dendrogram(hcc)
            if (!is.logical(Colv) || Colv)
                ddc <- reorderfun(ddc, Colv)
        }
        if (nc != length(colInd <- order.dendrogram(ddc)))
            stop("column dendrogram ordering gave index of wrong length")
    }
    else colInd <- 1:nc
    x <- x[rowInd, colInd]
    labRow <- if (is.null(labRow))
        if (is.null(rownames(x)))
            (1:nr)[rowInd]
        else rownames(x)
    else labRow[rowInd]
    labCol <- if (is.null(labCol))
        if (is.null(colnames(x)))
            (1:nc)[colInd]
        else colnames(x)
    else labCol[colInd]
    if (scale == "row") {
        x <- sweep(x, 1, rowMeans(x, na.rm = na.rm))
        sx <- apply(x, 1, sd, na.rm = na.rm)
        x <- sweep(x, 1, sx, "/")
    }
    else if (scale == "column") {
        x <- sweep(x, 2, colMeans(x, na.rm = na.rm))
        sx <- apply(x, 2, sd, na.rm = na.rm)
        x <- sweep(x, 2, sx, "/")
    }
    lmat <- rbind(c(NA, 3), 2:1)
    lwid <- c(if (doRdend) 1 else 0.05, 4)
    lhei <- c((if (doCdend) 1 else 0.05) + if (!is.null(main)) 0.2 else 0,
        4)
    if (!missing(ColSideColors)) {
        if (!is.matrix(ColSideColors))
            stop("'ColSideColors' must be a matrix")
        if (!is.character(ColSideColors) || dim(ColSideColors)[1] !=
            nc)
            stop("'ColSideColors' dim()[2] must be of length ncol(x)")
        lmat <- rbind(lmat[1, ] + 1, c(NA, 1), lmat[2, ] + 1)
        lhei <- c(lhei[1], 0.6, lhei[2])
    }
    if (!missing(RowSideColors)) {
        if (!is.matrix(RowSideColors))
            stop("'RowSideColors' must be a matrix")
        if (!is.character(RowSideColors) || dim(RowSideColors)[1] !=
            nr)
            stop("'RowSideColors' must be a character vector of length nrow(x)")
        lmat <- cbind(lmat[, 1] + 1, c(rep(NA, nrow(lmat) - 1),
            1), lmat[, 2] + 1)
        lwid <- c(lwid[1], 0.2, lwid[2])
    }
    lmat[is.na(lmat)] <- 0
    if (verbose) {
        cat("layout: widths = ", lwid, ", heights = ", lhei,
            "; lmat=\n")
        print(lmat)
    }
    op <- par(no.readonly = TRUE)
    on.exit(par(op))
    layout(lmat, widths = lwid, heights = lhei, respect = FALSE)
    if (!missing(RowSideColors)) {
        par(mar = c(margins[1], 0, 0, 0.5))
        rsc = RowSideColors[rowInd, ]
        rsc.colors = matrix()
        rsc.names = names(table(rsc))
        rsc.i = 1
        for (rsc.name in rsc.names) {
            rsc.colors[rsc.i] = rsc.name
            rsc[rsc == rsc.name] = rsc.i
            rsc.i = rsc.i + 1
        }
        rsc = matrix(as.numeric(rsc), nrow = dim(rsc)[1])
        image(t(rsc), col = as.vector(rsc.colors), axes = FALSE)
        if (length(colnames(RowSideColors)) > 0) {
            axis(1, 0:(dim(rsc)[2] - 1)/(dim(rsc)[2] - 1), colnames(RowSideColors),
                las = 2, tick = FALSE)
        }
    }
    if (!missing(ColSideColors)) {
        par(mar = c(0.5, 0, 0, margins[2]))
        csc = ColSideColors[colInd, ]
        csc.colors = matrix()
        csc.names = names(table(csc))
        csc.i = 1
        for (csc.name in csc.names) {
            csc.colors[csc.i] = csc.name
            csc[csc == csc.name] = csc.i
            csc.i = csc.i + 1
        }
        csc = matrix(as.numeric(csc), nrow = dim(csc)[1])
        image(csc, col = as.vector(csc.colors), axes = FALSE)
        if (length(colnames(ColSideColors)) > 0) {
            axis(2, 0:(dim(csc)[2] - 1)/(dim(csc)[2] - 1), colnames(ColSideColors),
                las = 2, tick = FALSE)
        }
    }
    par(mar = c(margins[1], 0, 0, margins[2]))
    if (!symm || scale != "none") {
        x <- t(x)
    }
    if (revC) {
        iy <- nr:1
        ddr <- rev(ddr)
        x <- x[, iy]
    }
    else iy <- 1:nr
    image(1:nc, 1:nr, x, xlim = 0.5 + c(0, nc), ylim = 0.5 +
        c(0, nr), axes = FALSE, xlab = "", ylab = "", ...)
    axis(1, 1:nc, labels = labCol, las = 2, line = -0.5, tick = 0,
        cex.axis = cexCol)
    if (!is.null(xlab))
        mtext(xlab, side = 1, line = margins[1] - 1.25)
    axis(4, iy, labels = labRow, las = 2, line = -0.5, tick = 0,
        cex.axis = cexRow)
    if (!is.null(ylab))
        mtext(ylab, side = 4, line = margins[2] - 1.25)
    if (!missing(add.expr))
        eval(substitute(add.expr))
    par(mar = c(margins[1], 0, 0, 0))
    if (doRdend)
        plot(ddr, horiz = TRUE, axes = FALSE, yaxs = "i", leaflab = "none")
    else frame()
    par(mar = c(0, 0, if (!is.null(main)) 1 else 0, margins[2]))
    if (doCdend)
        plot(ddc, axes = FALSE, xaxs = "i", leaflab = "none")
    else if (!is.null(main))
        frame()
    if (!is.null(main))
        title(main, cex.main = 1.5 * op[["cex.main"]])
    invisible(list(rowInd = rowInd, colInd = colInd, Rowv = if (keep.dendro &&
        doRdend) ddr, Colv = if (keep.dendro && doCdend) ddc))
}


## Clusters and heatmap of PDX + Metabric All Genes

load(file="/Expression/PDX_Genes_Expression.RData")
SS <- read.csv("/Expression/ExpressionFullSampleSheet.csv", skip=7)

SS <- SS[which(SS$ID %in% colnames(PDX)),]
SS <- SS[match(colnames(PDX), SS$ID),]



PDX <- PDX[,-which(SS$Include=="NO" & SS$Engrafted!="n")]
SS <- SS[-which(SS$Include=="NO" & SS$Engrafted!="n"),]


load(“/Expression1980GSEA.RData")
Metabric <- Exp
rownames(Metabric) <- Metabric[,1]
Metabric <- as.matrix(Metabric[,-c(1:2)])
common.genes <- intersect(rownames(PDX), rownames(Metabric))
Metabric <- Metabric[which(rownames(Metabric) %in% common.genes),]
PDX <- PDX[which(rownames(PDX) %in% common.genes),]
PDX <- PDX[match(rownames(Metabric), rownames(PDX)),]

Exp <- cbind(Metabric, PDX)
library(preprocessCore)
AllExp <- normalize.quantiles(Exp)
dimnames(AllExp) <- dimnames(Exp)
AllExp <- apply(AllExp, 1, scale)
AllExp <- t(AllExp)
dimnames(AllExp) <- dimnames(Exp)

sd.all <- apply(AllExp, 1, IQR, na.rm=T)
ids <- which(sd.all >= quantile(sd.all, 0.95))
library(RColorBrewer)
col.heat <- rev(brewer.pal(10, "RdBu"))

iC10 <- read.table(file="/Expression/PDXiC10.txt", header=T, sep="\t", stringsAsFactors=FALSE)
iC10 <- iC10[,c('ID', 'ER.status', 'Type', 'ThreeGene', 'Pam50', 'Final', 'ER', 'HER2', 'Tumour'),]
iC10$Cohort <- "PDTX"
iC10 <- merge(iC10, SS[,c('ID', 'Engrafted', 'TYPE')])
iC10$Graft <- "YES"
iC10$Graft[which(iC10$Engrafted=="n")] <- "NO"
iC10$Engrafted <- NULL
colnames(iC10)[c(2, 6)] <- c("er_status", "Group")
iC10$er_status <- factor(iC10$er_status, levels=c("Neg", "Pos"),
                         labels=c("-", "+"))
iC10$Group[which(iC10$Group=="4" & iC10$er_status=="-")] <- "4ER-"
iC10$Group[which(iC10$Group=="4" & iC10$er_status=="+")] <- "4ER+"
iC10$Group[which(iC10$Group=="4" & iC10$ER=="-")] <- "4ER-"
iC10$Group[which(iC10$Group=="4" & (iC10$ER=="+"))] <- "4ER+"
iC10$Group <- factor(iC10$Group, levels=c(1:3, "4ER+", "4ER-", 5:10))
iC10$ER <- NULL

load(“/Clinical1980.RData")
Clinical <- Clinical[,c('METABRIC_ID', 'er_status', 'Her2.Expr', 'Genefu', 'Pam50Subtype', 'Group')]
Clinical$Type <- "Primary"
Clinical$Cohort <- "Metabric"
Clinical$TYPE <- "Tumour"
Clinical$Graft <- NA
Clinical$Tumour <- "Metabric"
colnames(Clinical)[c(1, 3,4,5)] <- c("ID", "HER2", "ThreeGene", "Pam50")
Clinical$er_status <- factor(Clinical$er_status, levels=c("neg", "pos"),
                         labels=c("-", "+"))
Clinical$ThreeGene <- as.character(Clinical$ThreeGene)
Clinical$ThreeGene[which(Clinical$ThreeGene=="null")] <- NA
Clinical$Pam50 <- as.character(Clinical$Pam50)
Clinical$Pam50[which(Clinical$Pam50=="NC")] <- NA


Clinical <- Clinical[,match(colnames(iC10), colnames(Clinical))]
X <- rbind(Clinical, iC10)
colnames(AllExp) <- sub(".", "-", colnames(AllExp), fixed=TRUE)
X <- X[match(colnames(AllExp), X$ID),]

coliClust <- c('#FF5500', '#00EE76', '#CD3278','#00C5CD', '#B5D0D2', '#8B0000',
               '#FFFF40', '#0000CD', '#FFAA00', '#EE82EE', '#7D26CD')
colipam <- c("#E41A1C", "#FB9A99", "#1F78B4", "#A6CEE3", "#66A61E")
colithree <- colipam[c(1, 2, 3, 4)]
TG.col <- rep(0, length(X$ThreeGene))
levs <- c("ER-/HER2-", "HER2+", "ER+/HER2- Low Prolif", "ER+/HER2- High Prolif")
for (i in 1:length(levs)) TG.col[which(X$ThreeGene==levs[i])] <- colithree[i]
color.palette <- c(brewer.pal(8, "Set2"),
                   brewer.pal(8, "Dark2"),
                   brewer.pal(8, "Pastel1"),
                   brewer.pal(8, "Set1"),
                   brewer.pal(10, "BrBG"))
ic.col <- rep(0, length(X$Group))
for (i in 1:11) ic.col[which(X$Group==levels(X$Group)[i])] <- coliClust[i]
pam.col <- rep(0, length(X$Pam50))
levs <- c("Basal", "Her2", "LumA", "LumB", "Normal")
for (i in 1:length(levs)) pam.col[which(X$Pam50==levs[i])] <- colipam[i]
ER.col <- color.palette[as.numeric(X$er_status)]
HER2.col <- color.palette[as.numeric(X$HER2)]
Tumor.col <- color.palette[as.numeric(factor(X$Tumour))]
TYPE.col <- color.palette[as.numeric(factor(X$TYPE))]
Type.col <- color.palette[as.numeric(factor(X$Type))]
Cohort.col <- color.palette[as.numeric(factor(X$Cohort))]
Engraft.col <- color.palette[as.numeric(factor(X$Graft))]
vars <- cbind(ER.col, HER2.col, TG.col, Tumor.col,
              Type.col, TYPE.col, Engraft.col, pam.col,
              ic.col, Cohort.col)
colnames(vars) <- c("ER", "HER2", "Three Gene",
                    "Tumour", "Source", "Type",
                    "Engrafted",  "Pam50", "iC10", "Cohort")
rownames(vars) <- X$ID
vars[,'Cohort'][which(vars[,'Cohort'] == "#66C2A5")] <- "lightgrey"
vars[,'Cohort'][which(vars[,'Cohort'] == "#FC8D62")] <- "black"
breaks <- c(-10, seq(from=-2, to=2, length=9), 10)
pdf("/Expression/HeatmapExpression.pdf", width=14, height=9)
oscar.heatmap.plus(AllExp[ids,], ColSideColors=vars,
                   col=col.heat, scale="none", breaks=breaks,
             hclustfun=function(x) hclust(x, method="ward"),
             labRow="", labCol="", cexCol=1.2, verbose=T, margins=c(10,10))
dev.off()



## Clusters and heatmap of PDX + Metabric Pathways

load(file="/Expression/pathwaysReduced.RData")

colnames(all.res) <- sub(".", "-", colnames(all.res), fixed=TRUE)
all.res <- all.res[,which(colnames(all.res) %in% X$ID)]
mean(colnames(all.res) == X$ID)
breaks <- c(-10, seq(from=-1, to=1, length=9), 10)


pdf("/Expression/ClusterTumoursB.pdf", width=22, height=9)
layout(rbind(1, 2, 3))
par(mar=c(2, 6, 2, 2))
ids <- which(X$Cohort=="PDTX")
set.seed(35345)
for (i in unique(X$Group)) {
    ids <- c(ids, sample(which(X$Cohort=="Metabric" & X$Group==i), size=15))
}
res <- hclust(dist(t(tmp[,ids])), method="ward")
colnames(vars)[5] <- "IntClust"
plotDendroAndColors(res, colors=vars[ids,], dendroLabels=FALSE,
                    cex.colorLabels=2.5, setLayout=FALSE,
                    main="", ylab="", axes=FALSE,
                    marAll=c(2, 8, 2, 2))
plot(0,0, type="n", axes=F, xlab="", ylab="")
vector.col <- c(rep(color.palette[1:2], 2), colithree,
                colipam,
                coliClust, c("lightgrey", "black"))
vector.text <- c("ER-", "ER+", "HER2-", "HER2+",
                 "ER-/HER2-", "HER2+", "ER+/HER2- Low Prolif",
                   "ER+/HER2- High Prolif",
                 c("Basal", "Her2", "LumA", "LumB", "Normal"),
                 paste("IntClust", c(1:3, "4ER+",
                                  "4ER-", 5:10), sep=""),
                 "Metabric", "PDTX")
legend("topleft", fill=vector.col, legend=vector.text,
       bty="n", ncol=6, cex=2.5)
dev.off()

