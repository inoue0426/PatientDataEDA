## Annotate
load("FilteredSNVs_ALLSAMPLES.RData")
tmp <- sapply(strsplit(rownames(SNVs), ";"), function(x) x[2])
tmp <- unique(tmp)
SNVs <- data.frame(Location=tmp)
SNVs$Chrom <- sapply(strsplit(tmp, ":"), function(x) x[1])
SNVs <- SNVs[which(SNVs$Chrom %in% paste("chr", c(1:22, "X"), sep="")),]
rownames(SNVs)  <- SNVs$Location
tmp <- sapply(strsplit(rownames(SNVs), ":"), function(x) x[2])
tmp <- strsplit(tmp, "_", fixed=TRUE)
SNVs$Pos <- sapply(tmp, function(x) x[1])
tmp <- sapply(tmp, function(x) x[2])
tmp <- strsplit(tmp, "/", fixed=TRUE)
SNVs$Ref <- sapply(tmp, function(x) x[1])
SNVs$Alt <- sapply(tmp, function(x) x[2])

## annovar (only SNPs for now)
annovar <- SNVs[,c('Chrom', 'Pos', 'Pos', 'Ref', 'Alt')]
annovar$Chrom <- sub("chr", "" ,annovar$Chrom)
annovar$Comments <- rownames(annovar)
write.table(annovar,
            file="/annovar_March2015/SNVPDX.txt", row.names=F, col.names=F, sep="\t", quote=F)

setwd("/annovar_March2015/")

system("./annotate_variation.pl -filter -dbtype 1000g2014oct_eur -buildver hg19 -out ex1 SNVPDX.txt humandb/")

system("./annotate_variation.pl -build hg19 -out gene_annot SNVPDX.txt humandb/")

SNP <- read.table("ex1.hg19_EUR.sites.2014_10_dropped", sep="\t")

SNVs$V8 <- rownames(SNVs)
SNP <- SNP[,c('V1', 'V8')]
SNVs <- merge(SNVs, SNP, all.x=T)
colnames(SNVs)[7] <- "GERMLINE.1000G"
SNVs$GERMLINE.1000G <- as.character(SNVs$GERMLINE.1000G)
SNVs$GERMLINE.1000G[which(is.na(SNVs$GERMLINE.1000G))] <- "NO"
SNVs$Chrom <- factor(SNVs$Chrom,
                     levels=paste("chr", c(1:22, "X"), sep=""))
SNVs$Pos <- as.numeric(SNVs$Pos)
SNVs <- SNVs[order(SNVs$Chrom, SNVs$Pos),]
rownames(SNVs) <- SNVs$V8
SNVs$V8 <- NULL

Annot <- read.table("gene_annot.exonic_variant_function", header=FALSE, sep="\t")
SNVs$V9 <- rownames(SNVs)
Annot <- Annot[,c('V2', 'V3', 'V9')]
SNVs <- merge(SNVs, Annot, all.x=T)
colnames(SNVs)[8:9] <- c("Type", "Exon")
Annot <- read.table("gene_annot.variant_function", header=FALSE, sep="\t")
colnames(SNVs)[1] <- "V8"
Annot <- Annot[,c('V1', 'V2', 'V8')]
SNVs <- merge(SNVs, Annot, all.x=T)
colnames(SNVs)[10:11] <- c("GenomicPos", "Symbol")

## Repetitive regions

system("./annotate_variation.pl -regionanno -build hg19 -out ex1 -dbtype genomicSuperDups SNVPDX.txt humandb/")

Annot <- read.table("ex1.hg19_genomicSuperDups", header=FALSE, sep="\t")
Annot <- Annot[,c('V1', 'V8')]
SNVs <- merge(SNVs, Annot, all.x=T)
colnames(SNVs)[12] <- c("Repetitive")
SNVs$Repetitive <- as.character(SNVs$Repetitive)
SNVs$Repetitive[which(is.na(SNVs$Repetitive))] <- "NO"

## DBSNP
system("./annotate_variation.pl -filter -out ex1 -build hg19 -dbtype snp138 SNVPDX.txt humandb/")


SNVs <- SNVs[order(SNVs$Chrom, SNVs$Pos),]

SNP <- read.table("ex1.hg19_snp138_dropped", sep="\t")

SNP <- SNP[,c('V2', 'V8')]
SNVs <- merge(SNVs, SNP, all.x=T)
colnames(SNVs)[13] <- "GERMLINE.DBSNP"
SNVs$GERMLINE.DBSNP <- as.character(SNVs$GERMLINE.DBSNP)
SNVs$GERMLINE.DBSNP[which(is.na(SNVs$GERMLINE.DBSNP))] <- "NO"

############################################################
############################################################
## SIFT
############################################################
############################################################


setwd("/annovar_March2015/")
system("./annotate_variation.pl -filter -dbtype ljb26_sift -buildver hg19 -out ex1 SNVPDX.txt humandb/ -otherinfo")
system("./annotate_variation.pl -filter -dbtype ljb26_pp2hvar -buildver hg19 -out ex1 SNVPDX.txt humandb/ -otherinfo")
system("./annotate_variation.pl -filter -dbtype ljb26_mt -buildver hg19 -out ex1 SNVPDX.txt humandb/ -otherinfo")
system("./annotate_variation.pl -filter -dbtype ljb26_metalr -buildver hg19 -out ex1 SNVPDX.txt humandb/ -otherinfo")

z <- read.table("ex1.hg19_ljb26_sift_dropped", header=F, sep="\t", stringsAsFactors=F)
z$SIFT <- sapply(strsplit(as.character(z$V2), ","), function(x) x[2])
z$V1 <- NULL
z$V2 <- NULL
preds <- z
z <- read.table("ex1.hg19_ljb26_pp2hvar_dropped", header=F, sep="\t", stringsAsFactors=F)
z$POLYPHEN <- sapply(strsplit(as.character(z$V2), ","), function(x) x[2])
z$V1 <- NULL
z$V2 <- NULL
preds <- merge(preds, z, all=T)
z <- read.table("ex1.hg19_ljb26_mt_dropped", header=F, sep="\t", stringsAsFactors=F)
z$MT <- sapply(strsplit(as.character(z$V2), ","), function(x) x[2])
z$V1 <- NULL
z$V2 <- NULL
preds <- merge(preds, z, all=T)
z <- read.table("ex1.hg19_ljb26_metalr_dropped", header=F, sep="\t", stringsAsFactors=F)
z$METALR <- sapply(strsplit(as.character(z$V2), ","), function(x) x[2])
z$V1 <- NULL
z$V2 <- NULL
preds <- merge(preds, z, all=T)
SNVs.preds <- preds[,-c(1:5)]

SNVs <- merge(SNVs, SNVs.preds, all=T)

save(SNVs, file="/Volumes/BAM_PDX/ExomeV3/SNVsAnnotated.RData")

########################################################################
########################################################################
## indels
########################################################################
########################################################################

## Annotate
load("/FilteredIndels_ALLSAMPLES.RData")
tmp <- sapply(strsplit(rownames(indels), ";"), function(x) x[2])
tmp <- unique(tmp)
indels <- data.frame(Location=tmp)
indels$Chrom <- sapply(strsplit(tmp, ":"), function(x) x[1])
indels <- indels[which(indels$Chrom %in% paste("chr", c(1:22, "X"), sep="")),]
rownames(indels)  <- indels$Location
tmp <- sapply(strsplit(rownames(indels), ":"), function(x) x[2])
tmp <- strsplit(tmp, "_", fixed=TRUE)
indels$Pos <- sapply(tmp, function(x) x[1])
tmp <- sapply(tmp, function(x) x[2])
tmp <- strsplit(tmp, "/", fixed=TRUE)
indels$Ref <- sapply(tmp, function(x) x[1])
indels$Alt <- sapply(tmp, function(x) x[2])

## annovar
indels$Pos <- as.numeric(as.character(indels$Pos))
annovar <- indels[,c('Chrom', 'Pos', 'Pos', 'Ref', 'Alt')]
annovar$Chrom <- sub("chr", "" ,annovar$Chrom)
annovar$Comments <- rownames(annovar)
annovar[,3] <- annovar[,2] + pmax(0, nchar(annovar$Ref) - nchar(annovar$Alt))
write.table(annovar,
            file="/annovar_March2015/indelsPDX.txt", row.names=F, col.names=F, sep="\t", quote=F)

setwd("/Volumes/RRBS/annovar_March2015/")

system("./annotate_variation.pl -filter -dbtype 1000g2014oct_eur -buildver hg19 -out ex1 indelsPDX.txt humandb/")

system("./annotate_variation.pl -build hg19 -out gene_annot indelsPDX.txt humandb/")

SNP <- read.table("ex1.hg19_EUR.sites.2014_10_dropped", sep="\t")

indels$V8 <- rownames(indels)
SNP <- SNP[,c('V1', 'V8')]
indels <- merge(indels, SNP, all.x=T)
colnames(indels)[7] <- "GERMLINE.1000G"
indels$GERMLINE.1000G <- as.character(indels$GERMLINE.1000G)
indels$GERMLINE.1000G[which(is.na(indels$GERMLINE.1000G))] <- "NO"
indels$Chrom <- factor(indels$Chrom,
                     levels=paste("chr", c(1:22, "X"), sep=""))
indels$Pos <- as.numeric(indels$Pos)
indels <- indels[order(indels$Chrom, indels$Pos),]
rownames(indels) <- indels$V8
indels$V8 <- NULL

Annot <- read.table("gene_annot.exonic_variant_function", header=FALSE, sep="\t")
indels$V9 <- rownames(indels)
Annot <- Annot[,c('V2', 'V3', 'V9')]
indels <- merge(indels, Annot, all.x=T)
colnames(indels)[8:9] <- c("Type", "Exon")
Annot <- read.table("gene_annot.variant_function", header=FALSE, sep="\t")
colnames(indels)[1] <- "V8"
Annot <- Annot[,c('V1', 'V2', 'V8')]
indels <- merge(indels, Annot, all.x=T)
colnames(indels)[10:11] <- c("GenomicPos", "Symbol")

## Repetitive regions

system("./annotate_variation.pl -regionanno -build hg19 -out ex1 -dbtype genomicSuperDups indelsPDX.txt humandb/")

Annot <- read.table("ex1.hg19_genomicSuperDups", header=FALSE, sep="\t")
Annot <- Annot[,c('V1', 'V8')]
indels <- merge(indels, Annot, all.x=T)
colnames(indels)[12] <- c("Repetitive")
indels$Repetitive <- as.character(indels$Repetitive)
indels$Repetitive[which(is.na(indels$Repetitive))] <- "NO"

## DBSNP
system("./annotate_variation.pl -filter -out ex1 -build hg19 -dbtype snp138 indelsPDX.txt humandb/")


indels <- indels[order(indels$Chrom, indels$Pos),]

SNP <- read.table("ex1.hg19_snp138_dropped", sep="\t")

SNP <- SNP[,c('V2', 'V8')]
indels <- merge(indels, SNP, all.x=T)
colnames(indels)[13] <- "GERMLINE.DBSNP"
indels$GERMLINE.DBSNP <- as.character(indels$GERMLINE.DBSNP)
indels$GERMLINE.DBSNP[which(is.na(indels$GERMLINE.DBSNP))] <- "NO"

############################################################
############################################################
## SIFT
############################################################
############################################################

setwd("/annovar_March2015/")
system("./annotate_variation.pl -filter -dbtype ljb26_sift -buildver hg19 -out ex1 indelsPDX.txt humandb/ -otherinfo")
system("./annotate_variation.pl -filter -dbtype ljb26_pp2hvar -buildver hg19 -out ex1 indelsPDX.txt humandb/ -otherinfo")
system("./annotate_variation.pl -filter -dbtype ljb26_mt -buildver hg19 -out ex1 indelsPDX.txt humandb/ -otherinfo")
system("./annotate_variation.pl -filter -dbtype ljb26_metalr -buildver hg19 -out ex1 indelsPDX.txt humandb/ -otherinfo")

## z <- read.table("ex1.hg19_ljb23_sift_dropped", header=F, sep="\t", stringsAsFactors=F)
## z$SIFT <- sapply(strsplit(as.character(z$V2), ","), function(x) x[3])
## z$V1 <- NULL
## z$V2 <- NULL
## preds <- z
## z <- read.table("ex1.hg19_ljb23_pp2hvar_dropped", header=F, sep="\t", stringsAsFactors=F)
## z$POLYPHEN <- sapply(strsplit(as.character(z$V2), ","), function(x) x[2])
## z$V1 <- NULL
## z$V2 <- NULL
## preds <- merge(preds, z, all=T)
## z <- read.table("ex1.hg19_ljb23_mt_dropped", header=F, sep="\t", stringsAsFactors=F)
## z$MT <- sapply(strsplit(as.character(z$V2), ","), function(x) x[3])
## z$V1 <- NULL
## z$V2 <- NULL
## preds <- merge(preds, z, all=T)
## z <- read.table("ex1.hg19_ljb23_metalr_dropped", header=F, sep="\t", stringsAsFactors=F)
## z$METALR <- sapply(strsplit(as.character(z$V2), ","), function(x) x[2])
## z$V1 <- NULL
## z$V2 <- NULL
## preds <- merge(preds, z, all=T)
## indels.preds <- preds[,-c(1:5)]

## indels <- merge(indels, indels.preds, all=T)

save(indels, file="/indelsAnnotated.RData")
