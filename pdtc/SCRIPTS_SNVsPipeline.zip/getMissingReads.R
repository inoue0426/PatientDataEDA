########################################################
########################################################
##################     SNVs           ##################
########################################################
########################################################

load("/FilteredSNVs_ALLSAMPLES.RData")
SNPs <- SNVs[grep("-N", SNVs$ID, fixed=TRUE),]
SNPs$Location <- sapply(strsplit(rownames(SNPs), ";"), function(x) x[2])
SNPs <- SNPs$Location
SNPs <- unique(SNPs)

SS <- read.table("/SampleSheetExomes.txt", header=TRUE, sep="\t", stringsAsFactors=FALSE)
SS <- SS[which(SS$Include=="YES"),]
ids <- names(table(SS$Tumour))
for (i in ids) {
    load(paste("/SNVs/", i, "_SNVs.RData", sep=""))
    col.ids <- colnames(all.x)[grep("VAF", colnames(all.x))]
    for (j in col.ids) {
        todo <- all.x$Variant[which(is.na(all.x[,j]))]
        save(todo, file=paste("/MissingSNVs/",
                   sub(".VAF", "", j, fixed=TRUE), ".RData", sep=""))
        if (length(todo)>0) {
            todo <- sapply(strsplit(todo, "_"), function(x) x[1])
            pos <- as.numeric(sapply(strsplit(todo, ":"), function(x) x[2]))
            ## pos <- pos + 1
            todo <- paste(todo, pos, sep="-")
            write.table(todo, file=paste("/MissingSNVs/",
                              sub(".VAF", "", j, fixed=TRUE), ".intervals", sep=""),
                        row.names=F, col.names=F, quote=F)
        }
    }
}
## get Missing Reads through GATK
setwd("/MissingSNVs/")
allF <- dir(pattern=".intervals$")
for (i in allF) {
    runString <- paste("java -Xmx4g -jar /Applications/GATK/GATK-3.3-0/GenomeAnalysisTK.jar ", sep="")
    runString <- paste(runString, " -T HaplotypeCaller -I /Volumes/BAM_PDX/BAMExomes/",
                       sub(".intervals", "_ordered_picard.bam", i, fixed=TRUE), sep="")
    runString <- paste(runString, " -L  /MissingSNVs/",
                       i, sep="")
    runString <- paste(runString, " -R /reference/ucsc.hg19_mmu10.fa", sep="")
    runString <- paste(runString, " -ERC BP_RESOLUTION", sep="")
    runString <- paste(runString, " -o /MissingSNVs/MissingSNVs", i, ".vcf  -stand_call_conf 30.0 -stand_emit_conf 20.0", sep="")
    system(runString)
}

 setwd("/MissingSNVs/")
 allF <- dir()
 for (i in allF) {
 load(i)
all.x$Pos <- sapply(strsplit(all.x$Variant, "_"), function(x) x[1])
all.x$Pos2 <- sapply(strsplit(all.x$Variant, "_"), function(x) x[2])
library(VariantAnnotation)
ids <- colnames(all.x)[grep("VAF", colnames(all.x))]
feo.name <- sub(".VAF", "", ids, fixed=TRUE)
for (k in 1:length(ids)) {
    if (length(ids) > 1) {
    x <- readVcf(paste("/MissingSNVs/MissingSNVs”, i, “_", feo.name[k], ".intervals.vcf", sep=""), "hg19")
   todo <- length(unique(all.x$Pos[is.na(all.x[,ids[k]])]))
   found <- rownames(geno(x)$AD)
    cat("\n", ids[k], " ", todo, " ", length(found), "\n")
   if (todo == length(found)) {
   variant<- sapply(strsplit(found, "_"), function(x) x[2])
   found <- sapply(strsplit(found, "_"), function(x) x[1])
   for (m in 1:length(found)) {
	tmp <- which(all.x$Pos == found[m])
	for (n in tmp) {
  	feo <- geno(x)$AD[[m]]
        if (is.na(all.x[n,sub("VAF", "Genotype", ids[k])])) {
	if (length(grep("NON", variant[m]))>0) {
 		all.x[n,ids[k]] <- feo[2] / sum(feo)
 		all.x[n,sub("VAF", "Depth", ids[k])] <- sum(feo)
	} else if (all.x$Pos2[n] == variant[m]) {
 		all.x[n,ids[k]] <- feo[2] / sum(feo)
 		all.x[n,sub("VAF", "Depth", ids[k])] <- sum(feo)
	} else {
		all.x[n,ids[k]] <- 0 / sum(feo)
 		all.x[n,sub("VAF", "Depth", ids[k])] <- sum(feo)
            }
    }
    }
    }
} else {
    stop()
}
}
}
    save(all.x, file=paste(“/SNVs/“, i, “_SNVs_MissingIncluded.RData", sep=""))

}
########################################################
########################################################
##################     Indels         ##################
########################################################
########################################################

load("/FilteredIndels_ALLSAMPLES.RData")
SNPs <- indels[grep("-N", indels$ID, fixed=TRUE),]
SNPs$Location <- sapply(strsplit(rownames(SNPs), ";"), function(x) x[2])
SNPs <- SNPs$Location
SNPs <- unique(SNPs)

SS <- read.table("/SampleSheetExomes.txt", header=TRUE, sep="\t", stringsAsFactors=FALSE)
SS <- SS[which(SS$Include=="YES"),]
ids <- names(table(SS$Tumour))
for (i in ids) {
    load(paste("/indels/", i, "_indels.RData", sep=""))
    col.ids <- colnames(all.x)[grep("VAF", colnames(all.x))]
    for (j in col.ids) {
        todo <- all.x$Variant[which(is.na(all.x[,j]))]
        save(todo, file=paste("/VMissingIndels/",
                   sub(".VAF", "", j, fixed=TRUE), ".RData", sep=""))
        if (length(todo)>0) {
            todo <- sapply(strsplit(todo, "_"), function(x) x[1])
            pos <- as.numeric(sapply(strsplit(todo, ":"), function(x) x[2]))
            ## pos <- pos + 1
            todo <- paste(todo, pos, sep="-")
            write.table(todo, file=paste("/MissingIndels/",
                              sub(".VAF", "", j, fixed=TRUE), ".intervals", sep=""),
                        row.names=F, col.names=F, quote=F)
        }
    }
}
## get Missing Reads through GATK
setwd("/MissingIndels/")
allF <- dir(pattern=".intervals$")
for (i in allF) {
    runString <- paste("java -Xmx4g -jar /Applications/GATK/GATK-3.3-0/GenomeAnalysisTK.jar ", sep="")
    runString <- paste(runString, " -T HaplotypeCaller -I /Volumes/BAM_PDX/BAMExomes/",
                       sub(".intervals", "_ordered_picard.bam", i, fixed=TRUE), sep="")
    runString <- paste(runString, " -L  /MissingIndels/",
                       i, sep="")
    runString <- paste(runString, " -R /Volumes/BAM_PDX/reference/ucsc.hg19_mmu10.fa", sep="")
    runString <- paste(runString, " -ERC BP_RESOLUTION", sep="")
    runString <- paste(runString, " -o /VMissingIndels/MissingIndels", i, ".vcf  -stand_call_conf 30.0 -stand_emit_conf 20.0", sep="")
    system(runString)
}


 setwd("/MissingIndels/")
 allF <- dir()
 for (i in allF) {
 load(i)

all.x$Pos <- sapply(strsplit(all.x$Variant, "_"), function(x) x[1])
all.x$Pos2 <- sapply(strsplit(all.x$Variant, "_"), function(x) x[2])
library(VariantAnnotation)
ids <- colnames(all.x)[grep("VAF", colnames(all.x))]
feo.name <- sub(".VAF", "", ids, fixed=TRUE)
for (k in 1:length(ids)) {
    x <- readVcf(paste("/Missingindels/MissingIndelsALLSTG139_", feo.name[k], ".intervals.vcf", sep=""), "hg19")
   todo <- length(unique(all.x$Pos[is.na(all.x[,ids[k]])]))
   found <- rownames(geno(x)$AD)
    cat("\n", ids[k], " ", todo, " ", length(found), "\n")
   if (todo == length(found)) {
   variant<- sapply(strsplit(found, "_"), function(x) x[2])
   found <- sapply(strsplit(found, "_"), function(x) x[1])
   for (m in 1:length(found)) {
	tmp <- which(all.x$Pos == found[m])
	for (n in tmp) {
  	feo <- geno(x)$AD[[m]]
        if (is.na(all.x[n,sub("VAF", "Genotype", ids[k])])) {
	if (length(grep("NON", variant[m]))>0) {
 		all.x[n,ids[k]] <- feo[2] / sum(feo)
 		all.x[n,sub("VAF", "Depth", ids[k])] <- sum(feo)
	} else if (all.x$Pos2[n] == variant[m]) {
 		all.x[n,ids[k]] <- feo[2] / sum(feo)
 		all.x[n,sub("VAF", "Depth", ids[k])] <- sum(feo)
	} else {
		all.x[n,ids[k]] <- 0 / sum(feo)
 		all.x[n,sub("VAF", "Depth", ids[k])] <- sum(feo)
	}
	}
	}
    }
} else {
    stop()
}
}
   save(all.x, file=paste("/indels/“, i, “_indels_MissingIncluded.RData", sep=""))



