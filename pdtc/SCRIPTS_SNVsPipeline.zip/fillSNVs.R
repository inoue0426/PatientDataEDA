SS <- read.table("/SampleSheetExomes.txt", header=TRUE, sep="\t", stringsAsFactors=FALSE)
SS <- SS[which(SS$Include=="YES"),]
valid <- unique(SS$Tumour)
for (i in valid) {
load(paste("/SNVs/", i, "_SNVs.RData", sep=""))
all.x$Pos <- sapply(strsplit(all.x$Variant, "_"), function(x) x[1])
all.x$Pos2 <- sapply(strsplit(all.x$Variant, "_"), function(x) x[2])
library(VariantAnnotation)
ids <- colnames(all.x)[grep("VAF", colnames(all.x))]
feo.name <- sub(".VAF", "", ids, fixed=TRUE)
for (k in 1:length(ids)) {
    if (length(ids) > 1) {
    x <- readVcf(paste("/MissingSNVs", feo.name[k], ".intervals.vcf", sep=""), "hg19")
   todo <- length(unique(all.x$Pos[is.na(all.x[,ids[k]])]))
   found <- rownames(geno(x)$AD)
    cat("\n", ids[k], " ", todo, " ", length(found), "\n")
   if (todo == length(found)) {
   variant<- sapply(strsplit(found, "_"), function(x) x[2])
   found <- sapply(strsplit(found, "_"), function(x) x[1])
   for (m in 1:length(found)) {
	tmp <- which(all.x$Pos == found[m])
	for (n in tmp) {
  	feo <- geno(x)$AD[[m]]
        if (is.na(all.x[n,sub("VAF", "Genotype", ids[k])])) {
	if (length(grep("NON", variant[m]))>0) {
 		all.x[n,ids[k]] <- feo[2] / sum(feo)
 		all.x[n,sub("VAF", "Depth", ids[k])] <- sum(feo)
	} else if (all.x$Pos2[n] == variant[m]) {
 		all.x[n,ids[k]] <- feo[2] / sum(feo)
 		all.x[n,sub("VAF", "Depth", ids[k])] <- sum(feo)
	} else {
		all.x[n,ids[k]] <- 0 / sum(feo)
 		all.x[n,sub("VAF", "Depth", ids[k])] <- sum(feo)
            }
    }
    }
    }
} else {
    stop()
}
}
}
    save(all.x, file=paste("/SNVs/", i, "_SNVs_MissingIncluded.RData", sep=""))
}
