library(VariantAnnotation)
setwd("./Merged/SNPs")
allF <- dir(pattern=".vcf$")
 i <- as.numeric(Sys.getenv("LSB_JOBINDEX"))
 i <- allF[i]
 if(!file.exists(paste(i, ".bgz", sep=""))) {
 bgzip(i)
 indexTabix(paste(i, ".bgz", sep=""), "vcf")
 }
allF <- dir(pattern=".bgz$")
 i <- as.numeric(Sys.getenv("LSB_JOBINDEX"))
  x.file <- readVcf(allF[i], "hg19")
  x <- geno(x.file)$AD
  x <- apply(x, 1, function(x) x[[1]])
  if (class(x)=="list") {
      ids <- which(sapply(x, length)==2)
      x <- x[ids]
      x <- do.call("rbind", x)
      x <- data.frame(ID=rownames(x), x)
  } else {
      x <- t(x)
      x <- cbind(rownames(x), x)
      x <- data.frame(x)
      colnames(x)[1] <- "ID"
  }
 x[,2] <- as.numeric(as.character(x[,2]))
   x[,3] <- as.numeric(as.character(x[,3]))
   colnames(x)[2:3] <- c("Ref", "Alt")
   x$Chrom <- sub("chr", "",
                  sapply(strsplit(as.character(x$ID), ":", fixed=TRUE),
                         function(x) x[1]), fixed=TRUE)
   x$Chrom <- factor(x$Chrom, levels=c(1:22, "X"))
   x$Pos <- sapply(strsplit(sapply(strsplit(as.character(x$ID), ":", fixed=TRUE),
          function(x) x[2]), "_"), function(x) x[1])
   x$Pos <- as.numeric(x$Pos)
   x <- x[order(x$Chrom, x$Pos),]
   x$VAF <- x$Alt / (x$Ref+x$Alt)
   x <- x[which(I(x$Ref + x$Alt) > 0),]
   print(summary(x$BAF))
   save(x, file=paste("./BAFs/", sub("_ordered_picard.bam.vcf.bgz", "",
           allF[i],fixed=TRUE),
           "_VAF.RData", sep=""))
   x <- geno(x.file)$GT
   x <- data.frame(ID=rownames(x), x)
   save(x, file=paste("./BAFs/", sub("_ordered_picard.bam.vcf.bgz", "",
           allF[i],fixed=TRUE),
           "_Genotype.RData", sep=""))


## Plot data

matchScore <- function(x, y) {
  all.lev <- unique(c(unique(as.character(x)), unique(as.character(y))))
  all.lev <- all.lev[which(!is.na(all.lev))]
  tmp <- table(factor(x, levels=all.lev), factor(y, levels=all.lev))
  sum(diag(tmp)) / sum(tmp)
}

## GET VAFs

setwd("/Merged/SNPs/BAFs/")
allF <- dir(pattern="Genotype.RData$")
i <- as.numeric(Sys.getenv("LSB_JOBINDEX"))
res <- matrix(NA, 1, length(allF))
rownames(res) <- gsub("_Genotype.RData", "", allF[i], fixed=TRUE)
colnames(res) <- gsub("_Genotype.RData", "", allF, fixed=TRUE)
  load(allF[i])
  colnames(x)[2] <- "x1"
  s1 <- x
  for(j in (i+1):length(allF)) {
  	if (j<=length(allF)) {
	load(allF[j])
	colnames(x)[2] <- "x2"
  	res[1,j]<- matchScore(s1$x1, x$x2)
	}
	cat(allF[j], " done\n")
	}
save(res, file=paste("Merged/SNPs/Concordance/concordance_genotype_", allF[i], ".RData", sep=""))

setwd("/Merged/SNPs/Concordance")
allF <- dir()
all.res <- NULL
for (i in allF) {
load(file=paste("/Merged/SNPs/Concordance/", i, sep=""))
all.res <- rbind(all.res, res)
}

res2 <- all.res
diag(res2) <- 1
for (i in 1:nrow(res2)) {
   for (j in 1:nrow(res2)) {
      if (i>j) res2[i,j] <- res2[j,i]
      }
}
save(res2, file="/lustre/projects/cclab-metams/Oscar/Merged/SNPs/Concordance_Genotype.RData")


library(RColorBrewer)
cols <- brewer.pal(9, "Blues")
rownames(res2) <- sapply(strsplit(rownames(res2), ".", fixed=T), function(x) x[1])
colnames(res2) <- rownames(res2)
ids <- apply(res2, 1, function(x) mean(is.na(x)))
res2 <- res2[which(ids<0.5), which(ids<0.75)]
pdf("/Merged/SNPs/BAFs/GenoypingHeatmap.pdf", width=16, height=16)
heatmap(res2, scale="none", col=cols)
dev.off()
pdf("/Merged/SNPs/BAFs/Genoyping.pdf", width=8, height=16)
res2 <- res2[order(rownames(res2)), order(rownames(res2))]
for (i in 1:nrow(res2)) {
dotchart(sort(res2[i,-i]), main=rownames(res2)[i], pch=19, cex=.75)
}
dev.off()
