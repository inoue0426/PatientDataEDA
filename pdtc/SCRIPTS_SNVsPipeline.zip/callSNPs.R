setwd("./Merged/DupMarked/")
allF <- dir(pattern="*bam$")
i <- as.numeric(Sys.getenv("LSB_JOBINDEX"))
i <- allF[i]
if(!file.exists(paste("Merged/SNPs/", i, ".vcf", sep=""))) {
runString <- paste("/java/jdk1.7.0_51/bin/java -Xmx4g -jar /GATK-3.3-0/GenomeAnalysisTK.jar ", sep="")
runString <- paste(runString, " -T HaplotypeCaller -I ", i, sep="")
runString <- paste(runString, " -L  /SNPsList.intervals", sep="")
runString <- paste(runString, " -R /Genomes/ucsc.hg19_mmu10.fa", sep="")
runString <- paste(runString, " -ERC BP_RESOLUTION", sep="")
runString <- paste(runString, " -o /Merged/SNPs/", i, ".vcf  -stand_call_conf 30.0 -stand_emit_conf 20.0", sep="")
system(runString)
}

