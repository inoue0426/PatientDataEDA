load(file="/indelsAnnotated.RData")
Annot <- indels
load("/Merged/VCF/FilteredIndels_ALLSAMPLES.RData")
indels$V8 <- sapply(strsplit(rownames(indels), ";"), function(x) x[2])
indels$Chrom <- sapply(strsplit(indels$V8, ":"), function(x) x[1])
indels <- indels[which(indels$Chrom %in% paste("chr", c(1:22, "X"), sep="")),]
indels$VAF <- indels$Alt / (indels$Ref+indels$Alt)
indels$Depth <- (indels$Ref+indels$Alt)
mean(indels$V8 %in% Annot$V8)
indels$Chrom <- NULL
indels$Ref <- NULL
indels$Alt <- NULL
indels <- merge(indels, Annot, by="V8")
indels <- indels[grep("exonic", indels$GenomicPos),]
save(indels, file="/Merged/VCF/Filteredindels_Exonic_ALLSAMPLES.RData")

SS <- read.table("/SampleSheetExomes.txt", header=TRUE, sep="\t", stringsAsFactors=F)
indels$ID <- sub("_ordered_picard", "", indels$ID)
valid.ids <- SS$ID[which(SS$Include=="YES")]
SS <- SS[which(SS$ID %in% valid.ids),]
indels <- indels[which(indels$ID %in% valid.ids),]
for (i in unique(SS$Tumour)) {
	ids <- unique(SS$ID[which(SS$Tumour==i)])
	tmp <- indels[which(indels$ID %in% ids),]
	tmp$Variant <- tmp$V8
	tmp$V8 <- NULL
	all.x <- tmp[which(tmp$ID==ids[1]),]
	all.x <- all.x[,c('Variant', 'GERMLINE.1000G', 'Type', 'Exon', 'GenomicPos', 'Symbol', 
		'GERMLINE.DBSNP', 'Genotype', 'VAF', 'Depth')]
	colnames(all.x)[c(8:10)] <- paste(ids[1], colnames(all.x)[c(8:10)], sep=".")
	if (length(ids)>1) {
        	for (j in ids[-1]) {
			x <- tmp[which(tmp$ID==j),]
			x <- x[,c('Variant', 'GERMLINE.1000G', 'Type', 'Exon', 'GenomicPos', 'Symbol', 
		'GERMLINE.DBSNP', 'Genotype', 'VAF', 'Depth')]
			colnames(x)[c(8:10)] <- paste(j, colnames(x)[c(8:10)], sep=".")
			all.x <- merge(all.x, x, all=T)
		}
	}
	save(all.x, file=paste("/Merged/VCF/SNVs/", i, "_indels.RData", sep=""))
}
