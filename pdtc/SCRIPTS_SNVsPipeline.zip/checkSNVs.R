load(file="/SNVsAnnotated.RData")
Annot <- SNVs
load("/Merged/VCF/FilteredSNVs_ALLSAMPLES.RData")
SNVs$V8 <- sapply(strsplit(rownames(SNVs), ";"), function(x) x[2])
SNVs$Chrom <- sapply(strsplit(SNVs$V8, ":"), function(x) x[1])
SNVs <- SNVs[which(SNVs$Chrom %in% paste("chr", c(1:22, "X"), sep="")),]
SNVs$VAF <- SNVs$Alt / (SNVs$Ref+SNVs$Alt)
SNVs$Depth <- (SNVs$Ref+SNVs$Alt)
mean(SNVs$V8 %in% Annot$V8)
SNVs$Chrom <- NULL
SNVs$Ref <- NULL
SNVs$Alt <- NULL
SNVs <- merge(SNVs, Annot, by="V8")
SNVs <- SNVs[which(!SNVs$GenomicPos %in% c("intergenic", "intronic", "ncRNA_intronic")),]
save(SNVs, file="/Merged/VCF/FilteredSNVs_Exonic_ALLSAMPLES.RData")

SS <- read.table("/SampleSheetExomes.txt", header=TRUE, sep="\t", stringsAsFactors=F)
SNVs$ID <- sub("_ordered_picard", "", SNVs$ID)
valid.ids <- SS$ID[which(SS$Include=="YES")]
SS <- SS[which(SS$ID %in% valid.ids),]
SNVs <- SNVs[which(SNVs$ID %in% valid.ids),]
for (i in unique(SS$Tumour)) {
	ids <- unique(SS$ID[which(SS$Tumour==i)])
	tmp <- SNVs[which(SNVs$ID %in% ids),]
	tmp$Variant <- tmp$V8
	tmp$V8 <- NULL
	all.x <- tmp[which(tmp$ID==ids[1]),]
	all.x <- all.x[,c('Variant', 'GERMLINE.1000G', 'Type', 'Exon', 'GenomicPos', 'Symbol', 
		'GERMLINE.DBSNP', 'SIFT', 'POLYPHEN', 'MT', 'METALR', 'Genotype', 'VAF', 'Depth')]
	colnames(all.x)[c(12:14)] <- paste(ids[1], colnames(all.x)[c(12:14)], sep=".")
	if (length(ids)>1) {
        	for (j in ids[-1]) {
			x <- tmp[which(tmp$ID==j),]
			x <- x[,c('Variant', 'GERMLINE.1000G', 'Type', 'Exon', 'GenomicPos', 'Symbol', 
		'GERMLINE.DBSNP', 'SIFT', 'POLYPHEN', 'MT', 'METALR', 'Genotype', 'VAF', 'Depth')]
			colnames(x)[c(12:14)] <- paste(j, colnames(x)[c(12:14)], sep=".")
			all.x <- merge(all.x, x, all=T)
		}
	}
	save(all.x, file=paste("/Merged/VCF/SNVs/", i, "_SNVs.RData", sep=""))
}
