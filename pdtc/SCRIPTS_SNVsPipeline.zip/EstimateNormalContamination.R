estimateNC <- function(Tum, Norm, CN) {
    require(VariantAnnotation)
    require(GenomicRanges)
    Tum <- readVcf(Tum, "hg19")
    if (is.na(Norm)) {
        GT.T <- geno(Tum)$GT
        if(nrow(GT.T) < 10000) {
            return(list(X=NULL, est=NULL))
        }
        cands <- which(GT.T=="0/1")
        cands <- rownames(GT.T)[cands]

    } else {
        Norm <- readVcf(Norm, "hg19")
        GT.N <- geno(Norm)$GT
        if(nrow(GT.N) < 10000) {
            GT.T <- geno(Tum)$GT
            if(nrow(GT.T) < 10000) {
                return(list(X=NULL, est=NULL))
            }
        cands <- which(GT.T=="0/1")
        cands <- rownames(GT.T)[cands]

        } else {
            common.variants <- intersect(rownames(geno(Tum)$GT), rownames(geno(Norm)$GT))
        GT.T <- geno(Tum)$GT
        GT.T <- GT.T[common.variants,]
        GT.N <- GT.N[common.variants,]
        GT.N <- GT.N[match(names(GT.T), names(GT.N))]
        cands <- which(GT.N=="0/1" & GT.T=="0/1")
        cands <- names(GT.T)[cands]
        }
    }
    tmp <- strsplit(cands, ":")
    Chrom <- sapply(tmp, function(x) x[1])
    tmp <- sapply(tmp, function(x) x[2])
    Pos <- as.numeric(as.character(sapply(strsplit(tmp, "_"), function(x) x[1])))
    pos.variants <- GRanges(seqnames=Chrom, IRanges(start=Pos, end=Pos, ), ID=1:length(Chrom))
    CN <- read.table(CN, header=TRUE, sep="\t")
    pos.CN <- GRanges(seqnames=paste("chr", CN$chromosome, sep=""), IRanges(start=CN$start, end=CN$end), seg.mean=CN[,6])
    res <- findOverlaps(pos.variants, pos.CN)
    values(pos.variants)$CN <- NA
    values(pos.variants)$CN[queryHits(res)] <- values(pos.CN)$seg.mean[subjectHits(res)]
    ## CN <- CN[which(CN[,6] > -5),]
    ## changes <- data.frame(x=CN[,6])
    ## changes <- changes[order(changes$x),,drop=FALSE]
    ## changes$change <- c(0, diff(changes$x))
    ## CN.th <- 2 * sd(changes$change[which(changes$change>0)])
    ## CN.th <- max(changes[which(changes$change > CN.th),'x'])
    CN.th <- -0.1
    pos.variants <- pos.variants[which(values(pos.variants)$CN < CN.th)]
    cands <- cands[values(pos.variants)$ID]
    res <- do.call("rbind", geno(Tum)$AD[cands,])
    res <- data.frame(res)
    res$Depth <- apply(res, 1, sum)
    res$BAF <- res[,2] / res$Depth
    res$CN <- values(pos.variants)$CN
    res <- res[which(res$Depth>=20),]
    if(nrow(res) < 25) {
        return(list(X=NULL, est=NULL))
    }
    y <- density(res$BAF, from=0, to=1, n=100000)
    df <- diff(y$y) / diff(y$x)
    TOL <- 1e-2
    MIN <- quantile(y$y, 0.25)
    estimate <- which(abs(df)<TOL & y$y[-1]>MIN)
    estimate <- y$x[-1][estimate[length(estimate)]]
    list(X=res, estimate=estimate)
}

SSExomes <- read.table("/SampleSheetExomes.txt", header=TRUE, sep="\t", stringsAsFactors=FALSE)
SSExomes <- SSExomes[which(SSExomes$Include=="YES"),]
setwd("/CopyNumber")
allF <- dir(pattern=".txt")
SSExomes$Name <- gsub(" ", "_", SSExomes$Name, fixed=TRUE)
SSExomes$Name <- gsub("/", "_", SSExomes$Name, fixed=TRUE)
SSExomes$Name <- gsub("(", "_", SSExomes$Name, fixed=TRUE)
SSExomes$Name <- gsub(")", "_", SSExomes$Name, fixed=TRUE)
found <- sub("Shallow_", "", allF)
found <- sub("_ordered.bam.picard.bam_QDNAseq.txt", "", found)
Tumours <- SSExomes[which(SSExomes$ID %in% found),]

Tumours <- Tumours[which(Tumours$Type=="Tumour"),]


Tumours <- unique(Tumours)
all.est <- NULL
all.X <- NULL
for (i in 1:nrow(Tumours)) {
    Tum <- paste("/VCFs/", Tumours$ID[i], "_ordered_picard.bam.vcf.bgz_SNPS_filtered.vcf",  sep="")
    Norm <- SSExomes$ID[which(SSExomes$Tumour==Tumours$Tumour[i] & SSExomes$Type=="Normal")]
    Norm2 <- SSExomes$Name[which(SSExomes$Tumour==Tumours$Tumour[i] & SSExomes$Type=="Normal")]
    if (Tumours[i,'Tumour']=="AB521") Norm <- "AB521M-N"
    Norm <- ifelse(length(Norm)>0, paste("/Volumes/BAM_PDX/ExomeV2/VCFs/", Norm, "_ordered_picard.bam.vcf.bgz_SNPS_filtered.vcf",  sep=""), NA)
    Norm2 <- ifelse(length(Norm2)>0, paste("/Volumes/BAM_PDX/ExomeV2/VCFs/", Norm2, "_ordered_picard.bam.vcf.bgz_SNPS_filtered.vcf",  sep=""), NA)
    if (is.na(Norm)) {
        Norm <- Norm2
    } else {
        if (!file.exists(Norm)) Norm <- Norm2
    }
    CN <- paste("/Shallow_", Tumours$ID[i], "_ordered.bam.picard.bam_QDNAseq.txt", sep="")
    if (!file.exists(Tum)) Tum <- sub("_ordered", ".bam_ordered", Tum, fixed=TRUE)
    if (!is.na(Norm)) {
        if (!file.exists(Norm)) Norm <- sub("_ordered", ".bam_ordered", Norm, fixed=TRUE)
    }
    res <- estimateNC(Tum=Tum, Norm=Norm, CN=CN)
    if (!is.null(res$est)) {
        all.X <- rbind(all.X, data.frame(ID=Tumours$ID[i], res$X))
        all.est <- c(all.est, res$est)
        print(Tumours$ID[i])
        print(res$estimate)
    }
}

names(all.est) <- Tumours$ID

save(all.est, file="/NormalContamination.RData")
