library(VariantAnnotation)
setwd("/Merged/VCF/")
allF <- dir(pattern=".bgz$")
i <- as.numeric(Sys.getenv("LSB_JOBINDEX"))
i <- allF[i]

load(file="/PDX/Homopolymers.RData")
    filt <- FilterRules(
            list(
            GQ= function(x) geno(x)$GQ > 20,
                 strandbias=function(x) info(x)$FS < 40,
                 minRead=function(x) {
                     res <- rep(FALSE, length(geno(x)$DP))
                     res[which(geno(x)$DP> 5)] <- TRUE
                     res
                 },
            isindel=function(x) {
                res <- rep(FALSE, length(geno(x)$DP))
		feo <- names(rowRanges(x))
		feo <- strsplit(feo, "_")
		feo <- sapply(feo, function(x) x[length(x)])
		ALT <- sapply(strsplit(feo, "/"), function(x) x[2])
		REF <- sapply(strsplit(feo, "/"), function(x) x[1])
		res[which(nchar(ALT)>1 | nchar(REF)>1)] <- TRUE
                res
            },
            homo= function(x) {
                     candidates <- findOverlaps(rowRanges(x), HP, maxgap=3L)
                     ids <- queryHits(candidates)
                     res <- rep(TRUE, length(rowRanges(x)))
                     res[ids] <- FALSE
		     res
		 }
            ))
    filtered <- filterVcf(i, "hg19",
                          paste(i, "_indels_filtered.vcf",
                                sep=""), filters=filt)
