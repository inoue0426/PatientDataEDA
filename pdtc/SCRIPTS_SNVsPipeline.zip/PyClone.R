source("commonFunctions.R")

## Example for STG139 analysis with PyClone
## Samples: STG139-T, STG139-X0, STG139-X2, STG139-X2R, STG139-X3, STG139-X12, STG139-X13, STG139-X14, 	STG139M-T, STG139M-X0, STG139M-X2, STG139M-X2R, STG139M-X5,
## STG139M-X5R1, STG139M-X5R1C7, STG139M-X5R1C10
load(“/SNVs/ALLSTG139_SNVs_MissingIncluded.RData")
result <- all.x[,-c(8:11)]
load(“/SNVs/ALLSTG139_Indels_MissingIncluded.RData")
result <- rbind(result, all.x)
save(result, file="/PyClone/ALLSTG139.RData")

setwd("/PyClone/ASCAT/ALLSTG139/")
tumor = c("STG139-T", "STG139-X0", "STG139-X2", "STG139-X2R", "STG139-X3", "STG139-X12", "STG139-X13", "STG139-X14",
    "STG139M-T", "STG139M-X0", "STG139M-X2", "STG139M-X2R", "STG139M-X5", "STG139M-X5R1", "STG139M-X5R1C7", "STG139M-X5R1C10")
normal <- "STG139-NR"
generate.BAF.ASCAT.files("/PyClone/ALLSTG139.RData", normal, tumor);

BAF.tumor.files= paste0(tumor, "_tumor_BAF.txt");
BAF.normal.files= paste0(tumor, "_normal_BAF.txt");
tumor.files = paste0(“/CopyNumberShifted/Shallow_", tumor, "_ordered.bam.picard.bam_QDNAseq.txt");
normal.files = paste0("/CopyNumberShifted/Shallow_", normal, "_ordered.bam.picard.bam_QDNAseq.txt");
generate.LogR.ASCAT.files(PDX.string, tumor.files, normal.files, BAF.tumor.files,
                          BAF.normal.files)

## run ASCAT
file.types = c("tumor_LogR", "tumor_BAF", "normal_LogR", "normal_BAF");

PDX.string <- tumor
file.types.unmatched = c("tumor_LogR", "tumor_BAF");
for (i in PDX.string) {
    setwd("/PyClone/ASCAT/ALLSTG139/")
    system(paste("mkdir", i))
    setwd(i)
    files = paste0("../", i, "_", file.types, ".txt");
    generate.Ascat.Output(files)
}

## Now we prepare Pyclone

VAF.tumor <- tumor

ss = paste0(unique(c(VAF.tumor)), ".Depth");
sample.set <- list()
for (i in 1:length(VAF.tumor)) sample.set[[i]] <- ss

cn.files = paste0("/PyClone/ASCAT/ALLSTG139/", VAF.tumor, "/segments.txt")


# assume snp, repeat and dup data are in the global environment

filter.for.all.mutations("/PyClone/ALLSTG139.RData",
                         VAF.tumor,
                                cn.files, sample.set[[i]]);


setwd("/PyClone/Inputs/")
allF <- dir(pattern=".tsv")
allF <- sub(".tsv", "", allF, fixed=TRUE)
allF <- allF[grep("STG139", allF, fixed=TRUE)]
allF <- allF[-grep("TREAT", allF)]
for (i in allF) {
    system(paste("PyClone build_mutations_file --ref_prior normal  --var_prior parental_copy_number /Users/rueda01/Documents/Projects/PDTX/PyClone/Inputs/", i, ".tsv  /PyClone/Inputs/", i, ".yaml", sep=""))
}

setwd("../")
system("PyClone analyse ALLSTG139-config.yaml")
system("PyClone cluster ALLSTG139-config.yaml ./Outputs/ALLSTG139.tsv --burnin 20000")
system("PyClone build_table --burnin 20000 ALLSTG139-config.yaml ./Outputs/ALLSTG139-results.tsv")

## Now plot results
setwd("/PyClone/Outputs")

cluster.means = function(data.table) {
  num.cols = ncol(data.table);
  num.clusters = max(data.table[,num.cols]);
  frequencies = vector(length=num.clusters);
  result.table = data.table[1:num.clusters,];
  for (i in 1:num.clusters) {
    cluster.subset = data.table[which(data.table[,num.cols]==i),];
    head(cluster.subset)
    frequencies[i] = nrow(cluster.subset);
    result.table[i,] = colMeans(cluster.subset);
  }
  result.table = cbind(result.table, frequencies);
}

# remove listed clusters
remove.clusters = function(data.table, clusters.to.remove) {
  num.cols = ncol(data.table);
  rows.to.remove = which(data.table[,num.cols] %in% clusters.to.remove)
  data.table = data.table[-rows.to.remove,]
  # renumber cluster definitions to be consecutive ints
  data.table = data.table[order(data.table[,num.cols]),];
  cluster.id = 1;
  old.clust.id=data.table[1, num.cols];
  for (i in 1:nrow(data.table)) {
    if (old.clust.id != data.table[i, num.cols]) {
      cluster.id = cluster.id + 1;
    }
    old.clust.id = data.table[i, num.cols];
    data.table[i, num.cols] = cluster.id;
  }
  return(data.table);
}
data.ALLSTG139 = read.table(
  "ALLSTG139-results.tsv");
means.ALLSTG139 = cluster.means(data.ALLSTG139)
pdf("/PyClone/Outputs/ALLSTG139_means.pdf");
max.cluster = max(means.ALLSTG139[, 'cluster_id']);
par(mfrow=c(1,1), mar=par("mar")+c(2,0,0,5), xpd=F)
plot(1, type="n", xlab="Sample", ylab="Predicted Cellular Frequency", xlim=c(1,16),
     ylim=c(0,1), xaxt="n", main="STG139", xaxs="i", yaxs="i", cex.axis=1.3,
     cex.lab=1.3, cex.main=2)
grid(nx=1, ny=5, col="black");
axis(1, at=1:16, labels=tumor, cex.axis=1.1,
     las=2)
color.list = c(90,16,47,26,31,640,40,552,24, 1:15)
for (i in 1:nrow(means.ALLSTG139)) {
  lines(1:16, means.ALLSTG139[i, c(1,3,5,7,9,11,12,15,17,19,21,22,25,26,27,29)],
        col=colors()[color.list[i]], lwd=(means.ALLSTG139$frequencies[i]/2))
}
par(xpd=T)
legend("topright", inset=c(-0.25,0), legend=paste0(1:max.cluster, " (",
        means.ALLSTG139$frequencies, ")"), col=colors()[color.list],
       lty=1,lwd=4, y.intersp=0.7, x.intersp=0.6, title="Cluster (n)", seg.len=0.6,
       bty="n",cex=1.3)
dev.off();


################################################################################
################################################################################


########################## Annotate genes

setwd("/PyClone/Outputs/")
allF <- dir(pattern=".tsv")
allF <- allF[grep("results", allF, fixed=TRUE)]
for (i in allF) {
    x <- read.table(i)
    x$Variant <- rownames(x)
    load(paste("PyClone/",
               sub("-results.tsv", "", i, fixed=TRUE),
               ".RData", sep=""))
    result <- result[,1:7]
    x <- merge(x, result, by="Variant", all.x=T)
    write.table(x, file=paste("/PyClone/Outputs/Genes/",
                       sub("-results.tsv", "", i, fixed=TRUE),
                       ".txt", sep=""), row.names=F, sep="\t", quote=F)
}

########################## Check 40 genes


setwd("/PyClone/Outputs/")
Genes <- read.table("/PyClone/driverType_combined.txt",
                    header=T, stringsAsFactors=F)
load("signifClusters.RData")
setwd("/PyClone/Outputs/Genes")
allF <- dir(pattern=".txt")
allF <- allF[-c(1, 6, 16:17, 21:24, 26, 28, 32:35)]
all.res <- NULL

Tot <- list()
Change <- list()
for (i in allF) {
    x <- read.table(i, header=T, sep="\t", stringsAsFactors=F)
    ids <- which(x$Symbol %in% Genes$gene)
    Tot[[i]] <- x$Symbol[ids]
    cl <- which(x$cluster_id[ids] %in%
                    asterisks[[sub(".txt", "", i, fixed=TRUE)]])
    Change[[i]] <- x$Symbol[ids][cl]
}

length(do.call("c", Tot))
length(unique(do.call("c", Tot)))
length(do.call("c", Change))


########################## Check significant clusters



cluster.means = function(data.table) {
  num.cols = ncol(data.table);
  num.clusters = max(data.table[,num.cols]);
  frequencies = vector(length=num.clusters);
  result.table = data.table[1:num.clusters,];
  for (i in 1:num.clusters) {
    cluster.subset = data.table[which(data.table[,num.cols]==i),];
    head(cluster.subset)
    frequencies[i] = nrow(cluster.subset);
    result.table[i,] = colMeans(cluster.subset);
  }
  result.table = cbind(result.table, frequencies);
}

# remove listed clusters
remove.clusters = function(data.table, clusters.to.remove) {
  num.cols = ncol(data.table);
  rows.to.remove = which(data.table[,num.cols] %in% clusters.to.remove)
  data.table = data.table[-rows.to.remove,]
  # renumber cluster definitions to be consecutive ints
  data.table = data.table[order(data.table[,num.cols]),];
  cluster.id = 1;
  old.clust.id=data.table[1, num.cols];
  for (i in 1:nrow(data.table)) {
    if (old.clust.id != data.table[i, num.cols]) {
      cluster.id = cluster.id + 1;
    }
    old.clust.id = data.table[i, num.cols];
    data.table[i, num.cols] = cluster.id;
  }
  return(data.table);
}

get.PDX.T.change = function(means.data, PDX.name, tumor.list, passage.list) {
  num.clusters=max(means.data$cluster_id);
  num.tumors = length(tumor.list);
  num.passages = length(passage.list);
  total.sum = 0
  for(k in 1:num.tumors) {
    for (i in 1:num.passages) {
      for (j in 1:num.clusters) {
        tumor.value = means.data[j,paste0(PDX.name,".",tumor.list[k])];
        passage.value = means.data[j,paste0(PDX.name,".",passage.list[i])];
        total.sum = total.sum + abs(tumor.value-passage.value);
      }
    }
  }
  total.sum = total.sum/(num.clusters*num.tumors*num.passages);
}

get.PDX.passage.change = function(means.data, PDX.name, passage.list) {
  num.clusters=max(means.data$cluster_id);
  num.passages = length(passage.list);
  total.sum = 0
  for (i in 1:num.passages) {
    for (j in 1:num.clusters) {
      mean = mean(as.numeric(means.data[j,paste0(PDX.name,".",passage.list)]));
      passage.value = means.data[j,paste0(PDX.name,".",passage.list[i])];
      total.sum = total.sum + abs(mean-passage.value);
    }
  }
  total.sum = total.sum/(num.clusters*num.passages);
}

get.PDX.culture.change = function(means.data, PDX.name, passage.name,
                                  culture.list) {
  num.clusters=max(means.data$cluster_id);
  num.cultures = length(culture.list);
  total.sum = 0
  for (i in 1:num.cultures) {
    for (j in 1:num.clusters) {
      PDX.value = means.data[j,paste0(PDX.name,".",passage.name)];
      culture.value = means.data[j,paste0(PDX.name,".",culture.list[i])];
      total.sum = total.sum + abs(culture.value-PDX.value);
    }
  }
  total.sum = total.sum/(num.clusters*num.cultures);
}

##################### AB521M #########################
data.AB521M = read.table(
  "PyClone/Outputs/ALLAB521-results.tsv");
means.AB521M = cluster.means(data.AB521M);
num.AB521M.tumor = get.PDX.T.change(means.AB521M, "AB521M",c("T"), c("X1", "X1R", "X1R1"))
num.AB521M.culture = get.PDX.culture.change(means.AB521M, "AB521M","X1", "X1C7");

##################### AB551 #########################
data.AB551 = read.table(
  "PyClone/Outputs/AB551-results.tsv");
means.AB551 = cluster.means(data.AB551);
num.AB551.tumor = get.PDX.T.change(means.AB551, "AB551",c("T","TR"),
                                   c("X0", "X0R1"));

##################### AB630 #########################
data.AB630 = read.table(
  "PyClone/Outputs/AB630-results.tsv");
means.AB630 = cluster.means(data.AB630);
num.A630.tumor = get.PDX.T.change(means.AB630, "AB630",c("T"),
                                   c("X0", "X0R"));


##################### HCI001 #########################
data.HCI001 = read.table(
  "PyClone/Outputs/HCI001-results.tsv");
means.HCI001 = cluster.means(data.HCI001);
num.HCI001.tumor = get.PDX.T.change(means.HCI001, "HCI001",c("T"), c("X0R"));
num.HCI001.passage = get.PDX.passage.change(means.HCI001, "HCI001",
                                            c("X0R", "X3", "X4", "X5"));

##################### HCI002 #########################
data.HCI002 = read.table(
  "PyClone/Outputs/HCI002-results.tsv");
means.HCI002 = cluster.means(data.HCI002);
num.HCI002.tumor = get.PDX.T.change(means.HCI002, "HCI002",c("T"), c("X3R"));

##################### HCI004 #########################
data.HCI004 = read.table(
  "PyClone/Outputs/HCI004-results.tsv");
means.HCI004 = cluster.means(data.HCI004);
num.HCI004.tumor = get.PDX.T.change(means.HCI004, "HCI004",c("T"), c("X1R"));
num.HCI004.passage = get.PDX.passage.change(means.HCI004, "HCI004",
                                            c("X1R", "X2", "X3"));

##################### HCI005 #########################
data.HCI005 = read.table(
  "PyClone/Outputs/HCI005-results.tsv");
means.HCI005 = cluster.means(data.HCI005);
num.HCI005.tumor = get.PDX.T.change(means.HCI005, "HCI005",c("T"), c("X2R"));

##################### HCI008 #########################
data.HCI008 = read.table(
  "PyClone/Outputs/HCI008-results.tsv");
means.HCI008 = cluster.means(data.HCI008);
num.HCI008.tumor = get.PDX.T.change(means.HCI008, "HCI008",c("T"), c("X1R"));

##################### HCI009 #########################
data.HCI009 = read.table(
  "PyClone/Outputs/HCI009-results.tsv");
means.HCI009 = cluster.means(data.HCI009);
num.HCI009.tumor = get.PDX.T.change(means.HCI009, "HCI009",c("T"), c("X0R"));
num.HCI009.passage = get.PDX.passage.change(means.HCI009, "HCI009",
                                            c("X0R", "X1R"));

##################### HCI010 #########################
data.HCI010 = read.table(
  "PyClone/Outputs/HCI010-results.tsv");
means.HCI010 = cluster.means(data.HCI010);
num.HCI010.passage = get.PDX.passage.change(means.HCI010, "HCI010",
                              c("X0", "X1", "X2", "X3"));

##################### STG139 #########################
data.STG139 = read.table(
  "PyClone/Outputs/ALLSTG139-results.tsv");
means.STG139 = cluster.means(data.STG139);
num.STG139.tumor = get.PDX.T.change(means.STG139, "STG139",c("T"), c("X0"));
num.STG139.passage = get.PDX.passage.change(means.STG139, "STG139",
                      c("X0", "X2", "X3", "X12", "X13", "X14"));
num.STG139M.tumor <- get.PDX.T.change(means.STG139, "STG139M", "T", "X0")
num.STG139M.passage <- get.PDX.passage.change(means.STG139, "STG139M", c("X0", "X2",
                                              "X2R", "X5"))
num.STG139M.culture = get.PDX.culture.change(means.STG139, "STG139M","X5R1",
                                            c("X5R1C7", "X5R1C10"));

##################### STG143 #########################
data.STG143 = read.table(
  "PyClone/Outputs/STG143-results.tsv");
means.STG143 = cluster.means(data.STG143);
num.STG143.passage = get.PDX.passage.change(means.STG143, "STG143",
                                            c("X0", "X2"));

##################### STG195 #########################
data.STG195 = read.table(
  "PyClone/Outputs/STG195-results.tsv");
means.STG195 = cluster.means(data.STG195);
num.STG195.passage = get.PDX.passage.change(means.STG195, "STG195",
                                            c("X0", "X2", "X3"));

##################### STG201 #########################
data.STG201 = read.table(
  "PyClone/Outputs/STG201-results.tsv");
means.STG201 = cluster.means(data.STG201);
num.STG201.tumor = get.PDX.T.change(means.STG201, "STG201",c("T"), c("X0","X0R"));
num.STG201.passage = get.PDX.passage.change(means.STG201, "STG201",
                                            c("X0", "X2", "X3", "X6"));

##################### STG282 #########################
data.STG282 = read.table(
  "PyClone/Outputs/STG282-results.tsv");
means.STG282 = cluster.means(data.STG282);
num.STG282.tumor = get.PDX.T.change(means.STG282, "STG282",c("T"),
                                    c("X1","X1R", "X1R1"));
num.STG282.passage = get.PDX.passage.change(means.STG282, "STG282",
                                            c("X1","X2"));
num.STG282.culture = get.PDX.culture.change(means.STG282, "STG282","X1",
                                            c("X1C4", "X1C7"));

##################### STG316 #########################
data.STG316 = read.table(
  "PyClone/Outputs/STG316-results.tsv");
means.STG316 = cluster.means(data.STG316);

##################### VHIO089 #########################
data.VHIO089 = read.table(
  "PyClone/Outputs/VHIO089-results.tsv");
means.VHIO089 = cluster.means(data.VHIO089);
num.VHIO089.tumor = get.PDX.T.change(means.VHIO089, "VHIO089",c("T"), c("X15"));

##################### VHIO093 #########################
data.VHIO093 = read.table(
  "PyClone/Outputs/VHIO093-results.tsv");
means.VHIO093 = cluster.means(data.VHIO093);
num.VHIO093.tumor = get.PDX.T.change(means.VHIO093, "VHIO093",c("T"), c("X5R"));

##################### VHIO098 #########################
data.VHIO098 = read.table(
  "PyClone/Outputs/VHIO098-results.tsv");
means.VHIO098 = cluster.means(data.VHIO098);
num.VHIO098.passage = get.PDX.passage.change(means.VHIO098, "VHIO098",
                                             c("X10", "X11"));

##################### VHIO179 #########################
data.VHIO179 = read.table(
  "PyClone/Outputs/VHIO179-results.tsv");
means.VHIO179 = cluster.means(data.VHIO179);
num.VHIO179.passage = get.PDX.passage.change(means.VHIO179, "VHIO179",
                                             c("X7", "X9"));

##################### CAMBMT1 #########################
data.CAMBMT1 = read.table(
  "PyClone/Outputs/CAMBMT1-results.tsv");
means.CAMBMT1 = cluster.means(data.CAMBMT1);
colnames(means.CAMBMT1) <- toupper(colnames(means.CAMBMT1))
colnames(means.CAMBMT1)[21] <- "cluster_id"
num.CAMBMT1.tumor = get.PDX.T.change(means.CAMBMT1, "CAMBMT1",
    c("T1", "T2", "T3", "T4", "T5"),
    c("T1.X0", "T2.X0", "T3.X0", "T4.X0", "T5.X0"))


################## tumor plot ################
tumor.values = matrix(c(num.AB521M.tumor, num.AB551.tumor, num.A630.tumor, num.CAMBMT1.tumor,
    num.HCI001.tumor, num.HCI002.tumor,
                 num.HCI004.tumor, num.HCI005.tumor, num.HCI008.tumor,
    num.HCI009.tumor, num.STG139.tumor, num.STG139M.tumor,
    num.STG201.tumor,
                 num.STG282.tumor, num.VHIO089.tumor, num.VHIO093.tumor), ncol=1);
rownames = c("AB521M", "AB551", "AB630", "CAMBMT1", "HCI001", "HCI002", "HCI004",
    "HCI005", "HCI008", "HCI009",
             "STG139", "STG139M", "STG201", "STG282", "VHIO089", "VHIO093");
order = order(tumor.values);
tumor.values = tumor.values[order,];
rownames = rownames[order];
pdf("PyClone/Outputs/tumor_overall.pdf");
plot(1, type="n", ylab="Change in Cellular Frequency", xlab="",
     xlim=c(0,(length(tumor.values)+1)), ylim=c(0,0.5),
     xaxt="n", main="Average Change in Cluster Cellular Frequencies
     between Tumor and Earliest Passage", xaxs="i", yaxs="i", cex.lab=1.1,
     cex.axis=1.1, cex.main=1.2)
axis(1, at=1:length(tumor.values), labels=rownames, cex.axis=0.9, las=2)
points(1:length(tumor.values), tumor.values, pch=20, cex=1.8)
dev.off();

################## passage plot ################
passage.values = matrix(c(num.HCI001.passage,
    num.HCI004.passage, num.HCI009.passage, num.HCI010.passage,
    num.STG139.passage, num.STG139M.passage,num.STG143.passage,
    num.STG195.passage,
                   num.STG201.passage, num.STG282.passage,
                   num.VHIO098.passage, num.VHIO179.passage), ncol=1);
num.passages = c(2,4,3,2,7,7, 5,3,4,5,4,3,2)
rownames = c("HCI001", "HCI004", "HCI009","HCI010", "STG139", "STG139M",
             "STG143", "STG195", "STG201", "STG282", "VHIO098", "VHIO179");
order = order(passage.values);
passage.values = passage.values[order,]
rownames = rownames[order];
num.passages = num.passages[order];
pdf("PyClone/Outputs/passage_overall.pdf", useDingbats=F);
plot(1, type="n", ylab="Change in Cellular Frequency", xlab="",
     xlim=c(0,(length(passage.values)+1)), ylim=c(0,0.5),
     xaxt="n", main="Average Change in Cluster Cellular
     Frequencies across Passages", xaxs="i", yaxs="i", cex.lab=1.3,
     cex.axis=1.3, cex.main=1.2)
axis(1, at=1:length(passage.values), labels=rownames, cex.axis=1.2, las=2)
points(1:length(passage.values), passage.values, pch=16, cex =(num.passages/2))
#text(1:length(passage.values), passage.values, labels=num.passages, cex=0.9, pos=3)
text(4, .24, labels = "Number of passages analyzed is
                  indicated by point size.", cex=1.2)
dev.off();

################## culture plot ################
culture.values = matrix(c(num.AB521M.culture, num.STG139M.culture,
                          num.STG282.culture), ncol=1);
rownames = c("AB521M", "STG139M", "STG282");
order = order(culture.values);
culture.values = culture.values[order,];
rownames = rownames[order];
pdf("PyClone/Outputs/culture_overall.pdf");
plot(1, type="n", ylab="Change in Cellular Frequency", xlab="",
     xlim=c(0,(length(culture.values)+1)), ylim=c(0,0.5),
     xaxt="n", main="Average Change in Cluster Cellular
     Frequencies due to Cell Culture", xaxs="i", yaxs="i", cex.lab=1.3,
     cex.axis=1.3, cex.main=1.2)
axis(1, at=1:length(culture.values), labels=rownames, cex.axis=0.9, las=1)
points(1:length(culture.values), culture.values, pch=20, cex=1.6)
dev.off();
