filter.for.all.mutations = function(snv.file, tumor.name, cn.file,
                                sample.set, use.latest=T) {
    if (use.latest) {
        snps.repeats.dups = "~/Documents/Projects/PDTX/PyClone/SNPs_Repeats_V3.RData"
    } else {
        snps.repeats.dups = "~/Documents/Projects/PDTX/PyClone/SNPs_Repeats.RData"
    }

    load(snps.repeats.dups)

    load(snv.file);
  ## normal.depth = paste0(normal.name, ".Depth");
  ## normal.VAF = paste0(normal.name, ".VAF");
  tumor.depth = paste0(tumor.name, ".Depth");
  tumor.VAF = paste0(tumor.name, ".VAF");
  # remove any entries for which the median read counts (across all samples
  # that we are using) were less than 50, we want mutations to be deeply sequenced
  # locate all the columns that are part of set of samples used
  depth.data.frame = result[,sample.set];
  # to take the median treat any NA values as 0's
  depth.data.frame[is.na(depth.data.frame)] <- 0;
  depth.matrix = as.matrix(depth.data.frame);
  rowMedians = apply(depth.matrix, 1, median);
  to.keep = which(rowMedians > 50);
  result = result[to.keep,];

  # make sure all entries have a read depth of at least 15
  depth.data.frame = result[,sample.set];
  # to take the median treat any NA values as 0's
  depth.data.frame[is.na(depth.data.frame)] <- 0;
  depth.matrix = as.matrix(depth.data.frame);
  to.remove = apply(depth.matrix, 1, function(x) any(x<15));
  if (length(which(to.remove)) > 0) { result = result[-which(to.remove),]; }
  # Matches with SNPs
  matches = result[,1] %in% SNPs;
  result = result[!matches,]
  # matches with Dups
  matches = result[,1] %in% Dups;
  result = result[!matches,]
  # matches with Repeats
  matches = result[,1] %in% Repeats;
  result = result[!matches,]

  # remove if low VAF frequency across all samples
    sample.VAF = strsplit(sample.set,".Depth");
  sample.VAF = paste0(as.vector(sample.VAF), ".VAF")
  VAF.data.frame = result[,sample.VAF]
  VAF.data.frame[is.na(VAF.data.frame)] <- 0;
  VAF.matrix = as.matrix(VAF.data.frame);
  to.remove = apply(VAF.matrix, 1, function(x) all(x<0.1));
  if (length(which(to.remove)) > 0) { result = result[-which(to.remove),]; }

    tmp <- list()
    for (i in 1:length(cn.file)) {
        tmp[[i]] <- get.cn.data(result[,"Pos"], cn.file[i])
    }
    miss <- lapply(tmp, function(x) which(is.na(x[,2])))
    miss <- do.call("c", miss)
    miss <- unique(miss)
    if (length(miss)>0) {
        tmp <- lapply(tmp, function(x) x[-miss,])
        result <- result[-miss,]
    }
                                        # post process be removing any mutations with a copy number of 0
    cnzero <- lapply(tmp, function(x) which(x[,1]==0))
    cnzero <- unique(do.call("c", cnzero))
    if (length(cnzero)>0) {
        tmp <- lapply(tmp, function(x) x[-cnzero,])
        result <- result[-cnzero,]
    }

                                        # if greater than 300 mutations remain, keep 300 with highest median coverage
                                        # across the samples
    if (nrow(result) > 300) {
        print("limit total num")
    depth.data.frame = result[,sample.set];
    depth.data.frame[is.na(depth.data.frame)] <- 0;
    depth.matrix = as.matrix(depth.data.frame);
    rowMedians = apply(depth.matrix, 1, median);
    cov.value = sort(rowMedians, decreasing=T) [300];
    to.keep = which(rowMedians >= cov.value);
        result = result[to.keep,];
        tmp <- lapply(tmp, function(x) x[to.keep,])
  }

  # format data as is required by PyClone
    ## WE ARE HERE
    for (i in 1:length(tumor.name)) {
        output = data.frame(mutation_id=result[,"Variant"],
            ref_counts=round((1-result[,tumor.VAF[i]])*result[,tumor.depth[i]]),
           var_counts=round(result[,tumor.VAF[i]]*result[,tumor.depth[i]]),
           normal_cn=2, minor_cn=tmp[[i]][,2],
           major_cn=tmp[[i]][,1])
        output[is.na(output)] <- 0;
        file.name = paste0("/Users/rueda01/Documents/Projects/PDTX/PyClone/Inputs/",
            sub(".Depth", "", sample.set[i], fixed=TRUE),
                     ".tsv");
        write.table(output, file=file.name,
                  , sep = "\t", row.names=F, col.names=T,
              quote=F);
    }
}



filter.for.mutations = function(snv.file, tumor.name, cn.file,
                                sample.set) {
    snps.repeats.dups = "~/Documents/Projects/PDTX/PyClone/SNPs_Repeats.RData"

load(snps.repeats.dups)

load(snv.file);
  ## normal.depth = paste0(normal.name, ".Depth");
  ## normal.VAF = paste0(normal.name, ".VAF");
  tumor.depth = paste0(tumor.name, ".Depth");
  tumor.VAF = paste0(tumor.name, ".VAF");
  # remove any entries for which the median read counts (across all samples
  # that we are using) were less than 50, we want mutations to be deeply sequenced
  # locate all the columns that are part of set of samples used
  depth.data.frame = result[,sample.set];
  # to take the median treat any NA values as 0's
  depth.data.frame[is.na(depth.data.frame)] <- 0;
  depth.matrix = as.matrix(depth.data.frame);
  rowMedians = apply(depth.matrix, 1, median);
  to.keep = which(rowMedians > 50);
  result = result[to.keep,];

  # make sure all entries have a read depth of at least 15
  depth.data.frame = result[,sample.set];
  # to take the median treat any NA values as 0's
  depth.data.frame[is.na(depth.data.frame)] <- 0;
  depth.matrix = as.matrix(depth.data.frame);
  to.remove = apply(depth.matrix, 1, function(x) any(x<15));
  if (length(which(to.remove)) > 0) { result = result[-which(to.remove),]; }
  # Matches with SNPs
  matches = result[,1] %in% SNPs;
  result = result[!matches,]
  # matches with Dups
  matches = result[,1] %in% Dups;
  result = result[!matches,]
  # matches with Repeats
  matches = result[,1] %in% Repeats;
  result = result[!matches,]

  # remove if low VAF frequency across all samples
    sample.VAF = strsplit(sample.set,".Depth");
  sample.VAF = paste0(as.vector(sample.VAF), ".VAF")
  VAF.data.frame = result[,sample.VAF]
  VAF.data.frame[is.na(VAF.data.frame)] <- 0;
  VAF.matrix = as.matrix(VAF.data.frame);
  to.remove = apply(VAF.matrix, 1, function(x) all(x<0.1));
  if (length(which(to.remove)) > 0) { result = result[-which(to.remove),]; }

  # if greater than 300 mutations remain, keep 300 with highest median coverage
  # across the samples
  if (nrow(result) > 300) {
    print("limit total num")
    depth.data.frame = result[,sample.set];
    depth.data.frame[is.na(depth.data.frame)] <- 0;
    depth.matrix = as.matrix(depth.data.frame);
    rowMedians = apply(depth.matrix, 1, median);
    cov.value = sort(rowMedians, decreasing=T) [300];
    to.keep = which(rowMedians >= cov.value);
    result = result[to.keep,];
  }

  # format data as is required by PyClone
feo <- get.cn.data(result[,"Pos"], cn.file)
    output = data.frame(mutation_id=result[,"Variant"],
           ref_counts=round((1-result[,tumor.VAF])*result[,tumor.depth]),
           var_counts=round(result[,tumor.VAF]*result[,tumor.depth]),
           normal_cn=2, minor_cn=feo[,2],
           major_cn=feo[,1])
  # throw out rows which have major as NA
  # indicates region for which no copy number data was generated
  to.discard <- which(is.na(output$major_cn));
  if (length(to.discard) > 0) {
    output = output[-to.discard, ]; }

  # replace any NA values with 0's
  output[is.na(output)] <- 0;

  # post process be removing any mutations with a copy number of 0
  to.keep=which(output$major_cn != 0);
  output = output[to.keep,];

  return(output)
}

get.cn.data = function(pos.data, cn.file){
    cn.data = read.table(cn.file, header=T, stringsAsFactors=F)
  cn.data = unique(cn.data); # only keep unique copy number entries
  pos=strsplit(pos.data, ':');
chr.name=sapply(pos, "[", 1);
chr.name <- sub("chr", "", chr.name, fixed=TRUE)
loc=sapply(pos, "[", 2);
  loc = as.numeric(loc);
  cn.results = matrix(NA, length(pos.data),2);
  # for each entry in the positional data determine the copy number
  for (i in 1:length(pos.data)) {
    match = which(((chr.name[i]==cn.data$chr) & (loc[i]<=cn.data$endpos)) &
      (loc[i]>=cn.data$startpos));
    if (length(match)==1) {
        cn.results[i,1] = cn.data[match,5]
        cn.results[i,2] = cn.data[match,6]
    }
  }
  return(cn.results);
}

                                        # file names must be in the right order
generate.Ascat.Output <- function(files, gamma=0.55) {
  source("~/Documents/Projects/PDTX/PyClone/ASCAT/ascat.R")
  ascat.bc = ascat.loadData(files[1], files[2], files[3], files[4],
                            chrs=c(1:22, "X"), gender="XX")

  ascat.plotRawData(ascat.bc)
  ascat.bc = ascat.aspcf(ascat.bc)
  ascat.plotSegmentedData(ascat.bc)
  ascat.output = ascat.runAscat(ascat.bc, gamma=gamma)
  segments.ascat <- data.frame(ascat.output$segments)
  write.table(segments.ascat, file="segments.txt", sep = "\t", row.names=F,
              col.names=T, quote=F);
}

generate.Unmatched.Ascat.Output <- function(files, gamma=0.55) {
  source("~/Documents/Projects/PDTX/PyClone/ASCAT/ascat.R")
  ascat.bc = ascat.loadData(files[1], files[2],
                            chrs=c(1:22, "X"), gender="XX")
  ascat.plotRawData(ascat.bc)
  platform = "Affy10k"
  ascat.gg = ascat.predictGermlineGenotypes(ascat.bc, platform)
  ascat.bc = ascat.aspcf(ascat.bc, ascat.gg=ascat.gg, penalty=0)
  ascat.plotSegmentedData(ascat.bc)
  ascat.output = ascat.runAscat(ascat.bc, gamma=gamma)
  segments.ascat <- data.frame(ascat.output$segments)
  write.table(segments.ascat, file="segments.txt", sep = "\t", row.names=F,
              col.names=T, quote=F);
}

generate.LogR.ASCAT.files = function(PDX.string, tumor.files, normal.file,
                          BAF.tumor.files, BAF.normal.files) {
  for (i in 1:length(BAF.tumor.files)) {
    # read in BAF files
    BAF.tumor = read.table(BAF.tumor.files[i], header=T);
    BAF.normal = read.table(BAF.normal.files[i], header=T);

    # start with normal
    normal.data = read.table(normal.file, header=T);
    output.normal = data.frame(character(), numeric(), numeric(),
                               stringsAsFactors=F);
    chrom.list = normal.data$chromosome;
    start.list = as.numeric(normal.data$start);
    end.list = as.numeric(normal.data$end);
    to.remove = vector(length=0);
    logR.index.list = vector(length=0);
    # find BAF positions and write those to the file
    for (j in 1:nrow(BAF.tumor)) {
      chr = as.character(BAF.tumor$chrs[j]);
      loc = as.numeric(BAF.tumor$pos[j]);
      index = which(chrom.list==chr & (start.list<=loc & end.list>=loc));
      if (length(index)==1) {
        new.row = rbind(c(chr, loc, as.numeric(normal.data[index,5])));
        names(new.row) = c("chrs", "pos", tumor[i]);
        output.normal = rbind(output.normal, data.frame(new.row,
                                                        stringsAsFactors=F));
        logR.index.list = c(logR.index.list, index);
      }
      else {
        # remove that row from the BAF files
        to.remove = c(to.remove, j);
      }
    }
    colnames(output.normal) = c("chrs", "pos", tumor[i]);
    BAF.tumor = BAF.tumor[-to.remove,];
    BAF.normal = BAF.normal[-to.remove,];

    # tumor data
    tumor.data = read.table(tumor.files[i], header=T);
    output.tumor = data.frame(output.normal$chrs, output.normal$pos,
                                  as.numeric(tumor.data[logR.index.list,5]));

    colnames(output.tumor) = c("chrs", "pos", tumor[i])

    # remove any of the rows that contain values that are not between 2 and -2
    to.keep = which(abs(as.numeric(output.normal[,3])) < 2);
    output.normal = output.normal[to.keep,];
    output.tumor = output.tumor[to.keep,];
    BAF.tumor = BAF.tumor[to.keep,];
    BAF.normal = BAF.normal[to.keep,];

    to.keep = which(abs(as.numeric(output.tumor[,3])) < 2);
    output.normal = output.normal[to.keep,];
    output.tumor = output.tumor[to.keep,];
    BAF.tumor = BAF.tumor[to.keep,];
    BAF.normal = BAF.normal[to.keep,];

    rownames <- paste0("SNV", 1:nrow(output.normal));
    rownames(output.normal) <- rownames;
    rownames(output.tumor) <- rownames;
    rownames(BAF.normal) <- rownames;
    rownames(BAF.tumor) <- rownames;
    colnames(BAF.normal) <- colnames(output.normal);
    colnames(BAF.tumor) <- colnames(output.tumor);

    out.name.normal = paste0(tumor[i], "_normal_LogR.txt");
    write.table(output.normal, file=out.name.normal, sep = "\t", row.names=T,
                col.names=T, quote=F);
    out.name.tumor = paste0(tumor[i], "_tumor_LogR.txt");
    write.table(output.tumor, file=out.name.tumor, sep = "\t", row.names=T,
                col.names=T, quote=F);
    BAF.name.normal = paste0(tumor[i], "_normal_BAF.txt");
    write.table(BAF.normal, file=BAF.name.normal, sep = "\t", row.names=T,
                col.names=T, quote=F);
    BAF.name.tumor = paste0(tumor[i], "_tumor_BAF.txt");
    write.table(BAF.tumor, file=BAF.name.tumor, sep = "\t", row.names=T,
                col.names=T, quote=F);
  }
}

generate.Unmatched.LogR.ASCAT.files = function(PDX.string, tumor.files,
                                     BAF.tumor.files) {
  for (i in 1:length(BAF.tumor.files)) {
    # read in BAF files
    BAF.tumor = read.table(BAF.tumor.files[i], header=T);

    tumor.data = read.table(tumor.files[i], header=T);
    output.tumor = data.frame(character(), numeric(), numeric(),
                               stringsAsFactors=F);
    chrom.list = tumor.data$chromosome;
    start.list = as.numeric(tumor.data$start);
    end.list = as.numeric(tumor.data$end);
    to.remove = vector(length=0);
                                        # find BAF positions and write those to the file
    for (j in 1:nrow(BAF.tumor)) {
      chr = as.character(BAF.tumor$chrs[j]);
      loc = as.numeric(BAF.tumor$pos[j]);
      index = which(chrom.list==chr & (start.list<=loc & end.list>=loc));
      if (length(index)==1) {
        new.row = rbind(c(chr, loc, as.numeric(tumor.data[index,5])));
        names(new.row) = c("chrs", "pos", tumor[i]);
        output.tumor = rbind(output.tumor, data.frame(new.row,
                                                        stringsAsFactors=F));
      }
      else {
        # remove that row from the BAF files
        to.remove = c(to.remove, j);
    }
  }
      cat("done", BAF.tumor.files[i], "\n")
    colnames(output.tumor) = c("chrs", "pos", tumor[i]);
    if (length(to.remove) > 0)  BAF.tumor = BAF.tumor[-to.remove,];
    # remove any of the rows that contain values that are not between 2 and -2
    to.keep = which(abs(as.numeric(output.tumor[,3])) < 2);
    output.tumor = output.tumor[to.keep,];
    BAF.tumor = BAF.tumor[to.keep,];

    rownames <- paste0("SNV", 1:nrow(output.tumor));
    rownames(output.tumor) <- rownames;
    rownames(BAF.tumor) <- rownames;
    colnames(BAF.tumor) <- colnames(output.tumor);

    out.name.tumor = paste0(tumor[i], "_tumor_LogR.txt");
    write.table(output.tumor, file=out.name.tumor, sep = "\t", row.names=T,
                col.names=T, quote=F);
    BAF.name.tumor = paste0(tumor[i], "_tumor_BAF.txt");
    write.table(BAF.tumor, file=BAF.name.tumor, sep = "\t", row.names=T,
                col.names=T, quote=F);
  }
}
generate.BAF.ASCAT.files = function(file, normal, tumor) {
  load(file);
  normal.depth = paste0(normal, ".Depth");
  normal.VAF = paste0(normal, ".VAF");
  tumor.depth = paste0(tumor, ".Depth");
  tumor.VAF = paste0(tumor, ".VAF");
  all.x <- result
  for (i in 1:length(tumor)) {
    # remove any entries for which the read counts were less than 10
    # this removes approximately 10% of the data with the lowest
    # read values (filter based on normal and tumor data)
      to.keep = which(all.x[,normal.depth]>9);
    all.x = all.x[to.keep,];
    to.keep = which(all.x[,tumor.depth[i]]>9);
    all.x = all.x[to.keep,];

    pos=strsplit(all.x[,"Pos"], ':');
    chr.name=sapply(pos, "[", 1); loc=sapply(pos, "[", 2);
    loc = as.numeric(loc);
    chr.name = substr(chr.name, 4, nchar(chr.name))

    # output germline
    # germline needs to have as many rows as tumor data
    output.normal = data.frame(chr.name, loc, all.x[,normal.VAF],
                               stringsAsFactors=F);
    colnames(output.normal) = c("chrs", "pos", tumor[i]);
    output.normal$chrs <- factor(output.normal$chrs, levels=c(1:22, "X"))
    output.normal <- output.normal[order(output.normal$chrs, output.normal$pos),]
    out.name.normal = paste0(tumor[i], "_normal_BAF.txt");
    write.table(output.normal, file=out.name.normal, sep = "\t", row.names=T,
                col.names=T, quote=F);

    # tumor data
    output.tumor = data.frame(chr.name, loc, all.x[,tumor.VAF[i]],
                              stringsAsFactors=F);
    colnames(output.tumor) = c("chrs", "pos", tumor[i])
    output.tumor$chrs <- factor(output.tumor$chrs, levels=c(1:22, "X"))
    output.tumor <- output.tumor[order(output.tumor$chrs, output.tumor$pos),]
    out.name.tumor = paste0(tumor[i], "_tumor_BAF.txt");
    write.table(output.tumor, file=out.name.tumor, sep = "\t", row.names=T,
                col.names=T, quote=F);
  }
}

generate.Unmatched.BAF.ASCAT.files = function(file, tumor) {
  load(file);
  tumor.depth = paste0(tumor, ".Depth");
  tumor.VAF = paste0(tumor, ".VAF");
  all.x <- result
  for (i in 1:length(tumor)) {
    # remove any entries for which the read counts were less than 10
    # this removes approximately 10% of the data with the lowest
    # read values (filter based on normal and tumor data)
    to.keep = which(all.x[,tumor.depth[i]]>9);
    all.x = all.x[to.keep,];

    pos=strsplit(all.x[,"Variant"], ':|_');
    chr.name=sapply(pos, "[", 1); loc=sapply(pos, "[", 2);
    loc = as.numeric(loc);
    chr.name = substr(chr.name, 4, nchar(chr.name))
    # tumor data
    output.tumor = data.frame(chr.name, loc, all.x[,tumor.VAF[i]],
                              stringsAsFactors=F);
    colnames(output.tumor) = c("chrs", "pos", tumor[i])
    output.tumor$chrs <- factor(output.tumor$chrs, levels=c(1:22, "X"))
    output.tumor <- output.tumor[order(output.tumor$chrs, output.tumor$pos),]
    out.name.tumor = paste0(tumor[i], "_tumor_BAF.txt");
    write.table(output.tumor, file=out.name.tumor, sep = "\t", row.names=T,
                col.names=T, quote=F);
  }
}

