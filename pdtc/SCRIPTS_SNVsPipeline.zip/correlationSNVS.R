load("/SNPs_Repeats.RData")

SS <- read.table("/SampleSheetExomes.txt", header=TRUE, sep="\t", stringsAsFactors=FALSE)
SS$Include[grep("X$", SS$ID)] <- "YES"

SS <- SS[which(SS$Include=="YES"),]
SS$Name <- NULL
SS <- unique(SS)
ids <- table(SS$Tumour)
ids <- names(which(ids>1))
minReads <- 20
minCoverage <- 500000
all.cors <- list()
all.cors.spearman <- list()


sum(sapply(split(SS, SS$Tumour), function(x) sum(x$Type=="PDTX") * (1 * any(x$Type=="Tumour"))))
sum(sapply(split(SS, SS$Tumour), function(x) {
    tmp <- sum(x$Type=="PDTX")
    ifelse(tmp>1, choose(tmp, 2), 0)
}))
sum(sapply(split(SS, SS$Tumour), function(x) sum(x$Type=="PDTX")>0))
sum(sapply(split(SS, SS$Tumour), function(x) sum(x$Type=="PDTX")))
sum(sapply(split(SS, interaction(SS$PASSAGE, SS$Tumour)), function(x) {
    tmp <- sum(x$Type=="PDTX")
    ifelse(tmp>1, tmp, 0)
}))
sum(sapply(split(SS, SS$Tumour), function(x) sum(x$Type=="Tumour")>1))

length(unique(SS$Tumour[which(SS$Type=="Tumour")]))

removed <- c()
pdf("/SNVsVAFConcordance.pdf", width=10, height=10)
par(oma=c(4, 2, 2, 4))
for (i in ids) {
    if (file.exists(paste("/SNVs/", i, "_SNVs_MissingIncluded.RData", sep=""))) {
        load(paste("/SNVs/", i, "_SNVs_MissingIncluded.RData", sep=""))
        tmp <- all.x
        load(paste("/VSNVs/", i, "_indels_MissingIncluded.RData", sep=""))
    } else {
        load(paste("/SNVs/", i, "_SNVs.RData", sep=""))
        tmp <- all.x
        load(paste("/SNVs/", i, "_indels.RData", sep=""))
    }
    common.cols <- intersect(colnames(tmp), colnames(all.x))
    all.x <- rbind(all.x[,common.cols], tmp[common.cols])
    Depth <- colnames(all.x)[grep("Depth", colnames(all.x))]
    Tot.Depth <- apply(all.x[,Depth], 2, sum, na.rm=TRUE)
    rem <- which(Tot.Depth < minCoverage)
    removed <- c(removed, names(rem))
    rem <- sub("Depth", "", names(rem), fixed=TRUE)
    if (length(rem)>0) {
        for (k in rem) {
            all.x <- all.x[,-grep(k, colnames(all.x), fixed=TRUE)]
        }
    }
    Depth <- colnames(all.x)[grep("Depth", colnames(all.x))]
    for (k in Depth) {
       all.x[which(all.x[,k] < minReads),sub("Depth", "VAF", k, fixed=TRUE)] <- NA
    }
    all.x <- all.x[which(!all.x$GenomicPos %in% c("intergenic", "intronic", "ncRNA_intronic")),]
    all.x$Somatic <- "YES"
    all.x$Somatic[which(all.x$Variant %in% SNPs)] <- "NO"
    all.x$Somatic[which(all.x$GERMLINE.1000G != "NO")] <- "NO"
    all.x <- all.x[which(all.x$Somatic=="YES"),]
    suspect <- which(all.x$Variant %in% Dups)
    if (length(suspect)>0) all.x <- all.x[-suspect,]
    repeated <- which(all.x$Variant %in% Repeats)
    if (length(repeated)>0) all.x <- all.x[-repeated,]
    feo <- all.x[,grep("Genotype", colnames(all.x)),drop=F]
    bad.ids <- grep("-N", colnames(feo))
    if (length(bad.ids)>0) feo <- feo[,-bad.ids,drop=F]
    if (ncol(feo)>1) {
        tmp <- all.x[,grep("VAF", colnames(all.x))]
        bad.ids <- grep("-N", colnames(tmp))
        if (length(bad.ids)>0) tmp <- tmp[,-bad.ids,drop=F]
        bad.ids <- apply(tmp, 2, function(x) mean(is.na(x)))
        tmp <- tmp[,which(bad.ids<1),drop=F]
        colnames(tmp) <- sub(".VAF", "", colnames(tmp), fixed=TRUE)
        sub.SS <- SS[which(SS$Tumour == i),]
        sub.SS$PASSAGE[which(sub.SS$Type=="Tumour")] <- -1
        sub.SS <- sub.SS[order(sub.SS$PASSAGE, sub.SS$ID),]
        sub.SS <- sub.SS[which(sub.SS$ID %in% colnames(tmp)),]
        tmp <- tmp[,match(sub.SS$ID, colnames(tmp)),drop=F]
        tum.id <- grep("-T", colnames(tmp))
        if (length(tum.id>0)) tmp <- tmp[,c(tum.id, I(1:ncol(tmp))[-tum.id]),drop=F]
        if (ncol(tmp)>1) pairs(tmp, pch=19, xlim=c(0,1), ylim=c(0,1))
        all.cors[[i]] <- cor(tmp, use="pairwise.complete")
        all.cors.spearman[[i]] <- cor(tmp, method="spearman", use="pairwise.complete")
    }
}
    dev.off()

removed <- sub(".Depth", "", removed, fixed=TRUE)
rem.SS <- SS[which(!SS$ID %in% removed),]

sum(sapply(split(rem.SS, rem.SS$Tumour), function(x) sum(x$Type=="PDTX") * (1 * any(x$Type=="Tumour"))))
sum(sapply(split(rem.SS, rem.SS$Tumour), function(x) {
    tmp <- sum(x$Type=="PDTX")
    ifelse(tmp>1, choose(tmp, 2), 0)
}))


sum(sapply(split(rem.SS, rem.SS$Tumour), function(x) sum(x$Type=="PDTX")>0))
sum(sapply(split(rem.SS, rem.SS$Tumour), function(x) sum(x$Type=="PDTX")))
sum(sapply(split(rem.SS, interaction(rem.SS$PASSAGE, rem.SS$Tumour)), function(x) {
    tmp <- sum(x$Type=="PDTX")
    ifelse(tmp>1, tmp, 0)
}))
sum(sapply(split(rem.SS, rem.SS$Tumour), function(x) sum(x$Type=="Tumour")>1))

length(unique(rem.SS$Tumour[which(rem.SS$Type=="Tumour")]))


## Now we correct for normal contamination

SS <- read.table("/SampleSheetExomes_V3.txt", header=TRUE, sep="\t", stringsAsFactors=FALSE)
SS <- SS[which(SS$Include=="YES"),]
SS$Name <- NULL
SS <- unique(SS)
ids <- table(SS$Tumour)
## all.variants <- c()
ids <- names(which(ids>1))
## all.Depth <- c()
## all.Calls <- c()
## all.SNVs <- c()
minReads <- 20
minCoverage <- 500000
## Check cellularity
load("/NormalContamination.RData")
all.est <- data.frame(ID=names(all.est), Contamination=all.est)
all.est <- merge(all.est, SS)
all.cors.cont <- list()
all.cors.spearman.cont <- list()
pdf("/SNVsVAFConcordance_ContaminationCorrected.pdf", width=10, height=10)
par(oma=c(4, 2, 2, 4))
for (i in ids) {
    if (file.exists(paste("/SNVs/", i, "_SNVs_MissingIncluded.RData", sep=""))) {
        load(paste("/SNVs/", i, "_SNVs_MissingIncluded.RData", sep=""))
        tmp <- all.x
        load(paste("/SNVs/", i, "_indels_MissingIncluded.RData", sep=""))
    } else {
        load(paste("/SNVs/", i, "_SNVs.RData", sep=""))
        tmp <- all.x
        load(paste("/SNVs/", i, "_indels.RData", sep=""))
    }
    common.cols <- intersect(colnames(tmp), colnames(all.x))
    all.x <- rbind(all.x[,common.cols], tmp[common.cols])
    Depth <- colnames(all.x)[grep("Depth", colnames(all.x))]
    Tot.Depth <- apply(all.x[,Depth], 2, sum, na.rm=TRUE)
    rem <- which(Tot.Depth < minCoverage)
    rem <- sub("Depth", "", names(rem), fixed=TRUE)
    if (length(rem)>0) {
        for (k in rem) {
            all.x <- all.x[,-grep(k, colnames(all.x), fixed=TRUE)]
        }
    }
    Depth <- colnames(all.x)[grep("Depth", colnames(all.x))]
    for (k in Depth) {
       all.x[which(all.x[,k] < minReads),sub("Depth", "VAF", k, fixed=TRUE)] <- NA
    }
    all.x <- all.x[which(!all.x$GenomicPos %in% c("intergenic", "intronic", "ncRNA_intronic")),]
    all.x$Somatic <- "YES"
    all.x$Somatic[which(all.x$Variant %in% SNPs)] <- "NO"
    all.x$Somatic[which(all.x$GERMLINE.1000G != "NO")] <- "NO"
    all.x <- all.x[which(all.x$Somatic=="YES"),]
    suspect <- which(all.x$Variant %in% Dups)
    if (length(suspect)>0) all.x <- all.x[-suspect,]
    repeated <- which(all.x$Variant %in% Repeats)
    if (length(repeated)>0) all.x <- all.x[-repeated,]
    feo <- all.x[,grep("Genotype", colnames(all.x)),drop=F]
    bad.ids <- grep("-N", colnames(feo))
    if (length(bad.ids)>0) feo <- feo[,-bad.ids,drop=F]
    if (ncol(feo)>1) {
        tmp <- all.x[,grep("VAF", colnames(all.x))]
        colnames(tmp) <- sub(".VAF", "", colnames(tmp), fixed=TRUE)
        ids2correct <-  which(colnames(tmp) %in% all.est$ID)
        for (id in ids2correct) {
            tmp[,id] <- tmp[,id] / all.est$Contamination[which(all.est$ID==colnames(tmp)[id])]
            tmp[which(tmp[,id]>1),id] <- 1
        }
        bad.ids <- grep("-N", colnames(tmp))
        if (length(bad.ids)>0) {
            tmp <- tmp[,-bad.ids,drop=FALSE]
        }

        bad.ids <- apply(tmp, 2, function(x) mean(is.na(x)))
        tmp <- tmp[,which(bad.ids<1),drop=FALSE]
        sub.SS <- SS[which(SS$Tumour == i),]
        sub.SS$PASSAGE[which(sub.SS$Type=="Tumour")] <- -1
        sub.SS <- sub.SS[order(sub.SS$PASSAGE, sub.SS$ID),]
        sub.SS <- sub.SS[which(sub.SS$ID %in% colnames(tmp)),]
        tmp <- tmp[,match(sub.SS$ID, colnames(tmp)),drop=F]
        tum.id <- grep("-T", colnames(tmp))
        if (length(tum.id>0)) tmp <- tmp[,c(tum.id, I(1:ncol(tmp))[-tum.id]),drop=FALSE]
        if (ncol(tmp)>1) pairs(tmp, pch=19, xlim=c(0,1), ylim=c(0,1))
        all.cors.cont[[i]] <- cor(tmp, use="pairwise.complete")
        all.cors.spearman.cont[[i]] <- cor(tmp, method="spearman", use="pairwise.complete")
}
cat(i, " done\n")
}
    dev.off()


## Tumour to Tumour correlation
all.baf <- NULL
i <- "AB551"
load(paste("/SNVs/", i, "_SNVs_MissingIncluded.RData", sep=""))
tmp <- all.x
load(paste("/SNVs/", i, "_indels_MissingIncluded.RData", sep=""))
common.cols <- intersect(colnames(tmp), colnames(all.x))
all.x <- rbind(all.x[,common.cols], tmp[common.cols])

id <- grep("-T", colnames(all.x))
tmp <- all.x[,c(1, 5, id)]
Depth <- colnames(tmp)[grep("Depth", colnames(tmp))]
Tot.Depth <- apply(tmp[,Depth], 2, sum, na.rm=TRUE)
rem <- which(Tot.Depth < minCoverage)
rem <- sub("Depth", "", names(rem), fixed=TRUE)
if (length(rem)>0) {
    for (k in rem) {
        all.x <- all.x[,-grep(k, colnames(all.x), fixed=TRUE)]
    }
}
Depth <- colnames(tmp)[grep("Depth", colnames(tmp))]
for (k in Depth) {
    tmp[which(tmp[,k] < minReads),sub("Depth", "VAF", k, fixed=TRUE)] <- NA
}
tmp <- tmp[which(!tmp$GenomicPos %in% c("intergenic", "intronic", "ncRNA_intronic")),]
tmp$Somatic <- "YES"
tmp$Somatic[which(tmp$Variant %in% SNPs)] <- "NO"
tmp$Somatic[which(tmp$GERMLINE.1000G != "NO")] <- "NO"
tmp <- tmp[which(tmp$Somatic=="YES"),]
suspect <- which(tmp$Variant %in% Dups)
if (length(suspect)>0) tmp <- tmp[-suspect,]
repeated <- which(tmp$Variant %in% Repeats)
if (length(repeated)>0) tmp <- tmp[-repeated,]

tmp <- tmp[,c(1, grep("VAF", colnames(tmp)))]
all.baf <- tmp

for (i in ids[-which(ids=="AB551")]) {
    if (file.exists(paste("/SNVs/", i, "_SNVs_MissingIncluded.RData", sep=""))) {
        load(paste("/SNVs/", i, "_SNVs_MissingIncluded.RData", sep=""))
        tmp <- all.x
        load(paste("/SNVs/", i, "_indels_MissingIncluded.RData", sep=""))
    } else {
        load(paste("/SNVs/", i, "_SNVs.RData", sep=""))
        tmp <- all.x
        load(paste("/SNVs/", i, "_indels.RData", sep=""))
    }
    common.cols <- intersect(colnames(tmp), colnames(all.x))
    all.x <- rbind(all.x[,common.cols], tmp[common.cols])
    id <- grep("-T", colnames(all.x))
    if (length(grep("X0", colnames(all.x)[id]))>0) {
        id <- id[-grep("X0", colnames(all.x)[id])]
    }
    if (length(id) > 0) {
    tmp <- all.x[,c(1, 5, id)]
    Depth <- colnames(tmp)[grep("Depth", colnames(tmp))]
    Tot.Depth <- apply(tmp[,Depth,drop=F], 2, sum, na.rm=TRUE)
    rem <- which(Tot.Depth < minCoverage)
    rem <- sub("Depth", "", names(rem), fixed=TRUE)
    if (length(rem)>0) {
        for (k in rem) {
            all.x <- all.x[,-grep(k, colnames(all.x), fixed=TRUE)]
        }
    }
    Depth <- colnames(tmp)[grep("Depth", colnames(tmp))]
    for (k in Depth) {
        tmp[which(tmp[,k] < minReads),sub("Depth", "VAF", k, fixed=TRUE)] <- NA
    }
    tmp <- tmp[which(!tmp$GenomicPos %in% c("intergenic", "intronic", "ncRNA_intronic")),]
    tmp$Somatic <- "YES"
    tmp$Somatic[which(tmp$Variant %in% SNPs)] <- "NO"
    tmp$Somatic[which(tmp$GERMLINE.1000G != "NO")] <- "NO"
    tmp <- tmp[which(tmp$Somatic=="YES"),]
    suspect <- which(tmp$Variant %in% Dups)
    if (length(suspect)>0) tmp <- tmp[-suspect,]
    repeated <- which(tmp$Variant %in% Repeats)
    if (length(repeated)>0) tmp <- tmp[-repeated,]
    tmp <- tmp[,c(1, grep("VAF", colnames(tmp)))]
    all.baf <- merge(all.baf, tmp, all=TRUE)
}
cat(i, " done\n")
}

for (i in 2:ncol(all.baf)) {
    ids <- which(all.est$ID==sub(".VAF", "", colnames(all.baf)[i], fixed=TRUE))
    all.baf[,i] <- all.baf[,i] / all.est$Contamination[ids]
}

## NAs should be 0
for (i in 2:ncol(all.baf)) {
    all.baf[which(is.na(all.baf[,i])),i] <- 0
}

if (any(colnames(all.baf)=="VHIO179-T.VAF")) {
    all.baf <- all.baf[,which(colnames(all.baf)!="VHIO179-T.VAF")]
}

tum.tum <- cor(all.baf[,-1], use="pairwise.complete.obs")
tum.tum.spearman <- cor(all.baf[,-1], method="spearman", use="pairwise.complete.obs")
rownames(tum.tum) <- sub(".VAF", "", rownames(tum.tum), fixed=TRUE)
colnames(tum.tum) <- sub(".VAF", "", colnames(tum.tum), fixed=TRUE)
rownames(tum.tum.spearman) <- sub(".VAF", "",
                                  rownames(tum.tum.spearman), fixed=TRUE)
colnames(tum.tum.spearman) <- sub(".VAF", "",
                                  colnames(tum.tum.spearman), fixed=TRUE)

N <- matrix(0, nrow(tum.tum), ncol(tum.tum))
for (i in 1:nrow(tum.tum)) {
    for (j in 1:ncol(tum.tum)) {
        N[i,j] <- length(which(!is.na(all.baf[,paste(rownames(tum.tum)[i], "VAF", sep=".")]) &
                            !is.na(all.baf[,paste(colnames(tum.tum)[j], "VAF", sep=".")])))
    }
}
tum.tum[which(N<20)] <- NA
tum.tum.spearman[which(N<20)] <- NA

## Remove the ones with low coverage
tmp <- sapply(all.cors, rownames)
accepted <- c()
for (i in 1:length(tmp)) {
    if (mean(is.na(tmp[[i]]))==0) {
        accepted <- c(accepted, tmp[[i]])
    }
}
ids <- which(sub(".VAF", "", rownames(tum.tum), fixed=TRUE) %in% accepted)
tum.tum <- tum.tum[ids,ids]
rownames(tum.tum) <- sub(".VAF", "", rownames(tum.tum), fixed=TRUE)
colnames(tum.tum) <- sub(".VAF", "", colnames(tum.tum), fixed=TRUE)
tum.tum.spearman <- tum.tum.spearman[ids,ids]
rownames(tum.tum.spearman) <- rownames(tum.tum)
colnames(tum.tum.spearman) <- colnames(tum.tum)

tum.tum <- tum.tum[which(rownames(tum.tum) %in% SS$ID), which(colnames(tum.tum) %in% SS$ID)]
tum.tum.spearman <- tum.tum.spearman[which(rownames(tum.tum.spearman) %in% SS$ID),
                                     which(colnames(tum.tum.spearman) %in% SS$ID)]

## Get correlation plot

for (i in 1:length(all.cors.cont)) {
    ids.row <- grep("X$", rownames(all.cors.cont[[i]]))
    if (length(ids.row)>0) {
                all.cors.cont[[i]] <- all.cors.cont[[i]][-ids.row,-ids.row]
    }
}

for (i in 1:length(all.cors)) {
    ids.row <- grep("X$", rownames(all.cors[[i]]))
    if (length(ids.row)>0) {
                all.cors[[i]] <- all.cors[[i]][-ids.row,-ids.row]
    }
}
all.cors <- all.cors.cont
all.cors.spearman <- all.cors.spearman.cont
pdf(paste("/Correlation_SNVs.pdf", sep=""), width=12, height=9)


all.cor.rep.pdx <- c()
all.cor.pass.pdx <- c()
all.cor.tum.pdx <- c()
all.cor.tum.tum <- c()
all.cor.tumour.tech <- c()
all.cor.pdtc.pdx <- c()

for (i in 1:length(all.cors)) {
    tmp <- SS[which(SS$Tumour==names(all.cors)[i]),,drop=FALSE]
    tmp <- tmp[which(tmp$ID %in% rownames(all.cors[[i]])),]
    ## Tumour (Technical replicate)
    ids <- grep("TR", tmp$ID)
    if (names(all.cors)[i] != "AB582") {
    for (j in ids) {
        found <- which(tmp$Type=="Tumour")
        res <- all.cors[[i]][j,found]
        res <- res[which(res<1)]
        all.cor.tumour.tech <- c(all.cor.tumour.tech, res)
    }
    }
    ## Replicate PDXs
    PDX <- which(tmp$Type=="PDTX")
    res <- c()
    for (j in PDX) {
        ids <- which(tmp$Type=="PDTX" & tmp$PASSAGE==tmp$PASSAGE[j])
        ids <- ids[-which(ids==j)]
        if (length(ids) > 0) {
            res <- c(res, all.cors[[i]][j,ids])
        }
    }
    res <- unique(res)
    all.cor.rep.pdx <- c(all.cor.rep.pdx, res)
    ## Different PDXs passages
    res <- c()
    for (j in PDX) {
        ids <- which(tmp$Type == "PDTX" & tmp$PASSAGE!=tmp$PASSAGE[j])
        if (length(ids) > 1) {
            res <- c(res, all.cors[[i]][j,ids])
        }
    }
    res <- unique(res)
    all.cor.pass.pdx <- c(all.cor.pass.pdx, res)

    ## Tumours vs PDXs
    Tum <- which(tmp$Type=="Tumour")
    if (length(Tum)>0 & length(PDX)>0) {
        for (j in Tum) {
            all.cor.tum.pdx <- c(all.cor.tum.pdx, all.cors[[i]][j,PDX])
        }
    }
    ## Tumours vs Tumours
    Tum <- which(tmp$Type=="Tumour")
    if (length(Tum)>0) {
        sub.tum.tum <- tum.tum[,which(!colnames(tum.tum) %in% tmp$ID)]
        for (j in Tum) {
            all.cor.tum.tum <- c(all.cor.tum.tum, sub.tum.tum[tmp$ID[j],])
        }
    }
    ## PDTCs
    ids <- which(tmp$Type=="PDTC")
    res <- c()
    for (j in ids) {
        found <- which(tmp$Type == "PDTX" & tmp$PASSAGE==tmp$PASSAGE[j])
        if (length(found) > 0) {
            res <- c(res, all.cors[[i]][j,found])
        }
    }
    res <- unique(res)
    all.cor.pdtc.pdx <- c(all.cor.pdtc.pdx, res)

    }
boxplot(all.cor.tumour.tech, all.cor.pdtc.pdx,
all.cor.rep.pdx, all.cor.pass.pdx, all.cor.tum.pdx, all.cor.tum.tum,
        names=c("Tech. Replicates", "PDTCs vs PDXs", "Mice Replicates",
            "PDTXs Passages", "PDTX vs Tumour", "Different Tumours"), ylab="Pearson Correlation",
                col=c("grey", "red", "yellow", "olivedrab", "orange", "darkblue"), cex.lab=1.2, cex.axis=1.2)

round(summary(all.cor.tum.pdx), 2)
round(summary(all.cor.pass.pdx), 2)
round(summary(all.cor.pdtc.pdx), 2)

## Get correlation plot
all.cor.rep.pdx <- c()
all.cor.pass.pdx <- c()
all.cor.tum.pdx <- c()
all.cor.tum.tum <- c()
all.cor.tumour.tech <- c()
all.cor.pdtc.pdx <- c()

for (i in 1:length(all.cors)) {
    tmp <- SS[which(SS$Tumour==names(all.cors.spearman)[i]),,drop=FALSE]
    tmp <- tmp[which(tmp$ID %in% rownames(all.cors.spearman[[i]])),]
    ## Tumour (Technical replicate)
    ids <- grep("TR", tmp$ID)
    if (names(all.cors)[i] != "AB582") {
    for (j in ids) {
        found <- which(tmp$Type=="Tumour")
        res <- all.cors.spearman[[i]][j,found]
        res <- res[which(res<1)]
        all.cor.tumour.tech <- c(all.cor.tumour.tech, res)
    }
    }
    ## Replicate PDXs
    PDX <- which(tmp$Type=="PDTX")
    res <- c()
    for (j in PDX) {
        ids <- which(tmp$Type=="PDTX" & tmp$PASSAGE==tmp$PASSAGE[j])
        ids <- ids[-which(ids==j)]
        if (length(ids) > 0) {
            res <- c(res, all.cors.spearman[[i]][j,ids])
        }
    }
    res <- unique(res)
    all.cor.rep.pdx <- c(all.cor.rep.pdx, res)
    ## Different PDXs passages
    res <- c()
    for (j in PDX) {
        ids <- which(tmp$Type == "PDTX" & tmp$PASSAGE!=tmp$PASSAGE[j])
        if (length(ids) > 1) {
            res <- c(res, all.cors.spearman[[i]][j,ids])
        }
    }
    res <- unique(res)
    all.cor.pass.pdx <- c(all.cor.pass.pdx, res)

    ## Tumours vs PDXs
    Tum <- which(tmp$Type=="Tumour")
    if (length(Tum)>0 & length(PDX)>0) {
        for (j in Tum) {
            all.cor.tum.pdx <- c(all.cor.tum.pdx, all.cors.spearman[[i]][j,PDX])
        }
    }
    ## Tumours vs Tumours
    Tum <- which(tmp$Type=="Tumour")
    if (length(Tum)>0) {
        sub.tum.tum <- tum.tum.spearman[,which(!colnames(tum.tum.spearman) %in% tmp$ID)]
        for (j in Tum) {
            all.cor.tum.tum <- c(all.cor.tum.tum, sub.tum.tum[tmp$ID[j],])
        }
    }
    ## PDTCs
    res <- c()
    ids <- which(tmp$Type=="PDTC")
    for (j in ids) {
        found <- which(tmp$Type == "PDTX" & tmp$PASSAGE==tmp$PASSAGE[j])
        if (length(found) > 0) {
            res <- c(res, all.cors.spearman[[i]][j,found])
        }
    }
    res <- unique(res)
    all.cor.pdtc.pdx <- c(all.cor.pdtc.pdx, res)

}

boxplot(all.cor.tumour.tech, all.cor.pdtc.pdx,
all.cor.rep.pdx, all.cor.pass.pdx, all.cor.tum.pdx, all.cor.tum.tum,
        names=c("Tech. Replicates", "PDTCs vs PDXs", "Mice Replicates",
            "PDTXs Passages", "PDTX vs Tumour", "Different Tumours"), ylab="Spearman Correlation",
                col=c("grey", "red", "yellow", "olivedrab", "orange", "darkblue"), cex.lab=1.2, cex.axis=1.2)


dev.off()

