load("/SNPs_Repeats.RData")
load(file="/FilteredIndels_ALLSAMPLES.RData")
indels$ID <- sub("_ordered_picard", "", indels$ID)
load(file="/FilteredSNVs_ALLSAMPLES.RData")
SNVs$ID <- sub("_ordered_picard", "", SNVs$ID)
Variants <- rbind(SNVs, indels)
rm(SNVs, indels)
gc()
gc()
Variants$Variant <- sapply(strsplit(rownames(Variants), ";"),
                           function(x) x[2])

minReads <- 20
minCoverage <- 50

Variants <- Variants[which(I(Variants$Ref + Variants$Alt) >= minReads),]
Variants <- Variants[-which(Variants$Variant %in% SNPs),]
Variants <- Variants[-which(Variants$Variant %in% Repeats),]
Variants <- Variants[-which(Variants$Variant %in% Dups),]
Variants <- Variants[which(Variants$Genotype == "0/1"),]

Variants$VAF <- Variants$Alt / (Variants$Ref+Variants$Alt)
Variants <- Variants[which(Variants$VAF < 1),]


SS <- read.table("/SampleSheetExomes.txt", header=TRUE, sep="\t", stringsAsFactors=FALSE)

SS <- SS[which(SS$Include=="YES"),]
SS$Name <- gsub(" ", "_", SS$Name, fixed=T)
SS$Name <- gsub("/", "_", SS$Name, fixed=T)
SS$Name <- gsub("(", "_", SS$Name, fixed=T)
SS$Name <- gsub(")", "_", SS$Name, fixed=T)
SS <- unique(SS)
ids <- unique(SS$Tumour)

load("/NormalContamination.RData")
all.est <- data.frame(ID=names(all.est), Contamination=all.est)
all.est <- merge(all.est, SS)

SS <- SS[which(SS$Type!="Normal"),]


for (i in unique(Variants$ID)) {
    if (!(i %in% SS$ID)) {
        ids <- which(SS$Name==i)
        if (length(ids)>0) {
            Variants$ID[which(Variants$ID==i)] <- SS$ID[ids]
        }
    }
}

MATH <- NULL
for (i in SS$ID) {
    ids <- which(Variants$ID==i)
    x <- Variants[ids,]
    Coverage <- nrow(x)
    if (i %in% all.est$ID) {
        x$VAF <- x$VAF / all.est$Contamination[which(all.est$ID==i)]
    }
    if (Coverage >= minCoverage) {
        math <- mad(x$VAF)/median(x$VAF)
        tmp <- data.frame(ID=i, math=math)
        MATH <- rbind(MATH, tmp)
    }
}
MATH <- merge(MATH, SS, all.x=T)

par(mfrow=c(4, 2))
for (i in SS$ID[which(SS$Tumour=="HCI002")]) {
    ids <- which(Variants$ID==i)
    x <- Variants[ids,]
    Coverage <- nrow(x)
    if (Coverage >= minCoverage) {
        plot(density(x$VAF), main=i)
    }
}


ER <- read.table(file="/ModelsClassifiers.txt", header=TRUE, sep="\t", stringsAsFactors=F)
MATH <- merge(MATH, ER, all.x=TRUE)
mutations.PDX <- read.table(file="/SNVsSummary_SDFilteredV3.txt", sep="\t", header=T)
mutations.PDX <- mutations.PDX[which(mutations.PDX$Symbol=="TP53"),-1]
TP53 <- 1 * (mutations.PDX!="NO")
TP53 <- data.frame(Tumour=colnames(TP53), TP53=as.vector(TP53))
MATH <- merge(MATH, TP53, all.x=T)

ids <- order(tapply(MATH$math, MATH$Tumour, median))
MATH$Tumour <- factor(MATH$Tumour,
                             levels=unique(MATH$Tumour)[ids])
ids <- which(MATH$Type == "Tumour")
means.tum <- tapply(MATH$math[ids], MATH$Tumour[ids], mean)

MATH$ER.status[which(MATH$Tumour=="HCI003")] <- "+"
MATH$ER.status[which(MATH$Tumour=="HCI007")] <- "+"


pdf("/MATHPlot.pdf", width=12, height=9)
layout(rbind(1,2), height=c(0.8, 0.2))
par(mar=c(5, 5, 2, 3))
boxplot(math ~ Tumour, data=MATH, las=2,
        ylab="MATH Score", cex.axis=1.6, cex.lab=1.6)
points(MATH$math[which(MATH$Type!="Tumour")] ~ MATH$Tumour[which(MATH$Type!="Tumour")], col=1, pch=19, cex=1)
points(means.tum, col=2, pch="T", cex=2)
ER <- tapply(MATH$ER.status, MATH$Tumour, max)
ER <- factor(ER, levels=c("Neg", "Pos"), labels=c("#FFFF33", "#377EB8"))
coliCluster.plus <- c('#FF5500', '#00EE76', '#CD3278', '#00C5CD',
                       '#B5D0D2',
                      '#8B0000',
                '#FFFF40', '#0000CD', '#FFAA00', '#EE82EE', '#7D26CD')
iC <- tapply(MATH$iC10, MATH$Tumour, max)
iC <- factor(iC, levels=c(1:3, "4ER+", "4ER-", 5:10),
                 labels=coliCluster.plus)
TP53 <- tapply(MATH$TP53, MATH$Tumour, max)
TP53 <- factor(TP53, levels=c(0, 1), labels=c("grey", "black"))
ER <- cbind(as.character(iC), as.character(TP53), as.character(ER))
csc.colors = matrix()
csc.names = names(table(ER))
csc.i = 1
for (csc.name in csc.names) {
  csc.colors[csc.i] = csc.name
  ER[ER == csc.name] = csc.i
  csc.i = csc.i + 1
}
ER = matrix(as.numeric(ER), nrow = dim(ER)[1])
colnames(ER) <- c("iC10", "TP53", "ER")
mar.orig <- par()$mar # save the original values
par(mar = c(2,7,4,5)) # set your new values
image(ER, col=as.vector(csc.colors), axes=FALSE)
axis(2, 0:(dim(ER)[2] - 1)/(dim(ER)[2] - 1), colnames(ER),
       las = 2, tick = FALSE, cex.axis=1.4)
box()
par(mar = mar.orig) # put the original values back
dev.off()
save(MATH, file="/MATHScores.RData")

