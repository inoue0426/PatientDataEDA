load("/FilteredSNVs_ALLSAMPLES.RData")
load("/FilteredIndels_ALLSAMPLES.RData")

SNVs <- rbind(SNVs, indels)
rm(indels)
SNPs <- SNVs[grep("N", SNVs$ID, fixed=TRUE),]
SNPs$Location <- sapply(strsplit(rownames(SNPs), ";"), function(x) x[2])
SNPs <- SNPs$Location
SNPs <- unique(SNPs)
rm(SNVs)
gc()

## Unfortunately, we need more than this
MoreSNPs <- c()

SS <- read.table("/SampleSheetExomes_V3.txt", header=TRUE, sep="\t", stringsAsFactors=FALSE)

SS$Name <- NULL
SS <- unique(SS)
SS <- SS[which(SS$Include=="YES"),]
SS <- SS[which(SS$Type=="Normal"),]
ids <- unique(SS$Tumour)
minReads <- 5
minVAF <- 0.1
for (i in ids) {
    if (file.exists(paste("/SNVs/", i, "_SNVs_MissingIncluded.RData", sep=""))) {
        load(paste("/SNVs/", i, "_SNVs_MissingIncluded.RData", sep=""))
    tmp <- all.x
    load(paste("/SNVs/", i, "_indels_MissingIncluded.RData", sep=""))
    common.cols <- intersect(colnames(tmp), colnames(all.x))
    all.x <- rbind(all.x[,common.cols], tmp[common.cols])
    smp <- SS$ID[which(SS$Tumour==i)]
    for (j in smp) {
        depth <- all.x[,paste(j, ".Depth", sep="")]
        vaf <- all.x[,paste(j, ".VAF", sep="")]
        cands <- which(depth >= minReads & vaf >= minVAF)
        MoreSNPs <- c(MoreSNPs, all.x$Variant[cands])
    }
    }
}
MoreSNPs <- unique(MoreSNPs)
SNPs <- c(SNPs, MoreSNPs)
SNPs <- unique(SNPs)


load(file="/SNVsAnnotated.RData")
load(file="/indelsAnnotated.RData")
SNVs <- SNVs[which(!SNVs$GenomicPos %in% c("intergenic", "intronic", "ncRNA_intronic")),]
indels <- indels[which(!indels$GenomicPos %in% c("intergenic", "intronic", "ncRNA_intronic")),]
SNVs <- SNVs[,c('Location', 'Repetitive')]
indels <- indels[,c('Location', 'Repetitive')]
SNVs <- rbind(SNVs, indels)
Repeats <- SNVs$Location[which(SNVs$Repetitive!="NO")]
Repeats <- as.character(Repeats)

## Dubious Insertions
Alt <- sapply(strsplit(as.character(SNVs$Location), "/"), function(x) x[2])
ids <- which(nchar(Alt) > 3)
Chrom <- sapply(strsplit(as.character(SNVs$Location), "_"), function(x) x[1])
Pos <- sapply(strsplit(Chrom, ":"), function(x) x[2])
Chrom <- sapply(strsplit(Chrom, ":"), function(x) x[1])
Candidates <- data.frame(Chrom[ids], Pos[ids], Alt[ids])
colnames(Candidates) <- c("Chrom", "Pos", "Alt")
Candidates$Pos <- as.character(Candidates$Pos)
Candidates$start <- as.numeric(Candidates$Pos)
Candidates$end <- as.numeric(Candidates$Pos) + nchar(as.character(Candidates$Alt))
Candidates$Error <- "NO"

library(BSgenome.Hsapiens.UCSC.hg19)
for (i in 1:nrow(Candidates)) {
    sequ <- getSeq(BSgenome.Hsapiens.UCSC.hg19, names=Candidates$Chrom[i], start=Candidates$start[i],
           end=Candidates$end[i]-1)
    if (as.character(sequ)==Candidates$Alt[i]) Candidates$Error[i] <- "YES"
    cat(i, " done\n")
}

rownames(Candidates) <- SNVs$Location[ids]
Dups <- rownames(Candidates)[which(Candidates$Error=="YES")]

## There are too many. We need to check replicates

SS <- read.table("/SampleSheetExomes_V3.txt", header=TRUE, sep="\t", stringsAsFactors=FALSE)

SS <- SS[which(SS$Include=="YES"),]
SS$Name <- NULL
SS <- unique(SS)
ids <- table(SS$Tumour)
ids <- names(which(ids>3))
minReads <- 20
minCoverage <- 500000
for (i in ids) {
    load(paste("/SNVs/", i, "_SNVs_MissingIncluded.RData", sep=""))
    tmp <- all.x
    load(paste("/SNVs/", i, "_indels_MissingIncluded.RData", sep=""))
    common.cols <- intersect(colnames(tmp), colnames(all.x))
    all.x <- rbind(all.x[,common.cols], tmp[common.cols])
    Depth <- colnames(all.x)[grep("Depth", colnames(all.x))]
    Tot.Depth <- apply(all.x[,Depth], 2, sum, na.rm=TRUE)
    rem <- which(Tot.Depth < minCoverage)
    rem <- sub("Depth", "", names(rem), fixed=TRUE)
    if (length(rem)>0) {
        for (k in rem) {
            all.x <- all.x[,-grep(k, colnames(all.x), fixed=TRUE)]
        }
    }
    Depth <- colnames(all.x)[grep("Depth", colnames(all.x))]
    for (k in Depth) {
       all.x[which(all.x[,k] < minReads),sub("Depth", "VAF", k, fixed=TRUE)] <- NA
    }
    feo <- all.x[,grep("Genotype", colnames(all.x)),drop=F]
    bad.ids <- grep("-N", colnames(feo))
    if (length(bad.ids)>0) feo <- feo[,-bad.ids,drop=F]
    if (ncol(feo)>=3) {
        tmp <- all.x[,grep("VAF", colnames(all.x))]
        bad.ids <- grep("-N", colnames(tmp))
        if (length(bad.ids)>0) tmp <- tmp[,-bad.ids,drop=F]
        bad.ids <- apply(tmp, 2, function(x) mean(is.na(x)))
        tmp <- tmp[,which(bad.ids<1),drop=F]
        colnames(tmp) <- sub(".VAF", "", colnames(tmp), fixed=TRUE)
        tmp <- tmp[which(all.x$Variant %in% Dups),]
        all.x <- all.x[which(all.x$Variant %in% Dups),]
        avg <- apply(tmp, 1, function(x) mean(x>0, na.rm=T))
        N <- apply(tmp, 1, function(x) sum(x>0, na.rm=T))
        good <- all.x$Variant[which(N >= 3 & avg >= 0.75)]
        if (length(good) > 0) {
            Dups <- Dups[-which(Dups %in% good)]
        }
    }
}
Candidates$Error <- "NO"
Candidates$Error[which(rownames(Candidates) %in% Dups)] <- "YES"

Candidates$Location <- paste(Candidates$Chrom, Candidates$Pos, sep=":")
badids <- which(duplicated(Candidates$Location))
Candidates$Error[badids] <- "YES"
Dups <- rownames(Candidates)[which(Candidates$Error=="YES")]
save(Repeats, SNPs, Dups, file="/SNPs_Repeats.RData")
