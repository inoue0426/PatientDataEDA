load(file="/SNPs_Repeats.RData")

######################################################
######################################################
## First, a gene-wise table for somatic
######################################################
######################################################

SS <- read.table("/SampleSheetExomes_V3.txt", header=TRUE, sep="\t", stringsAsFactors=FALSE)
SS <- SS[which(SS$Include=="YES"),]
SS$Name <- NULL
SS <- unique(SS)
ids <- table(SS$Tumour, SS$Type)
## all.variants <- c()
ids <- rownames(ids)[which(apply(ids, 1, function(x) sum(x[c('PDTC', 'PDTX')]))>0)]
## all.Depth <- c()
## all.Calls <- c()
## all.SNVs <- c()
minReads <- 20
minCoverage <- 500000
## Check cellularity
load("/NormalContamination.RData")
all.est <- data.frame(ID=names(all.est), Contamination=all.est)
all.est <- merge(all.est, SS)
mutations.PDX <- NULL
for (i in ids) {
    if (file.exists(paste("/SNVs/", i, "_SNVs_MissingIncluded.RData", sep=""))) {
        load(paste("/SNVs/", i, "_SNVs_MissingIncluded.RData", sep=""))
        tmp <- all.x
        load(paste("/SNVs/", i, "_indels_MissingIncluded.RData", sep=""))
        all.x$SIFT <- NA
        all.x$POLYPHEN <- NA
        all.x$MT <- NA
        all.x$METALR <- NA
        common.cols <- intersect(colnames(tmp), colnames(all.x))
        all.x <- rbind(all.x[,common.cols], tmp[common.cols])
    } else {
        load(paste("/SNVs/", i, "_SNVs.RData", sep=""))
        tmp <- all.x
        load(paste("/SNVs/", i, "_indels.RData", sep=""))
        all.x$SIFT <- NA
        all.x$POLYPHEN <- NA
        all.x$MT <- NA
        all.x$METALR <- NA
        common.cols <- intersect(colnames(tmp), colnames(all.x))
        all.x <- rbind(all.x[,common.cols], tmp[common.cols])
    }
    ids2do <- SS$ID[which(SS$Tumour==i)]
    Depth <- colnames(all.x)[grep("Depth", colnames(all.x))]
    Tot.Depth <- apply(all.x[,Depth,drop=FALSE], 2, sum, na.rm=TRUE)

    ## Remove low coverage samples and variants

    rem <- which(Tot.Depth < minCoverage)
    rem <- sub("Depth", "", names(rem), fixed=TRUE)
    if (length(rem)>0) {
        for (k in rem) {
            all.x <- all.x[,-grep(k, colnames(all.x), fixed=TRUE),drop=F]
        }
    }
    Depth <- colnames(all.x)[grep("Depth", colnames(all.x))]
    for (k in Depth) {
       all.x[which(all.x[,k] < minReads),sub("Depth", "VAF", k, fixed=TRUE)] <- NA
    }

    ## Now select only those annotated to a single gene
    all.x$Symbol <- as.character(all.x$Symbol)
    bad.ids <- grep("(", all.x$Symbol, fixed=TRUE)
    if (length(bad.ids)>0) all.x <- all.x[-bad.ids,]
    all.x <- all.x[which(all.x$Type != "synonymous SNV"),]
    all.x$Somatic <- "YES"
    all.x$Somatic[which(all.x$Variant %in% SNPs)] <- "NO"
    all.x$Somatic[which(all.x$GERMLINE.1000G != "NO")] <- "NO"
    all.x <- all.x[which(all.x$Somatic=="YES"),]
    suspect <- which(all.x$Variant %in% Dups)
    if (length(suspect)>0) all.x <- all.x[-suspect,]
    repeated <- which(all.x$Variant %in% Repeats)
    if (length(repeated)>0) all.x <- all.x[-repeated,]
    feo <- all.x[,grep("VAF", colnames(all.x)),drop=F]

    normal.ids <- grep("-N", colnames(feo))
    if (length(normal.ids>0)) {
        suspicious <- c()
        for (j in normal.ids) {
            suspicious <- c(suspicious, which(feo[,j]>0.33))
        }
        if (length(suspicious) > 0) {
            all.x <- all.x[-suspicious,]
            feo <- feo[-suspicious,]
        }
    }
    feo.PDX <- feo
    if (length(normal.ids)>0) feo.PDX <- feo[,-normal.ids,drop=FALSE]
    tumour.ids <- grep("-T", colnames(feo.PDX))
    if (length(grep("X0.VAF", colnames(feo.PDX)[tumour.ids]))>0) {
        tumour.ids <- tumour.ids[-grep("X0.VAF", colnames(feo.PDX)[tumour.ids])]
    }
    if (length(tumour.ids)>0) feo.PDX <- feo.PDX[,-tumour.ids, drop=FALSE]
    if (ncol(feo.PDX) > 0) {
        th.detection <- 0.1
        number.VAF <- apply(feo.PDX, 1, function(x) mean(x>th.detection, na.rm=TRUE))
        good.ids <- which(number.VAF > 0.33)
        all.x <- all.x[good.ids,]
        tmp <- data.frame(Symbol=all.x$Symbol,ID=paste(all.x$Variant, "_", all.x$Type, "_", all.x$GERMLINE.DBSNP, "_SIFT=", all.x$SIFT,
                                              "_POLYPHEN=", all.x$POLYPHEN, "_MT=", all.x$MT, "_METALR=", all.x$METALR, sep=""))
        tmp <- aggregate(tmp$ID, by=list(tmp$Symbol), FUN=function(x) paste(x, collapse="//"))
        colnames(tmp) <- c("Symbol", i)
        if (is.null(mutations.PDX)) {
            mutations.PDX <- tmp
        } else {
            mutations.PDX <- merge(mutations.PDX, tmp, all=T)
        }
    }
    cat(i, " done\n")
}
for (i in 1:ncol(mutations.PDX)) {
    mutations.PDX[,i] <- as.character(mutations.PDX[,i])
    mutations.PDX[which(is.na(mutations.PDX[,i])),i] <- "NO"
}

## we need to put back PI3KCA
NotFiltered <- read.table(file="/SNVsSummaryV3.txt",
                          header=TRUE, sep="\t")
for (i in 1:ncol(NotFiltered)) {
    NotFiltered[,i] <- as.character(NotFiltered[,i])
}
mutations.PDX[which(mutations.PDX[,1]=="PIK3CA"),] <-
    NotFiltered[which(NotFiltered[,1]=="PIK3CA"),]
write.table(mutations.PDX, file="/SNVsSummary_SDFilteredV3.txt", row.names=F, quote=F, sep="\t")


######################################################
######################################################
## Now, a gene-wise table for SNPs
######################################################
######################################################

SS <- read.table("/SampleSheetExomes_V3.txt", header=TRUE, sep="\t", stringsAsFactors=FALSE)
SS <- SS[which(SS$Include=="YES"),]
SS$Name <- NULL
SS <- unique(SS)
ids <- table(SS$Tumour, SS$Type)
## all.variants <- c()
ids <- rownames(ids)[which(apply(ids, 1, function(x) sum(x[c('PDTC', 'PDTX')]))>0)]
## all.Depth <- c()
## all.Calls <- c()
## all.SNVs <- c()
minReads <- 20
minCoverage <- 500000
## Check cellularity
load("/NormalContamination.RData")
all.est <- data.frame(ID=names(all.est), Contamination=all.est)
all.est <- merge(all.est, SS)
mutations.PDX <- NULL
for (i in ids) {
    if (file.exists(paste("/SNVs/", i, "_SNVs_MissingIncluded.RData", sep=""))) {
        load(paste("/SNVs/", i, "_SNVs_MissingIncluded.RData", sep=""))
        tmp <- all.x
        load(paste("/SNVs/", i, "_indels_MissingIncluded.RData", sep=""))
        all.x$SIFT <- NA
        all.x$POLYPHEN <- NA
        all.x$MT <- NA
        all.x$METALR <- NA
        common.cols <- intersect(colnames(tmp), colnames(all.x))
        all.x <- rbind(all.x[,common.cols], tmp[common.cols])
    } else {
        load(paste("/SNVs/", i, "_SNVs.RData", sep=""))
        tmp <- all.x
        load(paste("/SNVs/", i, "_indels.RData", sep=""))
        all.x$SIFT <- NA
        all.x$POLYPHEN <- NA
        all.x$MT <- NA
        all.x$METALR <- NA
        common.cols <- intersect(colnames(tmp), colnames(all.x))
        all.x <- rbind(all.x[,common.cols], tmp[common.cols])
    }
    ids2do <- SS$ID[which(SS$Tumour==i)]
    Depth <- colnames(all.x)[grep("Depth", colnames(all.x))]
    Tot.Depth <- apply(all.x[,Depth,drop=FALSE], 2, sum, na.rm=TRUE)

    ## Remove low coverage samples and variants

    rem <- which(Tot.Depth < minCoverage)
    rem <- sub("Depth", "", names(rem), fixed=TRUE)
    if (length(rem)>0) {
        for (k in rem) {
            all.x <- all.x[,-grep(k, colnames(all.x), fixed=TRUE),drop=F]
        }
    }
    Depth <- colnames(all.x)[grep("Depth", colnames(all.x))]
    for (k in Depth) {
       all.x[which(all.x[,k] < minReads),sub("Depth", "VAF", k, fixed=TRUE)] <- NA
    }

    ## Now select only those annotated to a single gene
    all.x$Symbol <- as.character(all.x$Symbol)
    bad.ids <- grep("(", all.x$Symbol, fixed=TRUE)
    if (length(bad.ids)>0) all.x <- all.x[-bad.ids,]
    all.x <- all.x[which(all.x$Type != "synonymous SNV"),]
    all.x$Somatic <- "YES"
    all.x$Somatic[which(all.x$Variant %in% SNPs)] <- "NO"
    all.x$Somatic[which(all.x$GERMLINE.1000G != "NO")] <- "NO"
    all.x <- all.x[which(all.x$Somatic=="NO"),]
    suspect <- which(all.x$Variant %in% Dups)
    if (length(suspect)>0) all.x <- all.x[-suspect,]
    repeated <- which(all.x$Variant %in% Repeats)
    if (length(repeated)>0) all.x <- all.x[-repeated,]

    feo <- all.x[,grep("VAF", colnames(all.x)),drop=F]

    normal.ids <- grep("-N", colnames(feo))
    if (length(normal.ids>0)) {
        suspicious <- c()
        for (j in normal.ids) {
            suspicious <- c(suspicious, which(feo[,j]>0.33))
        }
        if (length(suspicious) > 0) {
            all.x <- all.x[-suspicious,]
            feo <- feo[-suspicious,]
        }
    }
    feo.PDX <- feo
    if (length(normal.ids)>0) feo.PDX <- feo[,-normal.ids,drop=FALSE]
    tumour.ids <- grep("-T", colnames(feo.PDX))
    if (length(grep("X0.VAF", colnames(feo.PDX)[tumour.ids]))>0) {
        tumour.ids <- tumour.ids[-grep("X0.VAF", colnames(feo.PDX)[tumour.ids])]
    }
    if (length(tumour.ids)>0) feo.PDX <- feo.PDX[,-tumour.ids, drop=FALSE]
    if (ncol(feo.PDX) > 0) {
        th.detection <- 0.1
        number.VAF <- apply(feo.PDX, 1, function(x) mean(x>th.detection, na.rm=TRUE))
        good.ids <- which(number.VAF > 0.5)
        all.x <- all.x[good.ids,]
        tmp <- data.frame(Symbol=all.x$Symbol,ID=paste(all.x$Variant, "_", all.x$Type, "_", all.x$GERMLINE.DBSNP, "_SIFT=", all.x$SIFT,
                                              "_POLYPHEN=", all.x$POLYPHEN, "_MT=", all.x$MT, "_METALR=", all.x$METALR, sep=""))
        tmp <- aggregate(tmp$ID, by=list(tmp$Symbol), FUN=function(x) paste(x, collapse="//"))
        colnames(tmp) <- c("Symbol", i)
        if (is.null(mutations.PDX)) {
            mutations.PDX <- tmp
        } else {
            mutations.PDX <- merge(mutations.PDX, tmp, all=T)
        }
    }
    cat(i, " done\n")
}
for (i in 1:ncol(mutations.PDX)) {
    mutations.PDX[,i] <- as.character(mutations.PDX[,i])
    mutations.PDX[which(is.na(mutations.PDX[,i])),i] <- "NO"
}


write.table(mutations.PDX, file="/SNPsSummary_SDFilteredV3.txt", row.names=T, quote=F, sep="\t")

######################################################
######################################################
## Individual files for each model
######################################################
######################################################

SS <- read.table("/SampleSheetExomes.txt", header=TRUE, sep="\t", stringsAsFactors=FALSE)
SS <- SS[which(SS$Include=="YES"),]
SS$Name <- NULL
SS <- unique(SS)
ids <- table(SS$Tumour, SS$Type)
## all.variants <- c()
ids <- rownames(ids)[which(apply(ids, 1, function(x) sum(x[c('PDTC', 'PDTX')]))>0)]
## all.Depth <- c()
## all.Calls <- c()
## all.SNVs <- c()
minReads <- 20
minCoverage <- 500000
## Check cellularity
load("/NormalContamination.RData")
all.est <- data.frame(ID=names(all.est), Contamination=all.est)
all.est <- merge(all.est, SS)
mutations.PDX <- NULL
for (i in ids) {
    if (file.exists(paste("/SNVs/", i, "_SNVs_MissingIncluded.RData", sep=""))) {
        load(paste("/SNVs/", i, "_SNVs_MissingIncluded.RData", sep=""))
        tmp <- all.x
        load(paste("/SNVs/", i, "_indels_MissingIncluded.RData", sep=""))
        all.x$SIFT <- NA
        all.x$POLYPHEN <- NA
        all.x$MT <- NA
        all.x$METALR <- NA
        common.cols <- intersect(colnames(tmp), colnames(all.x))
        all.x <- rbind(all.x[,common.cols], tmp[common.cols])
    } else {
        load(paste("/SNVs/", i, "_SNVs.RData", sep=""))
        tmp <- all.x
        load(paste("/SNVs/", i, "_indels.RData", sep=""))
        all.x$SIFT <- NA
        all.x$POLYPHEN <- NA
        all.x$MT <- NA
        all.x$METALR <- NA
        common.cols <- intersect(colnames(tmp), colnames(all.x))
        all.x <- rbind(all.x[,common.cols], tmp[common.cols])
    }
    ids2do <- SS$ID[which(SS$Tumour==i)]
    Depth <- colnames(all.x)[grep("Depth", colnames(all.x))]
    Tot.Depth <- apply(all.x[,Depth,drop=FALSE], 2, sum, na.rm=TRUE)

    ## Remove low coverage samples and variants

    rem <- which(Tot.Depth < minCoverage)
    rem <- sub("Depth", "", names(rem), fixed=TRUE)
    if (length(rem)>0) {
        for (k in rem) {
            all.x <- all.x[,-grep(k, colnames(all.x), fixed=TRUE),drop=F]
        }
    }
    Depth <- colnames(all.x)[grep("Depth", colnames(all.x))]
    for (k in Depth) {
       all.x[which(all.x[,k] < minReads),sub("Depth", "VAF", k, fixed=TRUE)] <- NA
    }

    ids2correct <-  which(colnames(all.x) %in% paste(all.est$ID, "VAF", sep="."))
        for (id in ids2correct) {
            all.x[,id] <- all.x[,id] / all.est$Contamination[which(all.est$ID==sub(".VAF", "", colnames(all.x)[id], fixed=TRUE))]
            all.x[which(all.x[,id]>1),id] <- 1
        }

    ## Now select only those annotated to a single gene
    all.x$Symbol <- as.character(all.x$Symbol)
    all.x$Somatic <- "YES"
    all.x$Somatic[which(all.x$Variant %in% SNPs)] <- "NO"
    all.x$Somatic[which(all.x$GERMLINE.1000G != "NO")] <- "NO"
    suspect <- which(all.x$Variant %in% Dups)
    if (length(suspect)>0) all.x <- all.x[-suspect,]
    repeated <- which(all.x$Variant %in% Repeats)
    if (length(repeated)>0) all.x <- all.x[-repeated,]
    all.x$Pos <- sapply(strsplit(all.x$Variant, "_"), function(x) x[1])
    all.x$Chrom <- sapply(strsplit(all.x$Pos, ":"), function(x) x[1])
    all.x$Pos <- sapply(strsplit(all.x$Pos, ":"), function(x) x[2])
    all.x$Chrom <- factor(all.x$Chrom, levels=paste("chr", c(1:22, "X"), sep=""))
    all.x$Pos <- as.numeric(all.x$Pos)
    all.x <- all.x[order(all.x$Chrom, all.x$Pos),]
    all.x$Pos <- NULL
    all.x$Pos2 <- NULL
    all.x$Chrom <- NULL
    write.table(all.x, file=paste("/SNVs", i, "_SDFiltered.txt", sep=""), row.names=T, quote=F, sep="\t")
    cat(i, " done\n")
}


mutations.PDX <- read.table(file="/SNVsSummary_SDFilteredV3.txt", sep="\t", header=T)

