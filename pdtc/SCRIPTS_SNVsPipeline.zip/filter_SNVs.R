library(VariantAnnotation)
setwd("/Merged/DupMarked/")
allF <- dir(pattern=".bam$")
i <- as.numeric(Sys.getenv("LSB_JOBINDEX"))
i <- allF[i]
i <- paste(i, "vcf", sep=".")
setwd("/Merged/VCF/")
if (!file.exists(paste(i, ".bgz", sep=""))) {
    bgzip(i)
    indexTabix(paste(i, ".bgz", sep=""), "vcf")
}
i <- paste(i, ".bgz", sep="")

load(file="/PDX/Homopolymers.RData")
    filt <- FilterRules(
            list(
            GQ= function(x) geno(x)$GQ > 20,
                 strandbias=function(x) info(x)$FS < 40,
                 minRead=function(x) {
                     res <- rep(FALSE, length(geno(x)$DP))
                     res[which(geno(x)$DP> 5)] <- TRUE
                     res
                 },
            isSNP=function(x) {
                res <- rep(TRUE, length(geno(x)$DP))
                res[which(sapply(values(rowRanges(x))$REF, nchar)>1)] <- FALSE
                tmp <- sapply(values(rowRanges(x))$ALT, nchar)
                tmp <- sapply(tmp, sum)
                res[which(tmp>1)] <- FALSE
                res
            },
            homo= function(x) {
                     candidates <- findOverlaps(rowRanges(x), HP, maxgap=1L)
                     x1 <- values(rowRanges(x)[queryHits(candidates)])$ALT
                     system.time(x1 <- sapply(x1, function(x) as.character(x[1])))
                     x2 <- values(HP[subjectHits(candidates)])$ref
                     ids <- which(x1==x2)
                     res <- rep(TRUE, length(rowRanges(x)))
                     res[queryHits(candidates)[ids]] <- FALSE
		     res
		 }
            ))
    filtered <- filterVcf(i, "hg19",
                          paste(i, "_SNPS_filtered.vcf",
                                sep=""), filters=filt)
