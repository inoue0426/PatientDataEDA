library(VariantAnnotation)
setwd("/Merged/VCF/")
allF <- dir(pattern=".bgz_SNPS_filtered.vcf$")
SNVs <- NULL
for (i in allF) {
    x <- readVcf(i, "hg19")
    if (file.info(i)$size>0) {
    if (nrow(geno(x)$GT) > 0) {
        ID <- sapply(strsplit(i, ".", fixed=TRUE),
                     function(x) x[1])
        res <- do.call("rbind", geno(x)$AD)
        ref <- res[,1]
        alt <- res[,2]
        tmp <- data.frame(Genotype=geno(x)$GT[,1], ID=ID,
                          Ref=ref, Alt=alt)
        rownames(tmp) <- paste(ID, rownames(tmp), sep=";")
        SNVs <- rbind(SNVs, tmp)
    }
}
    cat(i, " done\n")
}
save(SNVs, file="FilteredSNVs_ALLSAMPLES.RData")

library(VariantAnnotation)
setwd("/Merged/VCF/")
allF <- dir(pattern=".bgz_indels_filtered.vcf$")
indels <- NULL
for (i in allF) {
    x <- readVcf(i, "hg19")
    if (file.info(i)$size>0) {
    if (nrow(geno(x)$GT) > 0) {
        ID <- sapply(strsplit(i, ".", fixed=TRUE),
                     function(x) x[1])
	if(class(geno(x)$AD[1,])=="list") {
         res <- apply(geno(x)$AD, 1, function(y) y[[1]])
	 if (class(res)=="matrix") {
	 res <- t(res)
        sum.res <- rep(2, nrow(res))
	} else {
   	sum.res <- sapply(res, length)
	res <- res[which(sum.res==2)]
	 res <- do.call("rbind", res)
	}
	} else {
        res <- do.call("rbind", geno(x)$AD)
        sum.res <- rep(2, nrow(res))
	}
        ref <- res[,1]
        alt <- res[,2]
        tmp <- data.frame(Genotype=geno(x)$GT[which(sum.res==2),1], ID=ID,
                          Ref=ref, Alt=alt)
        rownames(tmp) <- paste(ID, rownames(tmp), sep=";")
        indels <- rbind(indels, tmp)
    }
}
    cat(i, " done\n")
}
save(indels, file="FilteredIndels_ALLSAMPLES.RData")
