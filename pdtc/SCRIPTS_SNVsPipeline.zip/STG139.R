options(scipen=100)
load(file="SNVsAnnotated.RData")
Annot <- SNVs
load("FilteredSNVs_ALLSAMPLES.RData")
SNVs$V8 <- sapply(strsplit(rownames(SNVs), ";"), function(x) x[2])
SNVs$Chrom <- sapply(strsplit(SNVs$V8, ":"), function(x) x[1])
SNVs <- SNVs[which(SNVs$Chrom %in% paste("chr", c(1:22, "X"), sep="")),]
SNVs$VAF <- SNVs$Alt / (SNVs$Ref+SNVs$Alt)
SNVs$Depth <- (SNVs$Ref+SNVs$Alt)
mean(SNVs$V8 %in% Annot$V8)
SNVs$Chrom <- NULL
SNVs$Ref <- NULL
SNVs$Alt <- NULL
SNVs <- merge(SNVs, Annot, by="V8")
SNVs <- SNVs[which(!SNVs$GenomicPos %in% c("intergenic", "intronic", "ncRNA_intronic")),]
save(SNVs, file="FilteredSNVs_Exonic_ALLSAMPLES.RData")

SS <- read.table("SampleSheetExomes.txt", header=TRUE, sep="\t", stringsAsFactors=FALSE)
SS[grep("X$", SS$ID),'Include'] <- "YES"
SNVs$ID <- sub("_ordered_picard", "", SNVs$ID)
valid.ids <- SS$ID[which(SS$Include=="YES")]
SS <- SS[which(SS$ID %in% valid.ids),]
SNVs <- SNVs[which(SNVs$ID %in% valid.ids),]

ids <- unique(SS$ID[which(SS$Tumour %in% c("STG139", "STG139M"))])
	tmp <- SNVs[which(SNVs$ID %in% ids),]
	tmp$Variant <- tmp$V8
	tmp$V8 <- NULL
	all.x <- tmp[which(tmp$ID==ids[1]),]
	all.x <- all.x[,c('Variant', 'GERMLINE.1000G', 'Type', 'Exon', 'GenomicPos', 'Symbol',
		'GERMLINE.DBSNP', 'SIFT', 'POLYPHEN', 'MT', 'METALR', 'Genotype', 'VAF', 'Depth')]
	colnames(all.x)[c(12:14)] <- paste(ids[1], colnames(all.x)[c(12:14)], sep=".")
	if (length(ids)>1) {
        	for (j in ids[-1]) {
			x <- tmp[which(tmp$ID==j),]
			x <- x[,c('Variant', 'GERMLINE.1000G', 'Type', 'Exon', 'GenomicPos', 'Symbol',
		'GERMLINE.DBSNP', 'SIFT', 'POLYPHEN', 'MT', 'METALR', 'Genotype', 'VAF', 'Depth')]
			colnames(x)[c(12:14)] <- paste(j, colnames(x)[c(12:14)], sep=".")
			all.x <- merge(all.x, x, all=T)
		}
	}
save(all.x, file=paste("ALLSTG139_SNVs.RData", sep=""))

load("FilteredSNVs_ALLSAMPLES.RData")
SNPs <- SNVs[grep("-N", SNVs$ID, fixed=TRUE),]
SNPs$Location <- sapply(strsplit(rownames(SNPs), ";"), function(x) x[2])
SNPs <- SNPs$Location
SNPs <- unique(SNPs)

SS <- read.table("SampleSheetExomes.txt", header=TRUE, sep="\t", stringsAsFactors=FALSE)
SS <- SS[which(SS$Include=="YES"),]
ids <- names(table(SS$Tumour))
load("ALLSTG139_SNVs.RData")
    col.ids <- colnames(all.x)[grep("VAF", colnames(all.x))]
    for (j in col.ids) {
        todo <- all.x$Variant[which(is.na(all.x[,j]))]
        save(todo, file=paste("./MissingSNVs/ALLSTG139_",
                   sub(".VAF", "", j, fixed=TRUE), ".RData", sep=""))
        if (length(todo)>0) {
            todo <- sapply(strsplit(todo, "_"), function(x) x[1])
            pos <- as.numeric(sapply(strsplit(todo, ":"), function(x) x[2]))
            ## pos <- pos + 1
            todo <- paste(todo, pos, sep="-")
            write.table(todo, file=paste("./MissingSNVs/ALLSTG139_",
                              sub(".VAF", "", j, fixed=TRUE), ".intervals", sep=""),
                        row.names=F, col.names=F, quote=F)
        }
    }


## get Missing Reads through GATK
setwd("MissingSNVs/")
allF <- dir(pattern=".intervals$")
allF <- allF[grep("ALLSTG139", allF)]
for (i in allF) {
    file2run <- sub(".intervals", "_ordered_picard.bam", i, fixed=TRUE)
    file2run <- sub("ALLSTG139_", "", file2run, fixed=TRUE)
    runString <- paste("java -Xmx4g -jar /Applications/GATK/GATK-3.3-0/GenomeAnalysisTK.jar ", sep="")
    runString <- paste(runString, " -T HaplotypeCaller -I ",
                       file2run, sep="")
    runString <- paste(runString, " -L  ./MissingSNVs/",
                       i, sep="")
    runString <- paste(runString, " -R ./reference/ucsc.hg19_mmu10.fa", sep="")
    runString <- paste(runString, " -ERC BP_RESOLUTION", sep="")
    runString <- paste(runString, " -o ./MissingSNVs", i, ".vcf  -stand_call_conf 30.0 -stand_emit_conf 20.0", sep="")
    system(runString)
}

load(paste("ALLSTG139_SNVs.RData", sep=""))
all.x$Pos <- sapply(strsplit(all.x$Variant, "_"), function(x) x[1])
all.x$Pos2 <- sapply(strsplit(all.x$Variant, "_"), function(x) x[2])
library(VariantAnnotation)
ids <- colnames(all.x)[grep("VAF", colnames(all.x))]
feo.name <- sub(".VAF", "", ids, fixed=TRUE)
for (k in 1:length(ids)) {
    if (length(ids) > 1) {
    x <- readVcf(paste("./MissingSNVs/MissingSNVsALLSTG139_", feo.name[k], ".intervals.vcf", sep=""), "hg19")
   todo <- length(unique(all.x$Pos[is.na(all.x[,ids[k]])]))
   found <- rownames(geno(x)$AD)
    cat("\n", ids[k], " ", todo, " ", length(found), "\n")
   if (todo == length(found)) {
   variant<- sapply(strsplit(found, "_"), function(x) x[2])
   found <- sapply(strsplit(found, "_"), function(x) x[1])
   for (m in 1:length(found)) {
	tmp <- which(all.x$Pos == found[m])
	for (n in tmp) {
  	feo <- geno(x)$AD[[m]]
        if (is.na(all.x[n,sub("VAF", "Genotype", ids[k])])) {
	if (length(grep("NON", variant[m]))>0) {
 		all.x[n,ids[k]] <- feo[2] / sum(feo)
 		all.x[n,sub("VAF", "Depth", ids[k])] <- sum(feo)
	} else if (all.x$Pos2[n] == variant[m]) {
 		all.x[n,ids[k]] <- feo[2] / sum(feo)
 		all.x[n,sub("VAF", "Depth", ids[k])] <- sum(feo)
	} else {
		all.x[n,ids[k]] <- 0 / sum(feo)
 		all.x[n,sub("VAF", "Depth", ids[k])] <- sum(feo)
            }
    }
    }
    }
} else {
    stop()
}
}
}
    save(all.x, file=paste("ALLSTG139_SNVs_MissingIncluded.RData", sep=""))



##############################################
##############################################
##############################################
## INDELS
##############################################
##############################################
##############################################

load(file="indelsAnnotated.RData")
Annot <- indels
load("Filteredindels_ALLSAMPLES.RData")
indels$V8 <- sapply(strsplit(rownames(indels), ";"), function(x) x[2])
indels$Chrom <- sapply(strsplit(indels$V8, ":"), function(x) x[1])
indels <- indels[which(indels$Chrom %in% paste("chr", c(1:22, "X"), sep="")),]
indels$VAF <- indels$Alt / (indels$Ref+indels$Alt)
indels$Depth <- (indels$Ref+indels$Alt)
mean(indels$V8 %in% Annot$V8)
indels$Chrom <- NULL
indels$Ref <- NULL
indels$Alt <- NULL
indels <- merge(indels, Annot, by="V8")
indels <- indels[which(!indels$GenomicPos %in% c("intergenic", "intronic", "ncRNA_intronic")),]
save(indels, file="Filteredindels_Exonic_ALLSAMPLES.RData")


SS <- read.table("SampleSheetExomes.txt", header=TRUE, sep="\t", stringsAsFactors=FALSE)
SS[grep("X$", SS$ID),'Include'] <- "YES"
indels$ID <- sub("_ordered_picard", "", indels$ID)
valid.ids <- SS$ID[which(SS$Include=="YES")]
SS <- SS[which(SS$ID %in% valid.ids),]
indels <- indels[which(indels$ID %in% valid.ids),]

ids <- unique(SS$ID[which(SS$Tumour %in% c("STG139", "STG139M"))])
tmp <- indels[which(indels$ID %in% ids),]
tmp$Variant <- tmp$V8
tmp$V8 <- NULL
all.x <- tmp[which(tmp$ID==ids[1]),]
all.x <- all.x[,c('Variant', 'GERMLINE.1000G', 'Type', 'Exon', 'GenomicPos', 'Symbol',
		'GERMLINE.DBSNP', 'Genotype', 'VAF', 'Depth')]
	colnames(all.x)[c(8:10)] <- paste(ids[1], colnames(all.x)[c(8:10)], sep=".")
	if (length(ids)>1) {
        	for (j in ids[-1]) {
			x <- tmp[which(tmp$ID==j),]
			x <- x[,c('Variant', 'GERMLINE.1000G', 'Type', 'Exon', 'GenomicPos', 'Symbol',
		'GERMLINE.DBSNP', 'Genotype', 'VAF', 'Depth')]
			colnames(x)[c(8:10)] <- paste(j, colnames(x)[c(8:10)], sep=".")
			all.x <- merge(all.x, x, all=T)
		}
	}
save(all.x, file=paste("ALLSTG139_indels.RData", sep=""))




load("FilteredIndels_ALLSAMPLES.RData")
SNPs <- indels[grep("-N", indels$ID, fixed=TRUE),]
SNPs$Location <- sapply(strsplit(rownames(SNPs), ";"), function(x) x[2])
SNPs <- SNPs$Location
SNPs <- unique(SNPs)

SS <- read.table("SampleSheetExomes.txt", header=TRUE, sep="\t", stringsAsFactors=FALSE)
SS <- SS[which(SS$Include=="YES"),]
ids <- names(table(SS$Tumour))
load("ALLSTG139_indels.RData")
    col.ids <- colnames(all.x)[grep("VAF", colnames(all.x))]
    for (j in col.ids) {
        todo <- all.x$Variant[which(is.na(all.x[,j]))]
        save(todo, file=paste("ALLSTG139_",
                   sub(".VAF", "", j, fixed=TRUE), ".RData", sep=""))
        if (length(todo)>0) {
            todo <- sapply(strsplit(todo, "_"), function(x) x[1])
            pos <- as.numeric(sapply(strsplit(todo, ":"), function(x) x[2]))
            ## pos <- pos + 1
            todo <- paste(todo, pos, sep="-")
            write.table(todo, file=paste("./MissingIndels/ALLSTG139_",
                              sub(".VAF", "", j, fixed=TRUE), ".intervals", sep=""),
                        row.names=F, col.names=F, quote=F)
        }
    }

## get Missing Reads through GATK
setwd("MissingIndels/")
allF <- dir(pattern=".intervals$")
allF <- allF[grep("ALLSTG139", allF)]
for (i in allF) {
    file2run <- sub(".intervals", "_ordered_picard.bam", i, fixed=TRUE)
    file2run <- sub("ALLSTG139_", "", file2run, fixed=TRUE)
    runString <- paste("java -Xmx4g -jar /Applications/GATK/GATK-3.3-0/GenomeAnalysisTK.jar ", sep="")
    runString <- paste(runString, " -T HaplotypeCaller -I ",
                       file2run, sep="")
    runString <- paste(runString, " -L  ./MissingIndels/",
                       i, sep="")
    runString <- paste(runString, " -R ./reference/ucsc.hg19_mmu10.fa", sep="")
    runString <- paste(runString, " -ERC BP_RESOLUTION", sep="")
    runString <- paste(runString, " -o ./MissingIndels", i, ".vcf  -stand_call_conf 30.0 -stand_emit_conf 20.0", sep="")
    system(runString)
}


## Now fill indels

load(paste("ALLSTG139_indels.RData", sep=""))
all.x$Pos <- sapply(strsplit(all.x$Variant, "_"), function(x) x[1])
all.x$Pos2 <- sapply(strsplit(all.x$Variant, "_"), function(x) x[2])
library(VariantAnnotation)
ids <- colnames(all.x)[grep("VAF", colnames(all.x))]
feo.name <- sub(".VAF", "", ids, fixed=TRUE)
for (k in 1:length(ids)) {
    x <- readVcf(paste("./Missingindels/MissingIndelsALLSTG139_", feo.name[k], ".intervals.vcf", sep=""), "hg19")
   todo <- length(unique(all.x$Pos[is.na(all.x[,ids[k]])]))
   found <- rownames(geno(x)$AD)
    cat("\n", ids[k], " ", todo, " ", length(found), "\n")
   if (todo == length(found)) {
   variant<- sapply(strsplit(found, "_"), function(x) x[2])
   found <- sapply(strsplit(found, "_"), function(x) x[1])
   for (m in 1:length(found)) {
	tmp <- which(all.x$Pos == found[m])
	for (n in tmp) {
  	feo <- geno(x)$AD[[m]]
        if (is.na(all.x[n,sub("VAF", "Genotype", ids[k])])) {
	if (length(grep("NON", variant[m]))>0) {
 		all.x[n,ids[k]] <- feo[2] / sum(feo)
 		all.x[n,sub("VAF", "Depth", ids[k])] <- sum(feo)
	} else if (all.x$Pos2[n] == variant[m]) {
 		all.x[n,ids[k]] <- feo[2] / sum(feo)
 		all.x[n,sub("VAF", "Depth", ids[k])] <- sum(feo)
	} else {
		all.x[n,ids[k]] <- 0 / sum(feo)
 		all.x[n,sub("VAF", "Depth", ids[k])] <- sum(feo)
	}
	}
	}
    }
} else {
    stop()
}
}
   save(all.x, file=paste("ALLSTG139_indels_MissingIncluded.RData", sep=""))


