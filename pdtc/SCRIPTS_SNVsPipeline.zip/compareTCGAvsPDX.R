coliClust <- c('#FF5500', '#00EE76', '#CD3278', '#00C5CD', '#8B0000',
               '#FFFF40', '#0000CD', '#FFAA00', '#EE82EE', '#7D26CD')

load(file="MutationIndicator.RData")
Clinical <- read.table("TCGA.Clinical.txt", header=TRUE, sep="\t", stringsAsFactors=F)
Clinical <- Clinical[which(Clinical$Gender == "FEMALE"),]
Clinical <- Clinical[,c('Complete.TCGA.ID', 'ER.Status')]
Clinical <- Clinical[which(Clinical$ER.Status %in% c("Negative", "Positive")),]

rownames(muts.tot) <- sapply(strsplit(rownames(muts.tot), "-"), function(x) paste(x[1:3], collapse="-"))

found <- intersect(rownames(muts.tot), Clinical[,1])
muts.tot <- muts.tot[which(rownames(muts.tot) %in% found),]
Clinical <- Clinical[which(Clinical[,1] %in% found),]
Clinical <- Clinical[match(rownames(muts.tot), Clinical[,1]),]
TCGA.Clinical <- Clinical

res <- apply(muts.tot, 2, function(x) tapply(x, Clinical$ER.Status, mean))

TCGA.Pos <- res['Positive',]
TCGA.Neg <- res['Negative',]

Freqs <- read.table("/SNVsFrequency_SDFilteredV3.txt", header=TRUE, sep="\t")

N <- 20
TP <- names(sort(TCGA.Pos, decreasing=T)[1:N])
TN <- names(sort(TCGA.Neg, decreasing=T)[1:N])
pos <- TP
neg <- TN

TP <- TCGA.Pos[which(names(TCGA.Pos) %in% pos)]
TP <- data.frame(Symbol=names(TP), TCGA=TP)
TN <- TCGA.Neg[which(names(TCGA.Neg) %in% neg)]
TN <- data.frame(Symbol=names(TN), TCGA=TN)

PP <- Freqs[which(Freqs$Symbol %in% pos),1:2]
PN <- Freqs[which(Freqs$Symbol %in% neg),c(1, 3)]
colnames(PP)[2] <- "PDTX"
colnames(PN)[2] <- "PDTX"

ERP <- merge(TP, PP, all=T)
ERN <- merge(TN, PN, all=T)
rownames(ERP) <- ERP$Symbol
ERP <- as.matrix(ERP[,-1])
rownames(ERN) <- ERN$Symbol
ERN <- as.matrix(ERN[,-1])

ERP <- ERP[order(ERP[,'TCGA'], I(1-ERP[,'PDTX']),
                 decreasing=T),]
ERN <- ERN[order(ERN[,'TCGA'], I(1-ERN[,'PDTX']),
                 decreasing=T),]

ERP[,'PDTX'][which(is.na(ERP[,'PDTX']))] <- 0
ERN[,'PDTX'][which(is.na(ERN[,'PDTX']))] <- 0

pdf("/SNVsFreqsTCGAvsPDTX.pdf", width=12, height=6)
barplot(t(ERN), beside=T, legend.text=c("TCGA", "PDTX"),
        main="ER-", las=2)
barplot(t(ERP), beside=T, legend.text=c("TCGA", "PDTX"),
        main="ER+", las=2)

## Now iClusters
iCl <- read.table("Curtis.Subtypes.txt",
                  header=TRUE, stringsAsFactors=FALSE)
iCl$Sample <- sapply(strsplit(iCl$Array_sample, "-"), function(x) paste(x[1:3], collapse="-"))
TCGA.Clinical <- merge(TCGA.Clinical, iCl, by.x="Complete.TCGA.ID", by.y="Sample", sort=F)
found <- intersect(rownames(muts.tot), TCGA.Clinical[,1])
muts.tot <- muts.tot[which(rownames(muts.tot) %in% found),]
TCGA.Clinical <- TCGA.Clinical[which(TCGA.Clinical[,1] %in% found),]
TCGA.Clinical <- TCGA.Clinical[match(rownames(muts.tot), TCGA.Clinical[,1]),]
X <- t(apply(muts.tot, 2,  function(x) tapply(x, TCGA.Clinical[,4], mean)))

mutations.PDX <- read.table(file="/SNVsSummary_SDFilteredV3.txt", sep="\t", header=T)
freqs <- apply(mutations.PDX[,-1], 1, function(x) mean(x!="NO"))
names(freqs) <- mutations.PDX$Symbol

ER <- read.table("/ER_HER2_PR.txt", header=TRUE, sep="\t", stringsAsFactors=F)
Exp.SS <- read.table("/ExpressionPhenotipicDataPDX.txt", header=TRUE, sep="\t", stringsAsFactors=F)
Exp.SS <- Exp.SS[,c('ID', 'Tumour', 'Type')]
ER <- merge(ER, Exp.SS)
Clinical <- aggregate(ER[,c('ThreeGene', 'PAM50', 'ER', 'HER2', 'PR', 'iC10')], by=list(ER$Tumour), FUN=function(x) names(table(x))[which.max(table(x))])
colnames(Clinical)[1] <- "Tumour"
Clinical.mutations <- Clinical[which(Clinical$Tumour %in% colnames(mutations.PDX)[-1]),]
Clinical.mutations <- Clinical.mutations[match(colnames(mutations.PDX)[-1], Clinical.mutations$Tumour),]
Clinical.mutations$iC10 <- factor(Clinical.mutations$iC10, levels=1:10)
freqs <- apply(mutations.PDX[,-1], 1, function(x) tapply(x, Clinical.mutations$iC10, function(y) mean(y!="NO")))
colnames(freqs) <- mutations.PDX$Symbol

for (i in c(1, 9, 10)) {
    Tc <- names(X[order(X[,i], decreasing=T),1][1:N])
    Pd <- colnames(freqs[,order(freqs[i,], decreasing=T)])[1:N]
    mut <- unique(c(Tc, Pd))

    Tc <- X[which(rownames(X) %in% mut), i]
    Tc <- data.frame(Symbol=names(Tc), TCGA=Tc)
    Pd <- freqs[i,which(colnames(freqs) %in% mut)]
    Pd <- data.frame(Symbol=names(Pd), PDTX=Pd)
    ALL <- merge(Tc, Pd, all=T)
    rownames(ALL) <- ALL$Symbol
    ALL <- as.matrix(ALL[,-1])
    ALL <- ALL[order(ALL[,'TCGA'], I(1-ALL[,'PDTX']),
                 decreasing=T),]
    barplot(t(ALL), beside=T, legend.text=c("TCGA", "PDTX"),
        main=paste("IntClust", i), las=2, col=coliClust[i])
}


dev.off()


pdf("/SNVsFreqsTCGAvsPDTX.pdf", width=12, height=8)
par(oma=c(1, 3, 1, 1), mfrow=c(1,2))
barplot(100*t(ERN), horiz=T, las=1, col=c("#FFFF33", "black"),
        beside=T, legend.text=c("TCGA", "PDTX"),
        main="ER-", xlim=c(0, 100), xlab="Percentage", cex.lab=1.3,
        cex.axis=1.3, cex.names=1.3)
barplot(100*t(ERP), beside=T, horiz=T, las=1, col=c("#377EB8", "black"),
        xlab="Percentage",
        legend.text=c("TCGA", "PDTX"),
        main="ER+", xlim=c(0,100), cex.lab=1.3,
        cex.axis=1.3, cex.names=1.3)
dev.off()

