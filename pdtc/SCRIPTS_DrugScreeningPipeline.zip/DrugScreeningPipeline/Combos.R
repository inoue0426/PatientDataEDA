library(isotonic.pen)
extract.data.combo <- function(X, drug.set.id, position, model) {
    all.res <-  NULL
    all.Y <- X[which(X$DRUG_SET_ID==drug.set.id & X$mp==position &
                 X$Model==model),]
    if (nrow(all.Y)>0) {
        for (bc in unique(all.Y$BARCODE)) {
            Y <- all.Y[which(all.Y$BARCODE==bc),]
            Y$P_ROW <- factor(Y$P_ROW)
            Y$P_COLUMN <- factor(Y$P_COLUMN)
            val <- xtabs(INTENSITY ~ P_ROW + P_COLUMN, data=Y)
            neg.controls <- X[which(X$DRUG_SET_ID==drug.set.id &
                                    X$Model==model),]
            neg.controls <- xtabs(INTENSITY ~ P_ROW + P_COLUMN,
                                  data=neg.controls)
            neg.controls <- neg.controls[,'1']
            neg.controls <- mean(neg.controls)
            if (position %in% c("A1", "B1", "C1")) {
                pos.controls <- c(val[,1], val[1,-1], val[2,2])
            } else {
                pos.controls <- c(val[,1], val[7,-1], val[1,2])
            }
            pos.controls <- mean(pos.controls)

            ## get concentrations
            conc <- read.csv("/DrugsPanel/Combos/combos_maxconc.txt", header=T, sep="\t", stringsAsFactors=FALSE)
    conc <- conc[which(conc$drug_set_id==drug.set.id),]
            Codes <- read.csv("/DrugsPanel/drug_mapping.csv", stringsAsFactors=FALSE)
            Codes <- unique(Codes)
            conc <- merge(conc, Codes, by.x="drug_id", by.y="DRUG_ID")
            drug.name.row <- conc$DRUG_NAME[which(conc$micronic_position==position)]
            MAX.CONC.row <- conc$working_stock_conc[which(conc$micronic_position==position)]
            col.index <- paste(sapply(strsplit(position, split=""),
                              function(x) x[1]), "3", sep="")
            drug.name.col <- conc$DRUG_NAME[which(conc$micronic_position ==
                                          col.index)]
            MAX.CONC.col <- conc$working_stock_conc[which(conc$micronic_position ==
                                                  col.index)]
            CONCS.row <- MAX.CONC.row / c(1, 4, 16, 64, 256)
            CONCS.col <- MAX.CONC.col / c(1, 4, 16, 64, 256)

            ## Drug on the row
            res <- NULL
            res$DRUG_SET <- drug.set.id
            res$Model <- model
            res$Barcode <- bc
            res$Drug <- rep(drug.name.row, 6)
            res$Anchor <- rep(drug.name.col, 6)
            res <- as.data.frame(res)
            res$Dose <- c(NA, CONCS.col)
            res$y1 <- NA
            res$y2 <- NA
            res$y3 <- NA
            res$y4 <- NA
            res$y5 <- NA
            res$MAX_CONC <- max(CONCS.row)
            for (i in 0:length(CONCS.col)) {
                obs.x <- CONCS.row
                if (position %in% c("A1", "B1", "C1")) {
                    y <- val[2+i,3:7]
                } else {
                    y <- val[1+i,3:7]
                }
                obs.y <- 100 - (100 * y/(pos.controls - neg.controls))
                obs.y <- pmin(obs.y, 100)
                obs.y <- pmax(0, obs.y)
                res[i+1, c('y1', 'y2', 'y3', 'y4', 'y5')] <- obs.y
    }
    res.row <- res

    ## Drug on the column
            res <- NULL
            res$DRUG_SET <- drug.set.id
            res$Model <- model
            res$Drug <- rep(drug.name.col, 6)
            res$Barcode <- bc
            res$Anchor <- rep(drug.name.row, 6)
            res <- as.data.frame(res)
            res$Dose <- c(NA, CONCS.row)
            res$y1 <- NA
            res$y2 <- NA
            res$y3 <- NA
            res$y4 <- NA
            res$y5 <- NA
            res$MAX_CONC <- max(CONCS.col)
            for (i in 0:length(CONCS.row)) {
                obs.x <- CONCS.col
                if (position %in% c("A1", "B1", "C1")) {
                    y <- val[3:7,2+i]
                } else {
                    y <- val[2:6,2+i]
                }
                obs.y <- 100 - (100 * y/(pos.controls - neg.controls))
                obs.y <- pmin(obs.y, 100)
                obs.y <- pmax(0, obs.y)
                res[i+1, c('y1', 'y2', 'y3', 'y4', 'y5')] <- obs.y
            }
            res.col <- res
            res <- rbind(res.row, res.col)
            all.res <- rbind(all.res, res)
        }
        all.res
    }

}

fit.isotonic <- function(obs.x,obs.y, sample=NA, drug=NA, plot=TRUE) {
    require(flux)
    obs.data <- data.frame(y=obs.y, x=obs.x)
    res <-isoreg(x=obs.data$x, y=obs.data$y)
    error <- mean(resid(res)^2)
    dif.doses <- length(unique(obs.x))
    fit.y <- res$yf[seq(from=1, length=dif.doses,
                        by=nrow(obs.data)/dif.doses)]
    fit.x <- unique(sort(obs.x, decreasing=F))
    AUC <- auc(fit.x, fit.y)
    AUC <- AUC / (diff(range(obs.x))*100)
    spli <- smooth.spline(x=fit.x, y=fit.y, all.knots=TRUE, df=2)
    iC50 <- predict(spli, seq(from=-100, to=100, length=1000))
    iC50 <- iC50$x[which.min(abs(50-iC50$y))]
    ## Now we need to make sure that we only get 5 values
    if (length(fit.y) == 10) {
        fit.y <- fit.y[seq(from=2, to=10, by=2)]
        fit.x <- fit.x[seq(from=2, to=10, by=2)]
    }
    if (plot) {
        plot(fit.x, fit.y, type="l", main=paste(sample, drug),
             xlab="Dose", ylab="Response",
             ylim=c(0,100))
        points(obs.x, obs.y, col=1, pch=19)
    }
    list(fit=fit.y, error=error, AUC=AUC, iC50=exp(iC50))
}

source("/Combos_functions.R")
X <- read.csv("/DrugsPanel/Combos/Combinations/Combos1.csv")

IDS <- read.csv("/Combos/CELLIDS_COMBOS.csv")
X <- merge(X, IDS, all.x=T, by.x="CELL_ID", by.y="CELL.ID")
colnames(X)[which(colnames(X)=="COSMIC.Name")] <- "Model"
table(X$P_ROW, X$P_COLUMN, X$Model, X$DRUG_SET_ID)

Addit <- read.table("/DrugsPanel/Combos/Combinations/AdditionalCombos.txt", header=TRUE, sep="\t")

colnames(Addit)[which(colnames(Addit)=="P_COL")] <- "P_COLUMN"
firtstry <- merge(X, Addit, all=T)

X$mp <- NA
for (i in 1:nrow(X)) {
    mp <- NA
    if (X$P_ROW[i] %in% c("B", "C", "D", "E", "F", "G", "H") &
        X$P_COLUMN[i] %in% 2:8) {
        mp <- "A1"
    }
    if (X$P_ROW[i] %in% c("B", "C", "D", "E", "F", "G", "H") &
        X$P_COLUMN[i] %in% 9:15) {
        mp <- "B1"
    }
    if (X$P_ROW[i] %in% c("B", "C", "D", "E", "F", "G", "H") &
        X$P_COLUMN[i] %in% 16:22) {
        mp <- "C1"
    }
    if (X$P_ROW[i] %in% c("I", "J", "K", "L", "M", "N", "O") &
        X$P_COLUMN[i] %in% 2:8) {
        mp <- "D1"
    }
    if (X$P_ROW[i] %in% c("I", "J", "K", "L", "M", "N", "O") &
        X$P_COLUMN[i] %in% 9:15) {
        mp <- "E1"
    }
    if (X$P_ROW[i] %in% c("I", "J", "K", "L", "M", "N", "O") &
        X$P_COLUMN[i] %in% 16:22) {
        mp <- "F1"
    }
    X$mp[i] <- mp
}

all.res <- NULL
for (i in unique(X$DRUG_SET_ID)) {
    for (j in c("A1", "B1", "C1", "D1", "E1", "F1")) {
        for (k in unique(X$Model)) {
            res <- extract.data.combo(X, i, j, k)
            if (!is.null(res)) res[,'POS'] <- j
            all.res <- rbind(all.res, res)
        }
    }
    cat("done ", i, "\n")
}

T.names <- read.table("/DrugsPanel/SampleSheetDrugs_Combos.txt", header=TRUE, sep="\t")
T.names <- T.names[which(T.names$INCLUDE=="YES"),]
all.res <- merge(all.res, T.names, by.x="Model", by.y="Name")


 ## Isotonic fits
all.fits <- list()
errors <- list()
all.AUC <- c()
all.iC50 <- c()
counter <- 1
for (p in 1:nrow(all.res)) {
    y <- unclass(all.res[p, c('y1', 'y2', 'y3', 'y4', 'y5')])
    y <- do.call("c", y)
    x <- log(all.res$MAX_CONC[p] / c(1, 4, 16, 64, 256))
    tmp <- fit.isotonic(x,y, sample=all.res$Model[p],
                        drug=all.res$Drug[p])
            all.fits[[counter]] <- tmp$fit
            errors[[counter]] <- tmp$error
            all.AUC[[counter]] <- tmp$AUC
            all.iC50[[counter]] <- tmp$iC50
    counter <- counter + 1
}

all.AUC <- cbind(all.res[,c(1:6,14, 15)], all.AUC)
colnames(all.AUC)[9] <- "AUC"
AUC <- all.AUC[which(is.na(all.AUC$Dose)),]
AUC$Anchor <- NULL
AUC <- aggregate(AUC$AUC, by=list(AUC$ID , AUC$Drug), mean)
colnames(AUC) <- c("ID", "Drug", "AUC")

## Now let's check with the single dose data
load(file="/DrugScreening/AllFits.RData")
SDfits <- SDfits[,c('Drug', 'AUC', 'Tumour', 'ID')]
colnames(SDfits)[2] <- "AUC.Single"
SDfits <- SDfits[which(SDfits$Tumour %in% unique(all.AUC$Tumour)),]
SDfits <- SDfits[which(SDfits$Drug %in% unique(all.AUC$Drug)),]

AUC <- merge(AUC, SDfits, all=T)

pdf("/DrugScreening/CombovsSingle.pdf", width=8, height=8)
par(mar=c(6, 6, 6, 6))
plot(AUC ~ AUC.Single, data=AUC, pch=19, xlab="AUC Single Drug Screening", ylab="AUC Combo Screening", cex.lab=1.7, cex.axis=1.7)
abline(a=0, b=1, col=2)
dev.off()


all.bliss <- list()
all.models <- c()
all.Drugs <- c()
all.anchors <- c()
counter <- 1
pdf("/DrugScreening/ComboTOTAL.pdf", width=12, height=12)
par(mfrow=c(2,2))
options(scipen=3)
for (i in as.character(sort(unique(all.res$ID)))) {
    for (j in as.character(sort(unique(all.res$Drug[which(all.res$ID==i)])))) {
        for (k in as.character(sort(unique(all.res$Anchor[which(all.res$ID==i & all.res$Drug==j)])))) {
            sub.x.1 <- all.res[which(all.res$ID==i &
                                     all.res$Drug==j & all.res$Anchor==k),]
            sub.x.2 <- all.res[which(all.res$ID==i &
                                     all.res$Drug==k & all.res$Anchor==j),]
            sd.1 <- sub.x.1[which(is.na(sub.x.1$Dose)),]
            y <- c()
            for (p in 1:nrow(sd.1)) {
                y <- c(y, unclass(sd.1[p, c('y1', 'y2', 'y3', 'y4', 'y5')]))
            }
            y <- do.call("c", y)
            x <- rep(log(sd.1$MAX_CONC[1] / c(1, 4, 16, 64, 256)), nrow(sd.1))
            res <- fit.isotonic(x,y, plot=FALSE)
            AUC1 <- res$AUC
            expect.1 <- res$fit
            pos.plot <- as.numeric(factor(x, levels=sort(unique(x))))
            plot(pos.plot, y, col=rep(1:nrow(sd.1), 5), ylim=c(0,100), pch=19, xlab=j,
                 axes=F, ylab="Percent of cells dead")
            lines(sort(pos.plot[1:5]), res$fit, type="l", lwd=2, col="red")
            sd.2 <- sub.x.2[which(is.na(sub.x.2$Dose)),]
            axis(2)
            axis(1, at=pos.plot, labels=round(c(exp(x)),3))
            y <- c()
            for (p in 1:nrow(sd.2)) {
                y <- c(y, unclass(sd.2[p, c('y1', 'y2', 'y3', 'y4', 'y5')]))
            }
            y <- do.call("c", y)
            x <- rep(log(sd.2$MAX_CONC[1] / c(1, 4, 16, 64, 256)), nrow(sd.2))
            res <- fit.isotonic(x,y, plot=FALSE)
            AUC2 <- res$AUC
            expect.2 <- res$fit
            pos.plot <- as.numeric(factor(x, levels=sort(unique(x))))
            points(pos.plot, y, col=rep(1:nrow(sd.1), 5), ylim=c(0,100), pch=17)
            lines(sort(pos.plot[1:5]), res$fit, type="l", lwd=2, col="blue")
            axis(3, at=pos.plot, labels=round(c(exp(x)),3))
            mtext(k, side=3, line=2)
            box()
            legend("topleft", pch=c(19, 17), col=c("red", "blue"), legend=c(j,k), bty="n")
        ## AUC part
        AUC.exp <- AUC1 + AUC2 - AUC1*AUC2
        sub.AUC <- all.AUC[which(all.AUC$ID==i & all.AUC$Drug==j & all.AUC$Anchor==k),]
        sub.AUC <- aggregate(sub.AUC$AUC, by=list(sub.AUC$Dose), mean)
        pos.plot <- as.numeric(factor(sub.AUC[,1], levels=sort(unique(sub.AUC[,1]))))
        plot(pos.plot, sub.AUC[,2], ylim=c(0,1), ylab="AUC", xlab=j, axes=F, type="b", col="red", lwd=2)
        axis(2)
            labsax1 <- sub.AUC[,1]
        sub.AUC <- all.AUC[which(all.AUC$ID==i & all.AUC$Drug==k & all.AUC$Anchor==j),]
        sub.AUC <- aggregate(sub.AUC$AUC, by=list(sub.AUC$Dose), mean)
        pos.plot2 <- as.numeric(factor(sub.AUC[,1], levels=sort(unique(sub.AUC[,1]))))
        lines(pos.plot2, sub.AUC[,2], ylim=c(0,1), col="blue", type="b", lwd=2)
            labsax2 <- sub.AUC[,1]
        axis(3, pos.plot, round(labsax1, 3))
            axis(1, pos.plot2, round(labsax2, 3))
        mtext(k, side=3, line=2)
        abline(h=AUC.exp, col="black", lwd=2)
        legend("topleft", lwd=rep(2, 3), col=c("black", "red", "blue"),
               legend=c("Expected AUC", paste(j, "AUC"), paste(k, "AUC")), bty="n")
        box()
        ## Bivariate isotonic fit,


        sub.x.1$Dose[which(is.na(sub.x.1$Dose))] <- max(sub.x.1$Dose, na.rm=TRUE) / (4 *256)
        y <- c()
       for (p in 1:nrow(sub.x.1)) {
          y <- c(y, unclass(sub.x.1[p, c('y1', 'y2', 'y3', 'y4', 'y5')]))
       }
      x1 <- rep(log(sub.x.1$MAX_CONC[1] / c(1, 4, 16, 64, 256)), nrow(sub.x.1))
      x2 <- rep(log(sub.x.1$Dose), rep(5, nrow(sub.x.1)))
      sub.x.2 <- sub.x.2[which(is.na(sub.x.2$Dose)),]
      for (p in 1:nrow(sub.x.2)) {
          y <- c(y, unclass(sub.x.2[p, c('y1', 'y2', 'y3', 'y4', 'y5')]))
      }
     y <- do.call("c", y)
     x1 <- c(x1, rep(log(rep(max(exp(x1)) / (4 *256))), 5 * nrow(sub.x.2)))
     x2 <- c(x2, rep(log(sub.x.2$MAX_CONC[1] / c(1, 4, 16, 64, 256)), nrow(sub.x.2)))
     biv.fit <- iso_pen(y,cbind(x1,x2))
        fitted.obs <- unique(cbind(x1, x2, biv.fit$fit))
     biv.fit$xgmat[1,1] <- NA
     persp(biv.fit$xg1,biv.fit$xg2,biv.fit$xgmat,th=-40, col="olivedrab", r=5, ticktype="detailed", nticks=5,xlab=j,ylab=k,zlab="% Dead Cells", zlim=c(0, 100), cex.lab=1.5, cex.axis=1.5)

        ## Bliss Model
        doses <- expand.grid(log(sd.1$MAX_CONC[1] / c(1, 4, 16, 64, 256)), log(sd.2$MAX_CONC[1] / c(1, 4, 16, 64, 256)))
        colnames(doses) <- c(as.character(j),as.character(k))
        doses <- doses[order(doses[,1], doses[,2]),]
        expect.1 <- expect.1 / 100
        expect.2 <- expect.2 / 100
        expected <- matrix(NA, 5, 5)
        for (nr in 1:5) {
            for (nc in 1:5) {
                expected[nr,nc] <- (expect.1[nr] + expect.2[nc]) - (expect.1[nr]*expect.2[nc])
            }
        }
        fitted.obs <- fitted.obs[-which(fitted.obs[,1]==min(fitted.obs[,1])),]
        fitted.obs <- fitted.obs[-which(fitted.obs[,2]==min(fitted.obs[,2])),]
        fitted.obs <- fitted.obs[order(fitted.obs[,1], fitted.obs[,2]),]
        fitted.obs <- matrix(fitted.obs[,3], nrow=5, byrow=TRUE)
        fitted.obs <- fitted.obs / 100
        resid <- 100 * (fitted.obs - expected)
            all.bliss[[counter]] <- resid
            all.models <- c(all.models, i)
            all.Drugs <- c(all.Drugs, j)
            all.anchors <- c(all.anchors,k)

            library(RColorBrewer)
        cols <- rev(brewer.pal(9, 'RdBu'))
        breaks <- c(-101, -50, -25, -10, -5, 5, 10, 25, 50, 101)
        image(resid, axes=F, xlab=j, ylab=k, col=cols, breaks=breaks,
              main=i, cex.lab=1.2)
        y.ticks <- seq(from=0, to=1, length=nrow(resid))
        x.ticks <- seq(from=0, to=1, length=ncol(resid))
        axis(1, at=x.ticks, labels=round(labsax2, 3),
             cex.axis=1.2)
        axis(2, at=y.ticks, labels=round(labsax1, 3),
             cex.axis=1.2)
        all.pos <- expand.grid(x.ticks, y.ticks)
        text(all.pos[,1], all.pos[,2],
             paste(round(unclass(resid), 2), "%", sep=""), cex=1.2)
            counter <- counter + 1
    }
    }
}
dev.off()

pdf("/DrugScreening/Sinergy_NVP_BMS.pdf", width=9, height=7)
par(oma=c(6, 3, 3, 3))
ids <- which(all.Drugs== "NVP-BEZ235" & all.anchors== "BMS-754807")
fig1.models <- all.models[ids]
fig1.bliss <- all.bliss[ids]
ord.ids <- order(sapply(fig1.bliss, median))
boxplot(fig1.bliss[ord.ids], names=fig1.models[ord.ids], cex.axis=1.3, las=2, col=brewer.pal(9, "Set1"),
        main="NVP-BEZ235 and BMS-754807", cex.main=1.5)
abline(h=0)
dev.off()

pdf("/DrugScreening/Sinergy_Paclitex_17AGG.pdf", width=9, height=7)
par(oma=c(6, 3, 3, 3))
ids <- which(all.Drugs== "Paclitaxel" & all.anchors== "17-AAG")
fig1.models <- all.models[ids]
fig1.bliss <- all.bliss[ids]
ord.ids <- order(sapply(fig1.bliss, median))
boxplot(fig1.bliss[ord.ids], names=fig1.models[ord.ids], cex.axis=1.3, las=2, col=brewer.pal(9, "Set1"),
        main="Paclitaxel and 17-AGG", cex.main=1.5)
abline(h=0)
dev.off()


sinergy <- sapply(all.bliss, quantile, p=0.95)
sinergy <- data.frame(ID=all.models, Drug1=all.Drugs, Drug2=all.anchors, sinergy)
antagonism <- sapply(all.bliss, quantile, p=0.05)
antagonism <- data.frame(ID=all.models, Drug1=all.Drugs, Drug2=all.anchors, antagonism)

Targets <- read.table("/DrugScreening/drug%20annotations_final.txt", header=T, sep="\t", stringsAsFactors=F)
Targets <- Targets[,c('DRUG_NAME', 'Matthew.Pathway')]
colnames(Targets) <- c("Drug", "Pathway")
Targets$Pathway[which(Targets$Pathway=="other")] <- "Unknown"
Targets$Pathway <- factor(Targets$Pathway)
Targets$Drug[which(Targets$Drug=="Cisplatin")] <- "cisplatin"

sinergy <- merge(sinergy, Targets, by.x="Drug1", by.y="Drug")
colnames(sinergy)[5] <- "Pathway1"
sinergy <- merge(sinergy, Targets, by.x="Drug2", by.y="Drug")
colnames(sinergy)[6] <- "Pathway2"
sinergy <- sinergy[order(sinergy$ID, sinergy$Pathway1, sinergy$Pathway2),]

antagonism <- merge(antagonism, Targets, by.x="Drug1", by.y="Drug")
colnames(antagonism)[5] <- "Pathway1"
antagonism <- merge(antagonism, Targets, by.x="Drug2", by.y="Drug")
colnames(antagonism)[6] <- "Pathway2"
antagonism <- antagonism[order(antagonism$ID, antagonism$Pathway1, antagonism$Pathway2),]

SS <- all.res[,c('ID', 'Tumour')]
SS <- unique(SS)
sinergy <- merge(sinergy, SS)
antagonism <- merge(antagonism, SS)
SS <- read.table("/Expression/ModelsClassifiers.txt", header=TRUE, sep="\t")
SS <- SS[,c('Tumour', 'ER.status', 'ER')]
sinergy <- merge(sinergy, SS)
antagonism <- merge(antagonism, SS)

pdf("/DrugScreening/Sinergy_Pacli_Cispl.pdf", width=9, height=9)
par(oma=c(5, 5, 2, 2))
Paclitaxel <- sinergy[which(sinergy$Drug1=="Paclitaxel"),]
X <- xtabs(sinergy ~ factor(ID) + factor(Drug2), data=Paclitaxel)
X <- t(X)
ER <- tapply(sinergy$ER.status, factor(sinergy$ID), function(x) as.character(x[1]))
X <- X[,order(ER)]
ER <- ER[order(ER)]
cols <- rev(brewer.pal(9, 'RdBu'))
breaks <- c(-101, -50, -25, -10, -5, 5, 10, 25, 50, 101)
image(X, axes=F, col=cols, breaks=breaks,
      main="Paclitaxel",  cex.lab=1.2)
x.ticks <- seq(from=0, to=1, length=nrow(X))
y.ticks <- seq(from=0, to=1, length=ncol(X))
axis(1, at=x.ticks, labels=rownames(X),  cex.axis=1.2, las=2)
axis(2, at=y.ticks[which(ER=="Pos")], labels=colnames(X)[which(ER=="Pos")],  cex.axis=1.2, las=1, col.axis="red")
axis(2, at=y.ticks[which(ER=="Neg")], labels=colnames(X)[which(ER=="Neg")],  cex.axis=1.2, las=1, col.axis="blue")
box()
all.pos <- expand.grid(x.ticks, y.ticks)
text(all.pos[,1], all.pos[,2],
     paste(round(unclass(X), 2), "%", sep=""), cex=1.2)
Cisplatin <- sinergy[which(sinergy$Drug1=="cisplatin"),]
X <- xtabs(sinergy ~ factor(ID) + factor(Drug2), data=Cisplatin)
X <- t(X)
ER <- tapply(sinergy$ER.status, factor(sinergy$ID), function(x) as.character(x[1]))
X <- X[,order(ER)]
ER <- ER[order(ER)]
cols <- rev(brewer.pal(9, 'RdBu'))
breaks <- c(-101, -50, -25, -10, -5, 5, 10, 25, 50, 101)
image(X, axes=F, col=cols, breaks=breaks,
      main="Cisplatin",  cex.lab=1.2)
x.ticks <- seq(from=0, to=1, length=nrow(X))
y.ticks <- seq(from=0, to=1, length=ncol(X))
axis(1, at=x.ticks, labels=rownames(X),  cex.axis=1.2, las=2)
axis(2, at=y.ticks[which(ER=="Pos")], labels=colnames(X)[which(ER=="Pos")],  cex.axis=1.2, las=1, col.axis="red")
axis(2, at=y.ticks[which(ER=="Neg")], labels=colnames(X)[which(ER=="Neg")],  cex.axis=1.2, las=1, col.axis="blue")
box()
all.pos <- expand.grid(x.ticks, y.ticks)
text(all.pos[,1], all.pos[,2],
     paste(round(unclass(X), 2), "%", sep=""), cex=1.2)
dev.off()


## Remove duplicates

sinergy$Comb <- factor(interaction(sinergy$Pathway1, sinergy$Pathway2))
antagonism$Comb <- factor(interaction(antagonism$Pathway1,
                                      antagonism$Pathway2))
ord <- tapply(sinergy$sinergy, sinergy$Comb, median)
sinergy$Comb <- factor(sinergy$Comb, levels=names(sort(ord)))
sinergy <- sinergy[which(sinergy$Comb %in%
                         levels(sinergy$Comb)[seq(from=1,
                         to=length(levels(sinergy$Comb)),
                        by=2)]),]
ord <- tapply(sinergy$sinergy, sinergy$Comb, median)
sinergy$Comb <- factor(sinergy$Comb, levels=names(sort(ord)))


ord <- tapply(antagonism$antagonism, antagonism$Comb, median)
antagonism$Comb <- factor(antagonism$Comb, levels=names(sort(ord)))
antagonism <- antagonism[which(antagonism$Comb %in%
                         levels(antagonism$Comb)[seq(from=1,
                         to=length(levels(antagonism$Comb)),
                        by=2)]),]
ord <- tapply(antagonism$antagonism, antagonism$Comb, median)
antagonism$Comb <- factor(antagonism$Comb, levels=names(sort(ord)))

pdf("/DrugScreening/Sinergy_Antagonism.pdf", width=9, height=15)
par(oma=c(2,14, 2,2))
boxplot(sinergy ~ Comb, data=sinergy, las=1, col=brewer.pal(9, "Set1"), xlab="Sinergy", horizontal=TRUE, cex.axis=1.3,
        cex.lab=1.3)
abline(v=0)
boxplot(antagonism ~ Comb, data=antagonism, las=1, col=brewer.pal(9, "Set1"), xlab="Antagonism", horizontal=TRUE,
        cex.axis=1.3,  cex.lab=1.3)
abline(v=0)
dev.off()


