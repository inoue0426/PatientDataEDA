## Prepare data
## List of drugs
Targets <- read.table("/drug%20annotations_final.txt", header=T, sep="\t", stringsAsFactors=F)
Targets$pathway <- gsub(" $", "", Targets$pathway)
Targets$Matthew.Pathway <- gsub(" $", "", Targets$Matthew.Pathway)
Targets <- Targets[,c('DRUG_NAME', 'pathway', 'Matthew.Pathway', 'PUTATIVE_TARGET.x')]
Targets$pathway[which(Targets$pathway=="apoptosis")] <- "Apoptosis"
Targets$pathway[which(Targets$pathway=="cell cycle")] <- "Cell cycle"
Targets$pathway[which(Targets$pathway=="cell cycle/mitosis")] <- "Cell cycle/mitosis"
Targets$pathway[which(Targets$pathway=="chromain histone acetylation")] <- "Chromain histone acetylation"
Targets$pathway[which(Targets$pathway=="chromatin other")] <- "Chromatin other"
Targets$pathway[which(Targets$pathway=="cytoskeleton")] <- "Cytoskeleton"
Targets$pathway[which(Targets$pathway=="metabolism")] <- "Metabolism"
Targets$pathway[which(Targets$pathway=="other")] <- "Unknown"

Targets <- Targets[which(Targets$pathway %in% c("PI3Kb", "Pi3K/AKT", "TOR signaling")),]
Targets <- Targets[-which(Targets$DRUG_NAME %in% c("PF-4708671", "BYL719", "NVP-BEZ235")),]

load(file="/DrugScreening/AllFits.RData")
Drugs <- aggregate(SDfits$AUC, list(SDfits$Drug, SDfits$Tumour), mean, na.rm=TRUE)
colnames(Drugs) <- c("Drug", "Model", "AUC")
Targets <- Targets[which(Targets$DRUG_NAME %in% Drugs$Drug),]

Targets$Class <- "AKT1"
Targets$Class[which(Targets$DRUG_NAME=="AZD6482")]<- "PI3Kb"
Targets$Class[which(Targets$DRUG_NAME=="AZD8055")]<- "mTOR"
Targets$Class[which(Targets$DRUG_NAME=="GDC0941")]<- "PI3Kalpha"

Drugs <- Drugs[which(Drugs$Drug %in% Targets$DRUG_NAME),]
Drugs <- merge(Drugs, Targets, by.x="Drug", by.y="DRUG_NAME")
Drugs <- aggregate(Drugs$AUC, by=list(Drugs$Class, Drugs$Model), mean)
colnames(Drugs) <- c("Target", "Model", "AUC")


## List of genes
genes <- c("PIK3CA", "PTEN", "PDK1", "AKT1", "AKT2", "AKT3", "TSC1", "TSC2", "RHEB", "MTOR", "RPTOR", "MLST8", "EIF4EBP1", "RPS6KB1")
genes <- rev(genes)
## Expression

load(file="/Expression/PDX_Genes_Expression.RData")
Expression <- PDX
Expression <- Expression[which(rownames(Expression) %in% genes),]
rm(PDX)
SS <- read.csv("/Expression/ExpressionFullSampleSheet.csv", skip=7)
SS <- SS[which(SS$ID %in% colnames(Expression)),]
SS <- SS[match(colnames(Expression), SS$ID),]
ids <-which(SS$TYPE %in% c("PDTX", "PDTC"))
SS <- SS[ids,]
Expression <- Expression[,which(colnames(Expression) %in% SS$ID)]
SS <- SS[match(colnames(Expression), SS$ID),]
SS$Tumour <- factor(SS$Tumour)
Expression <- Expression[,which(!colnames(Expression) %in% rem)]

Expression <- apply(Expression, 1, function(x) {
      tapply(x, SS$Tumour, mean, na.rm=TRUE)
  })
Expression <- t(Expression)
library(mclust)
library(moments)
Exp <- matrix(NA, nrow(Expression), ncol(Expression))
dimnames(Exp) <- dimnames(Expression)
pdf("/Volumes/PDX/Integration/ResultsExpression.pdf", width=12, height=7)
par(mfrow=c(1,2))
for (i in 1:nrow(Expression)) {
    x <- Expression[i,]
    sk <- skewness(x)
    clust <- Mclust(x, G=2)
    plot(clust, what="density")
    cl <- clust$classification
    if (sk > 0) {
        cl <- factor(cl, levels=1:2, labels=c("0", "+"))
    } else {
        cl <- factor(cl, levels=1:2, labels=c("-", "0"))
    }
    Exp[i,] <- as.character(cl)
    boxplot(Expression[i,] ~ Exp[i,],
            main=rownames(Exp)[i])
}
dev.off()

## SNVs
mutations.PDX <- read.table(file="/Exomes/SNVsSummary_SDFiltered.txt", sep="\t", header=T)
rownames(mutations.PDX) <- mutations.PDX$Symbol
mutations.PDX$Symbol <- NULL
SNVs <- mutations.PDX[which(rownames(mutations.PDX) %in% genes),]

## Copy Number

CN <- read.table(file="/GENECNMODEL.txt", header=TRUE, sep="\t")
rownames(CN) <- CN$Symbol
CN$Symbol <- NULL
CN <- CN[which(rownames(CN) %in% genes),]

## Methylation
Meth <- read.table("/Methylation/PromoterModels.txt", header=TRUE, sep="\t")
Meth <- Meth[which(rownames(Meth) %in% genes),]
Meth <- as.matrix(Meth)
MM <- matrix(NA, nrow(Meth), ncol(Meth))
dimnames(MM) <- dimnames(Meth)
MM[which(Meth>50)] <- "YES"
MM[which(Meth<=50)] <- "NO"

## Now some good ol' plotting
library(RColorBrewer)
cols <- brewer.pal(4, "Set1")
Targets <- unique(Drugs$Target)
all.pvals <- list()
all.coefs <- list()
for (i in 1:length(Targets)) {
    pdf(paste("/", Targets[i], "_Alterations.pdf", sep=""), width=10, height=10)
    par(mfrow=c(2,2))
    pvals <- matrix(NA, length(genes), 4)
    coefs <- matrix(0, length(genes), 4)
    rownames(pvals) <- genes
    colnames(pvals) <- c("Exp", "CN", "SNV", "Meth")
    dimnames(coefs) <- dimnames(pvals)
    y <- Drugs[which(Drugs$Target==Targets[i]),]
    y <- data.frame(Model=y$Model, AUC=y$AUC)
    for (j in genes) {
        x <- Exp[j,]
        x <- data.frame(Model=names(x), Exp=x)
        X <- merge(y, x, all=T)
        x <- unlist(CN[j,])
        x <- data.frame(Model=names(x), CN=x)
        X <- merge(X, x, all=T)
        x <- unlist(SNVs[j,])
        x <- data.frame(Model=names(x),
                        SNV=1 * (x!="NO"))
        X <- merge(X, x, all=T)
        x <- Meth[j,]
        x <- data.frame(Model=names(x), Meth=x)
        X <- merge(X, x, all=T)
        X$Exp <- factor(X$Exp, levels=c("-", "0", "+"),
                        labels=c("-", "Normal", "+"))
        X$Exp <- factor(X$Exp)
        X$CN <- factor(X$CN,
                       levels=c("LOSS", "NEUT", "GAIN"))
        X$CN <- factor(X$CN)
        X$Meth <- factor(X$Meth, levels=c("NO", "YES"))
        X$Meth <- factor(X$Meth)
        X$SNV <- factor(X$SNV, levels=c(0, 1),
                        labels=c("NO", "YES"))
        X$SNV <- factor(X$SNV)
        tmp <- try(t.test(AUC ~ Exp, data=X))
        if (class(tmp) != "try-error") {
            boxplot(AUC ~ Exp, data=X, xlab="Expression", main=j, col=cols)
            pvals[j,1] <- tmp$p.value
            coefs[j,1] <- diff(tmp$estimate)
        } else {
            plot.new()
        }
        tmp <- try(summary(lm(AUC ~ CN, data=X)))
        if (class(tmp) != "try-error") {
        boxplot(AUC ~ CN, data=X, xlab="Copy Number", main=j, col=cols)
        pvals[j,2] <- pf(tmp$fstatistic[1],
                         tmp$fstatistic[2],
                         tmp$fstatistic[3],
                         lower.tail=F)
        coefs[j,2] <- coef(tmp)[-1,,drop=F][which.max(abs(coef(tmp)[-1,'Estimate'])),'Estimate']
        } else {
            plot.new()
        }
        tmp <- try(t.test(AUC ~ SNV, data=X))
        if (class(tmp) != "try-error") {
            boxplot(AUC ~ SNV, data=X, xlab="SNVs", main=j, col=cols)
            pvals[j,3] <- tmp$p.value
            coefs[j,3] <- diff(tmp$estimate)
        } else {
            plot.new()
        }
        tmp <- try(t.test(AUC ~ Meth, data=X))
        if (class(tmp) != "try-error") {
        boxplot(AUC ~ Meth, data=X, xlab="Methylation", main=j, col=cols)
        pvals[j,4] <- tmp$p.value
        coefs[j,4] <- diff(tmp$estimate)
        } else {
            plot.new()
        }
    }
    dev.off()
    all.pvals[[Targets[i]]] <- pvals
    all.coefs[[Targets[i]]] <- coefs
}


## Now comes the plotting!
for (i in Targets) {
    pdf(paste("/", i, ".pdf", sep=""), width=6, heigh=7)
    layout(rbind(1,2), height=c(0.8, 0.2), respect=TRUE)
    par(mar=c(1, 6, 3, 1))
    color.code <- rev(brewer.pal(5, "RdBu"))
    breaks <- seq(from=-0.25, to=0.25, length=6)
    image(t(all.coefs[[i]]), breaks=breaks, col=color.code,
      axes=FALSE, cex.lab=2, las=2)
    title(i, line=-3, outer=T)
    box()
    xpos <- 0:(dim(all.coefs[[i]])[2] - 1)/(dim(all.coefs[[i]])[2] - 1)
    ypos <- 0:(dim(all.coefs[[i]])[1] - 1)/(dim(all.coefs[[i]])[1] - 1)
    axis(3, at=xpos, c("Expression", "CNAs", "SNVs", "Meth"))
    axis(2, at=ypos, las=2, genes, cex.lab=2, tick=FALSE)
    ## FDR <- matrix(p.adjust(all.pvals[[i]], "BH"), ncol=4)
    FDR <- all.pvals[[i]]
    FDR[which(is.na(FDR))] <- 1
    for (ro in 1:nrow(FDR)) {
        for (co in 1:ncol(FDR)) {
            if (FDR[ro, co] < 0.05) {
                points(xpos[co], ypos[ro], pch="*", cex=4, col="white")
            }
        }
    }
    par(mar=c(2, 10, 2, 9))
    image(as.matrix(breaks[-1], nrow=1), breaks=breaks, col=color.code,
          axes=FALSE, las=2, main="Difference in AUC")
    xpos <- 0:4/4
    axis(1, xpos, round(breaks[1:5] + diff(breaks)[1]/2, 2), cex.axis=0.9, )
    dev.off()
}
