plot.AUC.group <- function(x, pathway) {
    auc <- x[,grep("AUC", colnames(x))]
    group <- x[,grep("cluster.superv", colnames(x))]
    n <- ncol(auc)
    par(mfrow=c(n, n), oma=c(0, 0, 3, 0), mar=c(1, 1, 1, 1))
    for (i in 1:n) {
        for (j in 1:n) {
            if (i==j) {
                plot(0,0, type="n", xlab="", ylab="", axes=F)
                box()
                text(0,0, sub("AUC.", "", colnames(auc)[i], fixed=T),
                     cex=ifelse(n>5, 1, 3))
            } else if (i<j) {
                plot(auc[,i] ~ auc[,j], pch=19, xlab="", ylab="",
                     xlim=c(0,1), ylim=c(0,1))
            } else {
                all.col <- c("white", brewer.pal(4, "Reds"))
                breaks <- c(-1, 0.5, seq(from=1, to=20, length=3), 100)
                image(table(factor(group[,i], levels=1:8),
                            factor(group[,j], levels=1:8)),
                      breaks=breaks, col=all.col, axes=F)
                x.ticks <- seq(from=0, to=1, length=8)
                y.ticks <- seq(from=0, to=1, length=8)
                axis(1, at=x.ticks, labels=1:8,
                     cex.axis=1.2, las=1)
                axis(2, at=y.ticks, labels=1:8,
                     cex.axis=1.2, las=2)
                box()

            }
        }
    mtext(pathway, cex=2, outer=T)
    }
}

set.seed(43534)
load(file="/DrugScreening/SingleDrugRawData.RData")
AUC$Tumour <- factor(AUC$Tumour)
AUC$Model <- factor(AUC$Model)
######################################################################
######################################################################
## Now isotonic regression
######################################################################
######################################################################


fit.isotonic <- function(x, sample=NA, drug=NA, plot=TRUE) {
    require(flux)
    if (!is.na(sample) & !is.na(drug)) {
        x <- x[which(x$Model==sample & x$DRUG_ID==drug),]
    }
    dose <- unlist(x[,grep("_CONC", colnames(x), fixed=TRUE)])
    y <- as.numeric(unlist(x[grep("_INTENSITY", colnames(x), fixed=TRUE)]))
    lims <- range(c(y, x$Control, x$Blank))
    pos.cont <- rep(x$Control, 5)
    neg.cont <- rep(x$Blank, 5)
    obs.y <- 100 - (100 * y/(pos.cont - neg.cont))
    obs.y <- pmin(obs.y, 100)
    obs.y <- pmax(0, obs.y)
    obs.x <- log(dose)
    obs.data <- data.frame(y=obs.y, x=obs.x)
    res <-isoreg(x=obs.data$x, y=obs.data$y)
    error <- mean(resid(res)^2)
    dif.doses <- length(unique(obs.x))
    fit.y <- res$yf[seq(from=1, length=dif.doses,
                        by=nrow(obs.data)/dif.doses)]
    fit.x <- unique(sort(obs.x, decreasing=F))
    AUC <- auc(fit.x, fit.y)
    AUC <- AUC / (diff(range(obs.x))*100)
    spli <- smooth.spline(x=fit.x, y=fit.y, all.knots=TRUE, df=2)
    iC50 <- predict(spli, seq(from=-100, to=100, length=1000))
    iC50 <- iC50$x[which.min(abs(50-iC50$y))]
    ## Now we need to make sure that we only get 5 values
    if (length(fit.y) == 10) {
        fit.y <- fit.y[seq(from=2, to=10, by=2)]
        fit.x <- fit.x[seq(from=2, to=10, by=2)]
    }
    if (plot) {
        plot(fit.x, fit.y, type="l", main=paste(sample, drug),
             xlab="Dose", ylab="Response",
             ylim=c(0,100))
        points(obs.x, obs.y, col=1:nrow(x), pch=19)
    }
    list(fit=fit.y, error=error, AUC=AUC, iC50=exp(iC50))
}

all.fits <- list()
errors <- list()
all.AUC <- c()
all.iC50 <- c()
all.Models <- c()
all.Drugs <- c()
counter <- 1
for (cl in sort(as.character(unique(AUC$Model)))) {
    for (dr in sort(as.character(unique(AUC$DRUG_ID)))) {
        tot <- length(which(AUC$Model==cl & AUC$DRUG_ID==dr))
        if (tot > 0) {
            tmp <- fit.isotonic(AUC, sample=cl, drug=dr)
            all.fits[[counter]] <- tmp$fit
            errors[[counter]] <- tmp$error
            all.AUC[[counter]] <- tmp$AUC
            all.iC50[[counter]] <- tmp$iC50
            all.Models <- c(all.Models, cl)
            all.Drugs <- c(all.Drugs, dr)
            counter <- counter + 1
            cat(dr, " done\n")
        }
    }
    cat(cl, " done\n")
}

all.fits <- do.call("rbind", all.fits)
errors <- do.call("rbind", errors)
model.fits <- all.fits

res <- data.frame(Model=all.Models, Drug=all.Drugs, AUC=all.AUC,
                  iC50=all.iC50)
doses <- aggregate(AUC[,c('D1_CONC', 'D5_CONC')], by=list(Drug=AUC$DRUG_ID), mean)
doses <- unique(doses)
res <- merge(res, doses)

a <- log(res$iC50) - log(res$D5_CONC)
b <- log(res$D1_CONC) - log(res$D5_CONC)
res$perc.iC50 <- (100 * a / b)
SDfits <- res
T.names <- read.table("/PDTX/DrugScreening/SampleSheetDrugs.txt", header=TRUE, sep="\t")
T.names <- unique(T.names)
SDfits <- merge(SDfits, T.names, all.x=T)

all.fits <- list()
errors <- list()
all.AUC <- c()
all.iC50 <- c()
for (i in 1:nrow(AUC)) {
    tmp <- fit.isotonic(AUC[i,], plot=F)
    all.fits[[i]] <- tmp$fit
    errors[[i]] <- tmp$error
    all.AUC[[i]] <- tmp$AUC
    all.iC50[[i]] <- tmp$iC50
    cat(i, " done\n")
}

all.fits <- do.call("rbind", all.fits)
errors <- do.call("rbind", errors)

res <- data.frame(Model=AUC$Model, Drug=AUC$DRUG_ID, AUC=all.AUC,
                  iC50=all.iC50, Error=errors)
doses <- aggregate(AUC[,c('D1_CONC', 'D5_CONC')], by=list(Drug=AUC$DRUG_ID), mean)
doses <- unique(doses)
res <- merge(res, doses)

a <- log(res$iC50) - log(res$D5_CONC)
b <- log(res$D1_CONC) - log(res$D5_CONC)
res$perc.iC50 <- (100 * a / b)

SDfits.individuals <- res

sd.AUC <- aggregate(SDfits.individuals$AUC,
                         by=list(Model=SDfits.individuals$Model,
                         Drug=SDfits.individuals$Drug),
                            sd, na.rm=T)
sd.iC50 <- aggregate(SDfits.individuals$perc.iC50,
                         by=list(Model=SDfits.individuals$Model,
                         Drug=SDfits.individuals$Drug),
                            sd, na.rm=T)

## Now plots

pdf("/DrugScreening/SingleAgentFits.pdf", width=12, height=12)
par(oma=c(3, 7, 1, 1), mfrow=c(1,2), mai=c(0.9, 1.2, 0.35, 0.9))
for (i in sort(unique(as.character(SDfits$Drug)))) {
    tmp <- subset(SDfits, Drug==i)
    tmp$Name <- tmp$ID
    tmp2 <- aggregate(tmp$AUC, by=list(Tumour=tmp$Tumour,
                               Drug=tmp$Drug), FUN=mean)
    lic <- subset(sd.AUC, Drug==i)
    colnames(tmp2)[3] <- "AUC"
    tmp2$Model <- tmp2$Tumour
    tmp2$Name <- tmp2$Model
    tmp2$Name <- paste(tmp2$Model, "                ")
    tmp$Class <- "PDX"
    tmp2$Class <- "Mean"
    tmp2$lwic <- NA
    tmp2$upic <- NA
    tmp <- merge(tmp, lic, all.x=TRUE)
    tmp$lwic <- tmp$AUC - 1.96 * tmp$x
    tmp$upic <- tmp$AUC + 1.96 * tmp$x
    tmp$lwic <- pmax(0, tmp$lwic)
    tmp$upic <- pmin(tmp$upic, 1)
    tmp <- tmp[,colnames(tmp2)]
    tmp <- rbind(tmp, tmp2)
    tmp$Model <- as.character(tmp$Model)
    tmp$Tumour <- as.character(tmp$Tumour)
    tmp <- tmp[order(tmp$Tumour, tmp$Class, tmp$Model),]
    tmp$Name <- factor(tmp$Name, levels=rev(unique(tmp$Name)))
    test <- tmp
    test$auc[test$Class=="Mean"] <- NA
    stripchart(AUC ~ Name, data=test, main=i, las=1,
               vertical=FALSE, method="overplot", pch=20, col="blue", axes=F, xlab="AUC", xlim=c(0,1))
    stripchart(lwic ~ Name, data=test, main=i, las=1, add=TRUE,
               vertical=FALSE, method="overplot", pch="(", col="blue")
    stripchart(upic ~ Name, data=test, main=i, las=1, add=TRUE,
               vertical=FALSE, method="overplot", pch=")", col="blue")
    for (k in 1:nrow(test)) {
        lines(c(test$lwic[k], test$upic[k]), c(test$Name[k], test$Name[k]))
    }

    test <- tmp
    test$AUC[test$Class=="PDX"] <- NA
    stripchart(AUC ~ Name, data=test, main=i, las=1,
               vertical=FALSE, method="overplot", pch=18, col="red", axes=F, add=T, cex=1.5, xlab="AUC")
    axis(2, at=1:length(unique(tmp$Name)), labels=as.character(rev(unique(tmp$Name))), las=2, xlim=c(0,1))
    axis(1)
    box()
    abline(v=0.2, lty=3, col=2, lwd=2)
    abline(h=grep(" ", rev(unique(tmp$Name))), lty=2)
    ## Now ED50

    tmp <- subset(SDfits, Drug==i)
    tmp$Name <- tmp$ID
    tmp2 <- aggregate(tmp$perc.iC50, by=list(Tumour=tmp$Tumour,
                               Drug=tmp$Drug), FUN=mean)
    tmp2$x <- pmax(tmp2$x, -50)
    tmp2$x <- pmin(tmp2$x, 150)
    lic <- subset(sd.iC50, Drug==i)
    colnames(tmp2)[3] <- "perc.iC50"
    tmp2$Model <- tmp2$Tumour
    tmp2$Name <- tmp2$Model
    tmp2$Name <- paste(tmp2$Model, "                ")
    tmp$Class <- "PDX"
    tmp2$Class <- "Mean"
    tmp2$lwic <- NA
    tmp2$upic <- NA
    tmp <- merge(tmp, lic, all.x=TRUE)
    tmp$lwic <- tmp$perc.iC50 - 1.96 * tmp$x
    tmp$upic <- tmp$perc.iC50 + 1.96 * tmp$x
    tmp$perc.iC50 <- pmax(tmp$perc.iC50, -50)
    tmp$perc.iC50 <- pmin(tmp$perc.iC50, 150)
    tmp$lwic <- pmax(tmp$lwic, -50)
    tmp$upic <- pmin(tmp$upic, 150)
    tmp <- tmp[,colnames(tmp2)]
    tmp <- rbind(tmp, tmp2)
    tmp$Model <- as.character(tmp$Model)
    tmp$Tumour <- as.character(tmp$Tumour)
    tmp <- tmp[order(tmp$Tumour, tmp$Class, tmp$Model),]
    tmp$Name <- factor(tmp$Name, levels=rev(unique(tmp$Name)))
    test <- tmp
    test$auc[test$Class=="Mean"] <- NA
    stripchart(perc.iC50 ~ Name, data=test, main=i, las=1,
               vertical=FALSE, method="overplot", pch=20,
               col="blue", axes=F, xlab="iC50", xlim=c(-50,150))
    stripchart(lwic ~ Name, data=test, main=i, las=1, add=TRUE,
               vertical=FALSE, method="overplot", pch="(", col="blue")
    stripchart(upic ~ Name, data=test, main=i, las=1, add=TRUE,
               vertical=FALSE, method="overplot", pch=")", col="blue")
    for (k in 1:nrow(test)) {
        lines(c(test$lwic[k], test$upic[k]), c(test$Name[k], test$Name[k]))
    }

    test <- tmp
    test$perc.iC50[test$Class=="PDX"] <- NA
    stripchart(perc.iC50 ~ Name, data=test, main=i, las=1,
               vertical=FALSE, method="overplot", pch=18, col="red", axes=F, add=T, cex=1.5, xlab="iC50")
    axis(2, at=1:length(unique(tmp$Name)), labels=as.character(rev(unique(tmp$Name))), las=2)
    axis(1, c(-50, 0, 50, 100, 150), c("<-50%", "0%", "50%", "100%", ">150%"))
    box()
    abline(v=c(0, 50, 100), lty=3, col=2, lwd=2)
    abline(h=grep(" ", rev(unique(tmp$Name))), lty=2)
}
dev.off()


pdf("/DrugScreening/SingleAgentFits_PERMODEL.pdf", width=12, height=16)
par(oma=c(3, 7, 1, 1), mfrow=c(1,2), mai=c(0.9, 1.2, 0.35, 0.9))
for (i in sort(unique(as.character(SDfits$ID)))) {
    i <- as.character(SDfits$Model)[which(SDfits$ID==i)[1]]
    tmp <- subset(SDfits, Model==i)
    tmp$Name <- tmp$ID
    lic <- subset(sd.AUC, Model==i)
    tmp <- merge(tmp, lic, all.x=TRUE)
    tmp$lwic <- tmp$AUC - 1.96 * tmp$x
    tmp$upic <- tmp$AUC + 1.96 * tmp$x
    tmp$lwic <- pmax(0, tmp$lwic)
    tmp$upic <- pmin(tmp$upic, 1)
    tmp$Model <- as.character(tmp$Model)
    tmp$Tumour <- as.character(tmp$Tumour)
    tmp <- tmp[order(tmp$Tumour, tmp$Model),]
    tmp$Name <- factor(tmp$Name, levels=rev(unique(tmp$Name)))
    tmp$Drug <- factor(tmp$Drug, levels=rev(unique(tmp$Drug)))
    test <- tmp
    stripchart(AUC ~ Drug, data=test, main=tmp$Name[1], las=1,
               vertical=FALSE, method="overplot", pch=20, col="blue", axes=F, xlab="AUC", xlim=c(0,1))
    stripchart(lwic ~ Drug, data=test, las=1, add=TRUE,
               vertical=FALSE, method="overplot", pch="(", col="blue")
    stripchart(upic ~ Drug, data=test, las=1, add=TRUE,
               vertical=FALSE, method="overplot", pch=")", col="blue")
    for (k in 1:nrow(test)) {
        lines(c(test$lwic[k], test$upic[k]), c(test$Drug[k], test$Drug[k]))
    }

    axis(2, at=1:length(unique(test$Drug)), labels=as.character(rev(unique(test$Drug))), las=2, xlim=c(0,1))
    axis(1)
    box()
    abline(v=0.2, lty=3, col=2, lwd=2)
    abline(h=grep(" ", rev(unique(tmp$Name))), lty=2)

    ## Now ED50

    tmp <- subset(SDfits, Model==i)
    tmp$Name <- tmp$ID
    lic <- subset(sd.iC50, Model==i)
    tmp <- merge(tmp, lic, all.x=TRUE)
    tmp$lwic <- tmp$perc.iC50 - 1.96 * tmp$x
    tmp$upic <- tmp$perc.iC50 + 1.96 * tmp$x
    tmp$perc.iC50 <- pmax(tmp$perc.iC50, -50)
    tmp$perc.iC50 <- pmin(tmp$perc.iC50, 150)
    tmp$lwic <- pmax(tmp$lwic, -50)
    tmp$upic <- pmin(tmp$upic, 150)
    tmp$Model <- as.character(tmp$Model)
    tmp$Tumour <- as.character(tmp$Tumour)
    tmp <- tmp[order(tmp$Tumour, tmp$Model),]
    tmp$Name <- factor(tmp$Name, levels=rev(unique(tmp$Name)))
    tmp$Drug <- factor(tmp$Drug, levels=rev(unique(tmp$Drug)))
    test <- tmp
    stripchart(perc.iC50 ~ Drug, data=test, main=tmp$Name[1], las=1,
               vertical=FALSE, method="overplot", pch=20,
               col="blue", axes=F, xlab="iC50", xlim=c(-50,150))
    stripchart(lwic ~ Drug, data=test, las=1, add=TRUE,
               vertical=FALSE, method="overplot", pch="(", col="blue")
    stripchart(upic ~ Drug, data=test, las=1, add=TRUE,
               vertical=FALSE, method="overplot", pch=")", col="blue")
    for (k in 1:nrow(test)) {
        lines(c(test$lwic[k], test$upic[k]), c(test$Drug[k], test$Drug[k]))
    }

    axis(2, at=1:length(unique(tmp$Drug)), labels=as.character(rev(unique(tmp$Drug))), las=2)
    axis(1, c(-50, 0, 50, 100, 150), c("<-50%", "0%", "50%", "100%", ">150%"))
    box()
    abline(v=c(0, 50, 100), lty=3, col=2, lwd=2)
    abline(h=grep(" ", rev(unique(tmp$Name))), lty=2)
    cat(i, " done\n")
}
dev.off()

## Downstream stuff that we need to decide


isot.dist <- function(x, sens) {
    res <- matrix(NA, nrow(x), nrow(x))
    for (i in 1:nrow(x)) {
        for (j in 1:nrow(x)) {
            x1 <- x[i,]
            x2 <- x[j,]
            res[i,j] <- sum((x1-x2)^2)
        }
    }
    as.dist(res)
}

tmp <- isot.dist(model.fits)

feo <- hclust(tmp, method="ward")


own.cl <- cutree(feo, 8)
par(mfrow=c(4, 2))
for (i in unique(own.cl)) {
    matplot(t(model.fits[which(own.cl==i),]), type="l", ylim=c(0, 100))
}

own.cl.sorted <- rep(NA, length(own.cl))
own.cl.sorted[which(own.cl==2)] <- 1
own.cl.sorted[which(own.cl==3)] <- 2
own.cl.sorted[which(own.cl==4)] <- 3
own.cl.sorted[which(own.cl==7)] <- 4
own.cl.sorted[which(own.cl==1)] <- 5
own.cl.sorted[which(own.cl==6)] <- 6
own.cl.sorted[which(own.cl==8)] <- 7
own.cl.sorted[which(own.cl==5)] <- 8
par(mfrow=c(4, 2))
for (i in sort(unique(own.cl.sorted))) {
    matplot(t(model.fits[which(own.cl.sorted==i),]), type="l", ylim=c(0, 100),
            col=1)
}

test.disc <- function(x) {
    gs <- rbind(c(0, 0, 0, 0, 0),
                c(0, 0, 0, 0, 50),
                c(0, 0, 0, 50, 90),
                c(0, 0, 30, 50, 90),
                c(0, 25, 50, 75, 100),
                c(0, 50, 60, 80, 100),
                c(60, 60, 60, 60, 60),
                c(100, 100, 100, 100, 100))
    res <- numeric(nrow(x))
    for (i in 1:nrow(x)) {
        res[i] <- which.min(apply(gs, 1, function(y) sum((y- x[i,])^2)))
    }
    res
}
res <- test.disc(model.fits)

cl <- data.frame(Model = all.Models, Drug = all.Drugs,
                 cluster.superv=res, cluster.unsuperv=own.cl.sorted)
SDfits <- merge(SDfits, cl)

## Correlation plots
X <- NULL
for (i in unique(SDfits.individuals$Drug)) {
    models <- unique(SDfits.individuals$Model[which(SDfits.individuals$Drug==i)])
    for (j in models) {
        x <- SDfits.individuals[which(SDfits.individuals$Drug==i & SDfits.individuals$Model ==j),]
        if (nrow(x)>1) {
            X <- rbind(X, t(combn(x$AUC, 2)))
        }
    }
}

Y <- NULL
for (i in unique(SDfits$Drug)) {
    models <- unique(SDfits$Tumour[which(SDfits$Drug==i)])
    for (j in models) {
        x <- SDfits[which(SDfits$Drug==i & SDfits$Tumour ==j),]
        if (nrow(x)>1) {
            Y <- rbind(Y, t(combn(x$AUC, 2)))
        }
    }
}

pdf(“/DrugScreening/Replicates_AUC.pdf", width=10, height=6)
par(mfrow=c(1,2))
plot(X, main="Technical Replicates", xlim=c(0,1), ylim=c(0,1), xlab="",
     ylab="", pch=19, cex=0.5)
text(0.2, 1, paste("r=", round(cor(X)[1,2], 3), sep=""))
plot(Y, main="Biological Replicates", xlim=c(0,1), ylim=c(0,1), xlab="",
     ylab="", pch=19, cex=0.5)
text(0.2, 1, paste("r=", round(cor(Y)[1,2], 3), sep=""))
dev.off()

SDfits$ID <- factor(SDfits$ID)
X.sup <- xtabs(SDfits$cluster.superv ~ SDfits$ID+ SDfits$Drug)
X.sup[which(X.sup==0)] <- NA
X.unsup <- xtabs(SDfits$cluster.unsuperv ~ SDfits$ID+ SDfits$Drug)
X.unsup[which(X.unsup==0)] <- NA

save(SDfits, file="/DrugScreening/AllFits.RData")


library(RColorBrewer)
all.col <- c("grey", brewer.pal(7, "Greens"))
pdf("/Volumes/PDX/DrugScreening/isotonicClustering.pdf", width=20, height=40)
br <- c(-0.5, 0.5, 1.5)
col <- c("white", "darkgreen")
layout(matrix(1:16, ncol=2, byrow=T), widths=c(0.4, 0.6))
for (i in 1:8) {
    matplot(t(model.fits[which(res==i),]), type="l", ylim=c(0, 100),
            col=all.col[i], xlab="Dose", ylab="Response", main=paste("Cluster", i), lwd=3)
    sub.X <- matrix(0, nrow(X.sup), ncol(X.sup))
    sub.X[which(X.sup==i)] <- 1
    dimnames(sub.X) <- dimnames(X.sup)
    sub.X <- t(sub.X)
    image(sub.X, breaks=br, col=col, axes=F)
    x.ticks <- seq(from=0, to=1, length=nrow(sub.X))
    y.ticks <- seq(from=0, to=1, length=ncol(sub.X))
    axis(1, at=x.ticks, labels=rownames(sub.X),
         cex.axis=1.2, las=2)
    axis(2, at=y.ticks, labels=colnames(sub.X),
         cex.axis=1.2, las=2)
}
dev.off()


cum.propos <- apply(X.sup, 2, function(x)
                    cumsum(prop.table(table(factor(x, levels=1:8)))))

class.drugs <- rep(2, ncol(X.sup))
class.drugs[which(cum.propos[2,] > 0.5)] <- 3
class.drugs[which(cum.propos[7,] < 0.6)] <- 1

ids <- order(class.drugs, cum.propos[1,], cum.propos[8,], apply(X.sup, 2, function(x)
                                                mean(x==8, na.rm=T)), decreasing=T)
extremes <- apply(X.sup, 2, function(x) prop.table(table(factor(x, levels=1:8))))
inactive <- apply(extremes, 2, function(x) {
    1 * (x[1] > 0.80)
})
toxic <- apply(extremes, 2, function(x) {
    1 * (sum(x[7:8])==1)
})

Targets<- read.table("~/Documents/Projects/PDTX/DrugScreening/drug%20annotations_final.txt", header=TRUE, sep="\t")
Targets <- Targets[,c('DRUG_NAME', 'Matthew.Pathway', 'PUTATIVE_TARGET.x')]
colnames(Targets) <- c("Drug", "Pathway", "Target")
Targets$Pathway[which(Targets$Pathway=="other")] <- "Unknown"
Targets$Pathway <- factor(Targets$Pathway)
Targets <- unique(Targets)
Targets <- Targets[match(Targets$Drug, colnames(extremes)),]
colnames(extremes)[which(colnames(extremes)=="Olaparib(1495) + Temozolomide(1375)")] <-
    "Olaparib+Temozolomide"
colnames(extremes)[which(colnames(extremes)=="mirin")] <-
    "Mirin"


pdf(“/DrugScreening/DrugsSorted_V2.pdf", width=12, height=18)
par(oma=c(1, 8, 0, 28))
bars.names <- paste(Targets$Target, sep="")
x <- barplot(100*extremes[,rev(ids)], horiz=T, col=all.col, las=1, xlab="Percentage", cex.lab=2, cex.axis=1.6, axes=F, font=2)
axis(1, cex.axis=1.6, cex.lab=2)
axis(4, cex.lab=2, at=x, bars.names[rev(ids)], las=2,
     tick=FALSE)
dev.off()



pdf("/isotonicClusteringPieChartSorted.pdf", width=11, height=9)
all.col <- c("grey", brewer.pal(7, "Greens"))
par(mfrow=c(6, 7), mar=c(1,0,1,0))
for (i in colnames(X.sup)[ids]) {
    tmp <- prop.table(table(factor(X.sup[,i], levels=1:8)))
    pie(tmp, col=all.col, main=i, labels=NA)
}
par(mfrow=c(4, 2))
for (i in 1:8) {
    matplot(t(model.fits[which(res==i),]), type="l", ylim=c(0, 100),
            col=all.col[i])
}
dev.off()

pdf("/DrugScreening/Heatmaps_sup.pdf", width=12, height=12)
par(oma=c(3, 7, 1, 1))
na.cols <- apply(X.sup, 2, function(x) mean(is.na(x)))
na.rows <- apply(X.sup, 1, function(x) mean(is.na(x)))


sub.X <- X.sup[na.rows < 0.65, na.cols < 0.65]
heatmap(t(sub.X),
        breaks=seq(from=0.5, to=8.5, by=1), col=all.col, scale="none")

Targets <- read.table("/drug_key_annotations_Jan_2015.txt", header=T, sep="\t")
Targets <- Targets[which(Targets[,2] %in% colnames(sub.X)),]
Targets <- Targets[match(colnames(sub.X), Targets[,2]),]
source("../oscar_heatmaplus.R")
library(heatmap.plus)

vars <- Targets[,4]
vars <- as.character(as.numeric(factor(vars)))
heatmap(as.matrix(t(sub.X)), RowSideColors=as.matrix(vars),
             breaks=seq(from=0.5, to=8.5, by=1), col=all.col,
          scale="none", distfun=function(x) {
        as.dist(1 - cor(t(x),
                        use="pairwise.complete.obs", method="spearman"))
        },
          hclustfun=function(x,...) hclust(x, method="ward"),
          margins=c(8,8), labRow=paste(Targets[,2], Targets[,9]))
dev.off()
save(SDfits, SDfits.individuals, sd.AUC, sd.iC50, file="//DrugScreening/SingleAgentFits.RData")

res <- aggregate(SDfits$AUC, by=list(SDfits$Drug, SDfits$Tumour), FUN=mean)
colnames(res) <- c("Drug", "Model", "AUC")
save(res, file="//DrugScreening/AUCTumours.RData")



Targets <- read.table("drug%20annotations_final.txt", header=T, sep="\t", stringsAsFactors=)
Targets <- Targets[,c('DRUG_NAME', 'Matthew.Pathway')]
colnames(Targets) <- c("Drug", "Pathway")
Targets$Pathway[which(Targets$Pathway=="other")] <- "Unknown"
Targets$Pathway <- factor(Targets$Pathway)
Targets <- unique(Targets)
SDfits <- merge(SDfits, Targets, all.x=T)

SDfits$Pathway <- toupper(SDfits$Pathway)
pdf("/Drugscreening/Correlation_Drugs_Pathways.pdf", width=12, height=9)
ids <- sort(unique(as.character(SDfits$Pathway)))
for (i in sort(ids[which(ids!="UNKNOWN")])) {
    x <- SDfits[which(SDfits$Pathway==i), c('Drug', 'ID',
                      'AUC', 'cluster.superv')]
    if (length(unique(x$Drug))>1) {
        tmp <- reshape(x, v.names=c("AUC", "cluster.superv"), timevar="Drug",
                idvar="ID", direction="wide")
        ## plot.AUC.group(tmp, i)
        feo <-tmp[,grep("AUC", colnames(tmp))]
        colnames(feo) <- sub("AUC.", "", colnames(feo), fixed=TRUE)
        pairs(feo, lower.panel=NULL, pch=19, cex=1.5, main=i)
    }
}
dev.off()

pdf("/Drugscreening/Correlation_Drugs_PI3KmTOR.pdf", width=12, height=9)
ids <- sort(unique(as.character(SDfits$Pathway)))
x <- SDfits[which(SDfits$Pathway %in% c("TOR SIGNALING", "PI3K SIGNALING")), c('Drug', 'ID',
                       'AUC', 'cluster.superv')]
    if (length(unique(x$Drug))>1) {
        tmp <- reshape(x, v.names=c("AUC", "cluster.superv"), timevar="Drug",
                idvar="ID", direction="wide")
        ## plot.AUC.group(tmp, i)
        feo <-tmp[,grep("AUC", colnames(tmp))]
        colnames(feo) <- sub("AUC.", "", colnames(feo), fixed=TRUE)
        pairs(feo, lower.panel=NULL, pch=19, cex=1.5, main="PI3K/AKT/mTOR")
    }
dev.off()

