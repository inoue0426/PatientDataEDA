extract.data.combo <- function(X, drug.set.id, position, model) {
    all.res <-  NULL
    all.Y <- X[which(X$DRUG_SET_ID==drug.set.id & X$mp==position &
                 X$Model==model),]
    if (nrow(all.Y)>0) {
        for (bc in unique(all.Y$BARCODE)) {
            Y <- all.Y[which(all.Y$BARCODE==bc),]
            Y$P_ROW <- factor(Y$P_ROW)
            Y$P_COLUMN <- factor(Y$P_COLUMN)
            val <- xtabs(INTENSITY ~ P_ROW + P_COLUMN, data=Y)
            neg.controls <- X[which(X$DRUG_SET_ID==drug.set.id &
                                    X$Model==model),]
            neg.controls <- xtabs(INTENSITY ~ P_ROW + P_COLUMN,
                                  data=neg.controls)
            neg.controls <- neg.controls[,'1']
            neg.controls <- mean(neg.controls)
            if (position %in% c("A1", "B1", "C1")) {
                pos.controls <- c(val[,1], val[1,-1], val[2,2])
            } else {
                pos.controls <- c(val[,1], val[7,-1], val[1,2])
            }
            pos.controls <- mean(pos.controls)

            ## get concentrations
            conc <- read.csv("/Volumes/CLUS_BACKUP/PDX/PDX/DrugsPanel/Combos/combos_maxconc.txt", header=T, sep="\t", stringsAsFactors=FALSE)
    conc <- conc[which(conc$drug_set_id==drug.set.id),]
            Codes <- read.csv("/Volumes/CLUS_BACKUP/PDX/PDX/DrugsPanel/drug_mapping.csv", stringsAsFactors=FALSE)
            Codes <- unique(Codes)
            conc <- merge(conc, Codes, by.x="drug_id", by.y="DRUG_ID")
            drug.name.row <- conc$DRUG_NAME[which(conc$micronic_position==position)]
            MAX.CONC.row <- conc$working_stock_conc[which(conc$micronic_position==position)]
            col.index <- paste(sapply(strsplit(position, split=""),
                              function(x) x[1]), "3", sep="")
            drug.name.col <- conc$DRUG_NAME[which(conc$micronic_position ==
                                          col.index)]
            MAX.CONC.col <- conc$working_stock_conc[which(conc$micronic_position ==
                                                  col.index)]
            CONCS.row <- MAX.CONC.row / c(1, 4, 16, 64, 256)
            CONCS.col <- MAX.CONC.col / c(1, 4, 16, 64, 256)

            ## Drug on the row
            res <- NULL
            res$DRUG_SET <- drug.set.id
            res$Model <- model
            res$Barcode <- bc
            res$Drug <- rep(drug.name.row, 6)
            res$Anchor <- rep(drug.name.col, 6)
            res <- as.data.frame(res)
            res$Dose <- c(NA, CONCS.col)
            res$y1 <- NA
            res$y2 <- NA
            res$y3 <- NA
            res$y4 <- NA
            res$y5 <- NA
            res$MAX_CONC <- max(CONCS.row)
            for (i in 0:length(CONCS.col)) {
                obs.x <- CONCS.row
                if (position %in% c("A1", "B1", "C1")) {
                    y <- val[2+i,3:7]
                } else {
                    y <- val[1+i,3:7]
                }
                obs.y <- 100 - (100 * y/(pos.controls - neg.controls))
                obs.y <- pmin(obs.y, 100)
                obs.y <- pmax(0, obs.y)
                res[i+1, c('y1', 'y2', 'y3', 'y4', 'y5')] <- obs.y
    }
    res.row <- res

    ## Drug on the column
            res <- NULL
            res$DRUG_SET <- drug.set.id
            res$Model <- model
            res$Drug <- rep(drug.name.col, 6)
            res$Barcode <- bc
            res$Anchor <- rep(drug.name.row, 6)
            res <- as.data.frame(res)
            res$Dose <- c(NA, CONCS.row)
            res$y1 <- NA
            res$y2 <- NA
            res$y3 <- NA
            res$y4 <- NA
            res$y5 <- NA
            res$MAX_CONC <- max(CONCS.col)
            for (i in 0:length(CONCS.row)) {
                obs.x <- CONCS.col
                if (position %in% c("A1", "B1", "C1")) {
                    y <- val[3:7,2+i]
                } else {
                    y <- val[2:6,2+i]
                }
                obs.y <- 100 - (100 * y/(pos.controls - neg.controls))
                obs.y <- pmin(obs.y, 100)
                obs.y <- pmax(0, obs.y)
                res[i+1, c('y1', 'y2', 'y3', 'y4', 'y5')] <- obs.y
            }
            res.col <- res
            res <- rbind(res.row, res.col)
            all.res <- rbind(all.res, res)
        }
        all.res
    }

}

fit.combo <- function(x) {
    if (nrow(x)>0) {
        counter <- 1
        nls.obj <- list()
        all.tmp <- NULL
        CONCS <- x$MAX_CONC[1] / c(1, 4, 16, 64, 256)
        CONCS <- log(CONCS)
        ids <- which(is.na(sub.x$Dose))
        y <- as.matrix(x[ids,c('y1', 'y2', 'y3', 'y4', 'y5')])
        dim(y) <- NULL
        dose <- rep(CONCS, rep(length(ids), length(CONCS)))
        data <- data.frame(y=y, x=dose)
        tmp <- fit.Richards(data, method=1, plot.initial=FALSE)
        nls.obj[[counter]] <- tmp
        counter <- counter + 1
        tmp <- data.frame(Model=sub.x$Model[1], Barcode=sub.x$Barcode[1],
                          Drug=sub.x$Drug[1], Anchor=sub.x$Anchor[1],
                          Dose=NA, MAX_CONC=sub.x$MAX_CONC[1],
                          e=coef(tmp)['e'], b=coef(tmp)['b'],
                          alpha=coef(tmp)['alpha'])
        all.tmp <- rbind(all.tmp, tmp)
        for (i in unique(sub.x$Dose[which(!is.na(sub.x$Dose))])) {
            ids <- which(sub.x$Dose==i)
            y <- as.matrix(x[ids,c('y1', 'y2', 'y3', 'y4', 'y5')])
            dim(y) <- NULL
            dose <- rep(CONCS, rep(length(ids), length(CONCS)))
            data <- data.frame(y=y, x=dose)
            tmp <- fit.Richards(data, method=1, plot.initial=FALSE)
            nls.obj[[counter]] <- tmp
            counter <- counter + 1
            tmp <- data.frame(Model=sub.x$Model[1],
                              Barcode=sub.x$Barcode[1],
                              Drug=sub.x$Drug[1], Anchor=sub.x$Anchor[1],
                              Dose=i, MAX_CONC=sub.x$MAX_CONC[1],
                              e=coef(tmp)['e'], b=coef(tmp)['b'],
                              alpha=coef(tmp)['alpha'])
            all.tmp <- rbind(all.tmp, tmp)
        }
        list(nls.obj=nls.obj, coefs=all.tmp)
    }
}

plot.combo <- function(x.fitted, x.raw) {
    if (nrow(x.fitted)>0) {
        CONC <- x.fitted$MAX_CONC[1] / c(1, 4, 16, 64, 256)
        CONC <- log(CONC)
        ids <- which(is.na(x.fitted$Dose))
        plot.Richards(range(CONC), c("e"=x.fitted[ids,'e'],
                                 "b"=x.fitted[ids,'b'],
                                 "alpha"=x.fitted[ids, 'alpha']),
                  xlab="log-dose",
                  main=paste(x.fitted$Model[1], x.fitted$Drug[1]))
        obs <- x.raw[which(x.raw$Model==x.fitted$Model[1] &
                       x.raw$Drug==x.fitted$Drug[1] &
                       x.raw$Anchor==x.fitted$Anchor[1] &
                       is.na(x.raw$Dose)),]
    y <- as.matrix(obs[,c('y1', 'y2', 'y3', 'y4', 'y5')])
    dim(y) <- NULL
    dose <- rep(CONC, rep(nrow(obs), length(CONC)))
    data <- data.frame(y=y, x=dose)
    points(data$x, data$y, pch=19)
    colors.plot <- c("blue", "red", "green", "orange", "violet")
    counter <- 1
    for (i in sort(unique(x.fitted$Dose[which(!is.na(x.fitted$Dose))]))) {
        ids <- which(x.fitted$Dose==i)
        plot.Richards(range(CONC), c("e"=x.fitted[ids,'e'],
                                     "b"=x.fitted[ids,'b'],
                                     "alpha"=x.fitted[ids, 'alpha']),
                      add=T, col=colors.plot[counter])

        obs <- x.raw[which(x.raw$Model==x.fitted$Model[1] &
                       x.raw$Drug==x.fitted$Drug[1] &
                       x.raw$Anchor==x.fitted$Anchor[1] &
                       x.raw$Dose==i),]
        y <- as.matrix(obs[,c('y1', 'y2', 'y3', 'y4', 'y5')])
        dim(y) <- NULL
        dose <- rep(CONC, rep(nrow(obs), length(CONC)))
        data <- data.frame(y=y, x=dose)
        points(data$x, data$y, pch=19, col=colors.plot[counter])
        counter <- counter + 1
    }
    legend("bottomright", lwd=2, col=c(1, colors.plot),
           paste(x.fitted$Anchor[1], "Dose", c(0:5)))
}
}





summarize.combo <- function(Y, dose.1=0.5, dose.2=6) {
    neg.controls <-Y[2:8,1]
    tmp <- Y[2:8,2:9]
    pos.controls <- c(tmp[1,], tmp[-1,1], tmp[-1,8], tmp[2,2])
    X <- tmp[-1,-c(1,6)]
    X[1,1] <- NA
    rownames(X) <- c("", I(dose.1/c(1, 4, 16, 64, 256)))
    colnames(X) <- c("", I(dose.2/c(1, 4, 16, 64, 256)))
    par(mfrow=c(1,2))
    lims <- c(min(min(X, na.rm=T), min(neg.controls)),
              max(max(X, na.rm=T), max(pos.controls)))
    plot(colnames(X),X[1,], type='o', ylab="Intensity",
         xlab="log dose Getifnib", main="Getifnib", ylim=lims)
    lines(colnames(X),X[2,], type='o', col=2)
    lines(colnames(X),X[3,], type='o', col=3)
    lines(colnames(X),X[4,], type='o', col=4)
    lines(colnames(X),X[5,], type='o', col=5)
    lines(colnames(X),X[6,], type='o', col=6)
    abline(h=mean(pos.controls), col=2)
    abline(h=mean(neg.controls), col=2)
    legend("topright", col=1:6, lwd=2, legend=
           c("No Cisplatin", paste0("Dose", 1:5, " Cisplatin")))
    plot(rownames(X),X[, 1], type='o', ylab="Intensity",
         xlab="log dose Cisplatin", main="Cisplatin", ylim=lims)
    lines(rownames(X),X[,2], type='o', col=2)
    lines(rownames(X),X[,3], type='o', col=3)
    lines(rownames(X),X[,4], type='o', col=4)
    lines(rownames(X),X[,5], type='o', col=5)
    lines(rownames(X),X[,6], type='o', col=6)
    abline(h=mean(pos.controls), col=2)
    abline(h=mean(neg.controls), col=2)
    legend("topright", col=1:6, lwd=2, legend=
           c("No Getifnib", paste0("Dose", 1:5, " Getifnib")))

    XN <- 100 - ((100 * X)/(mean(pos.controls)-mean(neg.controls)))
    XN <- pmax(XN, 0)
    XN <- XN/100
    E.XN <- matrix(NA, 5, 5)
    for (i in 1:5) {
        for (j in 1:5) {
            E.XN[i,j] <- XN[i,2] + XN[2,j] - XN[i,2] * XN[2,j]
        }
    }
    tmp <- Y[2:8,9:16]
    pos.controls <- c(tmp[1,], tmp[-1,1], tmp[-1,8], tmp[2,2])

}

plot.combo.raw <- function(Y, multiple=T) {
    Y <- as.data.frame(Y)
    Y$P_ROW <- factor(Y$P_ROW, levels=rev(LETTERS[1:16]))
    Y <- xtabs(Freq ~ P_ROW + P_COLUMN, data=Y)
    Y <- t(Y)
    require(RColorBrewer)
    cols <- rev(brewer.pal(9, "RdBu"))
    cols[5] <- "grey"
    breaks <- seq(from=min(Y), t=max(Y), length=10)
    cols <-
    if (!multiple) {
        par(mfrow=c(1,1))
        image(Y, axes=F, col=cols, breaks=breaks)
        x.ticks <- seq(from=0, to=1, length=nrow(Y))
        y.ticks <- seq(from=0, to=1, length=ncol(Y))
        axis(1, at=x.ticks, labels=rownames(Y), las=1, cex.axis=0.8)
        axis(3, at=x.ticks, labels=rownames(Y), las=1, cex.axis=0.8)
        axis(2, at=y.ticks, labels=colnames(Y), las=2, cex.axis=0.8)
        axis(4, at=y.ticks, labels=colnames(Y), las=2, cex.axis=0.8)
    } else {
        par(mfrow=c(2, 3))
        tmp <- Y[3:8, 9:14]
        image(tmp, axes=F, col=cols, breaks=breaks)
        x.ticks <- seq(from=0, to=1, length=nrow(tmp))
        y.ticks <- seq(from=0, to=1, length=ncol(tmp))
        axis(1, at=x.ticks, labels=rownames(tmp), las=1, cex.axis=0.8)
        axis(3, at=x.ticks, labels=rownames(tmp), las=1, cex.axis=0.8)
        axis(2, at=y.ticks, labels=colnames(tmp), las=2, cex.axis=0.8)
        axis(4, at=y.ticks, labels=colnames(tmp), las=2, cex.axis=0.8)
        tmp <- Y[10:15, 9:14]
        image(tmp, axes=F, col=cols, breaks=breaks)
        x.ticks <- seq(from=0, to=1, length=nrow(tmp))
        y.ticks <- seq(from=0, to=1, length=ncol(tmp))
        axis(1, at=x.ticks, labels=rownames(tmp), las=1, cex.axis=0.8)
        axis(3, at=x.ticks, labels=rownames(tmp), las=1, cex.axis=0.8)
        axis(2, at=y.ticks, labels=colnames(tmp), las=2, cex.axis=0.8)
        axis(4, at=y.ticks, labels=colnames(tmp), las=2, cex.axis=0.8)
        tmp <- Y[17:22,9:14]
        image(tmp, axes=F, col=cols, breaks=breaks)
        x.ticks <- seq(from=0, to=1, length=nrow(tmp))
        y.ticks <- seq(from=0, to=1, length=ncol(tmp))
        axis(1, at=x.ticks, labels=rownames(tmp), las=1, cex.axis=0.8)
        axis(3, at=x.ticks, labels=rownames(tmp), las=1, cex.axis=0.8)
        axis(2, at=y.ticks, labels=colnames(tmp), las=2, cex.axis=0.8)
        axis(4, at=y.ticks, labels=colnames(tmp), las=2, cex.axis=0.8)

            tmp <- Y[3:8,3:8]
        image(tmp, axes=F, col=cols, breaks=breaks)
                x.ticks <- seq(from=0, to=1, length=nrow(tmp))
        y.ticks <- seq(from=0, to=1, length=ncol(tmp))
        axis(1, at=x.ticks, labels=rownames(tmp), las=1, cex.axis=0.8)
        axis(3, at=x.ticks, labels=rownames(tmp), las=1, cex.axis=0.8)
        axis(2, at=y.ticks, labels=colnames(tmp), las=2, cex.axis=0.8)
        axis(4, at=y.ticks, labels=colnames(tmp), las=2, cex.axis=0.8)

        tmp <- Y[10:15,3:8]
        image(tmp, axes=F, col=cols, breaks=breaks)
        x.ticks <- seq(from=0, to=1, length=nrow(tmp))
        y.ticks <- seq(from=0, to=1, length=ncol(tmp))
        axis(1, at=x.ticks, labels=rownames(tmp), las=1, cex.axis=0.8)
        axis(3, at=x.ticks, labels=rownames(tmp), las=1, cex.axis=0.8)
        axis(2, at=y.ticks, labels=colnames(tmp), las=2, cex.axis=0.8)
        axis(4, at=y.ticks, labels=colnames(tmp), las=2, cex.axis=0.8)
        tmp <- Y[17:22,3:8]
        image(tmp, axes=F, col=cols, breaks=breaks)
        x.ticks <- seq(from=0, to=1, length=nrow(tmp))
        y.ticks <- seq(from=0, to=1, length=ncol(tmp))
        axis(1, at=x.ticks, labels=rownames(tmp), las=1, cex.axis=0.8)
        axis(3, at=x.ticks, labels=rownames(tmp), las=1, cex.axis=0.8)
        axis(2, at=y.ticks, labels=colnames(tmp), las=2, cex.axis=0.8)
        axis(4, at=y.ticks, labels=colnames(tmp), las=2, cex.axis=0.8)
}
}



